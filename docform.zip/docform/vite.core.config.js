// Builds src/core as one CommonJS file for the Node 12 server: dist-core/docform-core.js
// (Node 12.16 can't load the ES module source directly). Run by `npm run build`.
const path = require('path');

module.exports = {
  build: {
    outDir: 'dist-core',
    emptyOutDir: true,
    lib: { entry: path.resolve(__dirname, 'src/core/index.js'), formats: ['cjs'], fileName: () => 'docform-core.js' },
    rollupOptions: { external: ['jszip', '@xmldom/xmldom'] }, // loaded from node_modules at run time
  },
};
