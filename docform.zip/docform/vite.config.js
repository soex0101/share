import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // relative asset paths: works at the site root, under a sub-path, or behind a proxy
  base: './',
  // dev server: reachable from the LAN; /api goes to `npm start` (server.js) on port 8090
  server: { host: true, proxy: { '/api': 'http://127.0.0.1:8090' } },
});
