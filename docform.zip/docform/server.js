#!/usr/bin/env node
/*
 * DocForm server (Node 12+): the built web app (dist/) and the MongoDB API (/api).
 *
 *   node server.js                                   -> http://0.0.0.0:8090, MongoDB at mongodb://127.0.0.1:27017/docform
 *   node server.js --host 213.136.75.191 --port 8090 --mongo mongodb://127.0.0.1:27017/docform
 *   HOST=0.0.0.0 PORT=8090 MONGO_URL=mongodb://user:pass@db-host:27017/docform node server.js
 *
 * The app starts even when MongoDB is down: pages and parsing work, saving answers
 * "database not connected" until MongoDB is reachable (it retries every 5 seconds).
 * Needs `npm run build` first (dist/ and dist-core/).
 */
'use strict';
const fs = require('fs');
const path = require('path');

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

const HOST = arg('host', process.env.HOST || '0.0.0.0');
const PORT = Number(arg('port', process.env.PORT || 8090));
const DIST = path.resolve(__dirname, arg('dir', 'dist'));
const MONGO_URL = arg('mongo', process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/docform');
// src/core bundled to CommonJS by `npm run build` (Node 12 can't load the ES module source)
const CORE = path.join(__dirname, 'dist-core', 'docform-core.js');

for (const [file, what] of [
  [path.join(DIST, 'index.html'), 'web app'],
  [CORE, 'core bundle'],
]) {
  if (!fs.existsSync(file)) {
    console.error(`${file} not found (${what}). Run "npm run build" first.`);
    process.exit(1);
  }
}

const { createApp } = require('./server/app');
const db = require('./server/db');

const app = createApp({ core: require(CORE), isConnected: db.isConnected, distDir: DIST });
app.listen(PORT, HOST, () => console.log(`DocForm running at http://${HOST}:${PORT}/  (serving ${DIST})`));
db.connect(MONGO_URL);
