# DocForm

Turn a Word form designed by a manager into a fill-in template for clients, then read the clients' filled files back as JSON
and save them in MongoDB.

- Works fully **offline** on a local network: no CDN, no external requests.
- Runs on **Node.js 12.16.2** or newer (build tools, tests and server), with **MongoDB** (tested with 4.2, 4.4 and 7.0).
- Clients fill the template in their own **Microsoft Word 2013 or newer**. No add-in needed.

## Contents

1. [How it works](#1-how-it-works)
2. [Quick start](#2-quick-start)
3. [Offline deployment](#3-offline-deployment)
4. [Using the app, page by page](#4-using-the-app-page-by-page)
5. [Field types](#5-field-types)
6. [Field map JSON (template definition)](#6-field-map-json-template-definition)
7. [Parse result JSON](#7-parse-result-json)
8. [Components and modules](#8-components-and-modules)
9. [MongoDB](#9-mongodb)
10. [Code layout](#10-code-layout)
11. [Tests](#11-tests)
12. [Limits and known issues](#12-limits-and-known-issues)

---

## 1. How it works

```
 Manager                              DocForm (browser)                                Clients
 ───────                              ─────────────────                                ───────
 designs a form in Word      ──►  1. Upload template (.docx)
 (labels, tables, empty cells)     2. Match fields: click a label, say where the
                                      client writes, name the field (= DB key), type;
                                      save to the database (or open a saved one)
                                   3. Download template  ─────────── Template.docx ──►  fill it in Word
                                      (choose a saved one)                               (locked fields,
                                                                                           + rows in tables)
                                   4. Parse client file  ◄─────────── Filled.docx ◄──  send it back
                                      ──► JSON { templateId, version, status, errors, data }

 server.js (Express) ── /api ── MongoDB:  templates (field map + .docx per version)
                                          submissions (parsed values + original .docx)
```

What makes parsing reliable: in the saved template every input area becomes a Word **content control** (`w:sdt`) whose **tag** is the
field key. The client can type in it but can't delete it (`sdtLocked`). On step 4 the parser simply finds every tagged
control, no matter how much the client changed the text, the layout or the formatting around it. Tables become Word
**repeating sections**, so the client adds rows with the **+** button and each row becomes one object in the JSON.

The **field map** (also called the *definition*) is the JSON description of a template: its ID, version, and every field
with its key, type and rules. It is downloaded as `.fields.json`, embedded inside the template `.docx`, and is the object
you store in MongoDB.

## 2. Quick start

```bash
cd docform
npm install        # once, needs internet (or copy node_modules from a machine that has it)
npm test           # unit tests (Jest)
npm run build      # builds the web app into dist/ and the server's core into dist-core/
npm start          # http://0.0.0.0:8090, MongoDB at mongodb://127.0.0.1:27017/docform
```

Then open `http://<server-ip>:8090/` in a browser.

MongoDB must be installed and running (MongoDB 3.6–7.0 work with the Mongoose 6 driver; tested with 4.2, 4.4 and 7.0). If it isn't reachable, the
server still starts: all pages and parsing work, the **Save to database** buttons answer "The database is not connected",
and the server retries every 5 seconds until MongoDB answers.

| Command | What it does |
|---|---|
| `npm run dev` | Development server with hot reload (Vite, port 5173, reachable from the LAN). `/api` is forwarded to `npm start` on port 8090, so run both to save to the database while developing. |
| `npm run build` | Production build: `dist/` (web app) and `dist-core/docform-core.js` (core for the server). |
| `npm start` | `node server.js`: web app + API on `0.0.0.0:8090`. |
| `node server.js --host 213.136.75.191 --port 8090` | Choose the address and port (`HOST` / `PORT` env vars also work). |
| `node server.js --mongo mongodb://user:pass@db-host:27017/docform` | Choose the MongoDB connection (`MONGO_URL` env var also works). The password is hidden in the log. |
| `node server.js --dir some/other/dist` | Serve another build folder. |
| `npm test` | Runs `test/*.test.js` with Jest. The API tests are skipped unless `MONGO_URL` is set (section 11). |

If the page does not open from another machine, the port is probably closed by the firewall:
`sudo ufw allow 8090/tcp`.

## 3. Offline deployment

The target machine needs Node.js 12+, MongoDB, and these files with the **production** `node_modules` (Express, Mongoose,
JSZip, xmldom: about 40 MB; React and the build tools are not included, they are already compiled into `dist/`).

```bash
# on a machine with the project and internet (same OS / CPU type as the target)
npm run build
rm -rf deploy && mkdir deploy
cp -r dist dist-core server server.js package.json package-lock.json deploy/
cd deploy && npm ci --production && cd ..
tar czf docform-offline.tar.gz -C deploy .

# on the offline machine
mkdir docform && tar xzf docform-offline.tar.gz -C docform && cd docform
node server.js --port 8090 --mongo mongodb://127.0.0.1:27017/docform
```

`server.js` serves the web app and the API from the same address (no CORS setup). It returns a real `404` for missing
files (instead of `index.html`, which caused "MIME type text/html" errors), sends `index.html` with `no-cache` so a new
build is picked up at once, and caches hashed files in `dist/assets/` for a year. The app uses hash URLs (`#/match`), so no
route configuration is needed.

## 4. Using the app, page by page

Each step is its own page with its own URL. The step bar at the top shows where you are; a step is clickable once the data
it needs exists. Work in progress (the uploaded template and the linked fields) is kept in the browser, so pages can be
refreshed or opened directly. It is per browser: another computer starts empty (use the field map JSON or MongoDB to share).

### Page 1: Upload template (`#/upload`)

Design the form in Word as usual: labels ("Title", "1. Task requirements"), tables with header rows, empty cells or example
text where the client should write. No placeholders or special marks are needed. Save it as `.docx` (old `.doc` files: open
in Word and *Save As* `.docx` first) and drop it on the page. Uploading a new file starts over with no fields.

### Page 2: Match fields (`#/match`)

Three panels: the field list (left), the document (middle), the link panel (right).

**Fixed field** (one value per document):

1. Click a label in the document, e.g. **Title**.
2. *Client writes in*: choose the input area. The app suggests, in this order:
   - **Text below**: the paragraph(s) under the label in the same cell or page,
   - **Cell right**: the table cell to the right (`Name: | ______ |`),
   - **Cell below**: the cell under the label cell,
   - **Replace label** / **This area**: the clicked paragraph itself.
   A choice with a dot is already used by another field.
3. *Field name (DB key)*: suggested from the label (`"1. Task requirements"` → `taskRequirements`). Letters, digits and `_`;
   a dot makes a nested object (`client.name` → `{ client: { name } }`).
4. *Type* (section 5), *Required*, and per type: dropdown choices, number min / max / unit.
5. **Create & link**. The area turns green with the key on it.

**Repeating table** (a list of rows, e.g. project members):

1. Click a cell in the table's **header row** (e.g. "Gender"), then the **Repeating table** tab.
2. The row under the header becomes the row clients repeat. Each header cell is a column: keep or untick it, set its key,
   type and *req*.
3. *Remove N sample rows below*: deletes example rows the manager typed under the input row.
4. **Create table**.

Remove a field with **×** in the field list. **Download field map (.json)** saves the field map; **View JSON** shows it.
**Next: download template** goes to page 3.

**Template ID and Name** (under the field list): *Template ID* is the stable identifier, e.g. `tpl_project_task`; every
parse result and MongoDB document refers to it. *Name* is shown to people and used in the file name. Both are suggested
from the file name.

**Saving to the database** (under the field list). A line shows the state, with the buttons for it:

| State | Shown | Buttons |
|---|---|---|
| New upload, or Template ID changed | "Not saved in the database yet." | **Save to database** creates this ID + version. If that version already exists, the error says so and **Save as new version** appears. |
| Saved (or opened), no changes since | "Saved in the database as tpl_sample v1." | **Save as new version** (Save changes is off: nothing to save) |
| Changed after saving or opening | "Changed since saved as tpl_sample v1." | **Save changes** overwrites v1 (field map, template file and original). **Save as new version** keeps v1 and saves the next free version (highest saved + 1). |

Which one? While the template hasn't been sent to clients, **Save changes**. After clients have it, **Save as new
version**: their returned files still parse with their own version's field map, while files made from an overwritten
version are read with the new fields. Each save stores the field map, the generated template and the original `.docx`.

**Open a saved template** (under the field list, and on the "No template yet" page): choose a version saved in MongoDB and
click **Open**. Its original Word file and its fields are loaded, replacing the current work, and can be changed like a new
upload (add fields, remove with **×**, re-link a removed one), then saved with **Save changes** or **Save as new version**.
Versions saved before the original file was stored are listed as "(original .docx not saved)" and can't be opened: upload
the original .docx once and save a new version.

### Page 3: Download template (`#/download`)

Choose a template saved in the database and click **Download .docx**. The file is the client template stored by the
last save of that version (`<name>_v<version>.docx`): locked, tagged content controls, repeating tables, and the field map
embedded inside the file. The version being edited on the Match page is preselected. Works on its own: no template needs
to be loaded, e.g. to send an older version to a client again. Templates are created and changed on the Match page.

### Page 4: Parse client file (`#/parse`)

Works on its own: no earlier step is needed.

1. *Field map* (optional): load a `.fields.json`, **or** pick a template saved in the database ("or use a saved
   template" → **Use**). Either is validated; a bad map shows why and is not used.
2. *Client file*: drop the filled `.docx`. The result shows a status (**OK** / **Needs review**), errors, warnings, and
   the JSON, with **Copy JSON** and **Download JSON**.
3. *Save to database*: uploads the file. The **server parses it again** with the field map stored in MongoDB for the
   template shown in the result, and saves the values and the original file. A file needing review is saved too, marked
   `needs_review`. The same file can't be saved twice ("This file is already saved").

Which field map is used, in order: the chosen map (`.json` or database) → the map embedded in the `.docx` → the map
currently being edited on the Match page. `definitionSource` in the result says which (`loaded`, `embedded`, `fallback`,
`none`). If a chosen map and the file's embedded map are different templates or versions, a warning is added. Choosing or
removing a map re-parses the current file. When no template is known for a file (no embedded map and none chosen),
**Save to database** is disabled until you choose its field map.

## 5. Field types

| Type | In Word the client sees | In the JSON | Checks when parsing |
|---|---|---|---|
| `text` | plain text box (multi-line allowed) | string | required |
| `rich` | rich text block: several paragraphs, formatting, pictures | string (plain text, paragraphs joined by `\n`); pictures are listed in `images` (section 7) | required (a picture alone counts as filled) |
| `number` | plain text box | number: `"1,200 $"` → `1200` | is a number, `min`, `max`, required |
| `date` | date picker, shown as `yyyy-MM-dd` | `"2026-11-18"` | required |
| `dropdown` | drop-down list with fixed choices | the chosen text | value is one of `options`, required |

Empty fields (gray placeholder still showing) become `null`. A failed check never drops the value: the original text is
kept in `data` and the problem is listed in `errors`.

## 6. Field map JSON (template definition)

Saved as `<name>_v<version>.fields.json` from the Match page. Example for `Sample.docx` (shortened, and with
a `taskType` dropdown added to show `options`):

```json
{
  "format": "docform.definition",
  "formatVersion": 1,
  "templateId": "tpl_sample",
  "name": "Sample",
  "version": 1,
  "fields": [
    { "key": "title", "label": "Title", "type": "text", "required": false,
      "labelPath": [0, 0, 0, 0], "targetPaths": [[0, 0, 0, 0]] },
    { "key": "taskRequirements", "label": "Task requirements", "type": "rich", "required": false,
      "labelPath": [0, 2, 0, 0], "targetPaths": [[0, 2, 0, 1], [0, 2, 0, 2]] },
    { "key": "taskType", "label": "Task type", "type": "dropdown", "required": true,
      "options": ["Web Project", "Application", "Mobile", "Hybrid"] }
  ],
  "groups": [
    { "key": "projectMembers", "label": "Project members", "headerRow": [0, 5],
      "removeSampleRows": true, "sampleRows": 4,
      "columns": [
        { "key": "name", "label": "Name", "type": "text", "required": false, "cell": 1 },
        { "key": "age", "label": "Age", "type": "number", "required": false, "cell": 3 }
      ] }
  ]
}
```

| Property | Meaning |
|---|---|
| `format`, `formatVersion` | Always `"docform.definition"` and `1`. A newer `formatVersion` is refused. |
| `templateId`, `name`, `version` | Template identity (Match page; the version is set by the save buttons). |
| `fields[]` | Fixed fields: one value each. |
| `fields[].key` | JSON / DB field name. Unique across `fields` and `groups`. |
| `fields[].label` | Human name, shown in Word on the control. |
| `fields[].type` | `text`, `rich`, `number`, `date` or `dropdown`. |
| `fields[].required` | Empty value → error. |
| `fields[].options` | Dropdown choices (required for `dropdown`). |
| `fields[].min`, `max`, `unit` | Number limits; `unit` is informational. |
| `fields[].labelPath`, `targetPaths` | Where the label and the input area are in the manager's original `.docx`. |
| `groups[]` | Repeating tables: an array of row objects each. |
| `groups[].headerRow` | `[table, row]` of the header row; the row below it is repeated. |
| `groups[].removeSampleRows`, `sampleRows` | Example rows deleted from the template. |
| `groups[].columns[]` | Same properties as a field, plus `cell` (cell index in the row). |

**Paths.** Indexes start at 0. `[i]` is the i-th element of the document body (a paragraph). `[i, r, c, k]` is body element
`i` (a table), row `r`, cell `c`, paragraph `k`. Paths are only needed to *generate* the template from the original file.
Parsing only needs keys and types, so a hand-written map with only `key` / `type` / `required` / `options` works for
parsing too.

## 7. Parse result JSON

`parseSubmission()` and the Parse page return:

```json
{
  "templateId": "tpl_sample",
  "templateName": "Sample",
  "version": 1,
  "definitionSource": "embedded",
  "status": "ok",
  "errors": [],
  "warnings": [],
  "data": {
    "title": "Customer portal",
    "taskRequirements": "Build the customer portal with login and reports.",
    "projectMembers": [
      { "no": "1", "name": "Jack", "gender": "M", "age": 31, "duty": "Senior", "grade": null },
      { "no": "2", "name": "Gleb", "gender": "X", "age": 35, "duty": "Junior", "grade": null }
    ]
  },
  "images": [
    { "field": "taskRequirements", "fileName": "image1.png", "contentType": "image/png", "size": 48213,
      "path": "word/media/image1.png" }
  ]
}
```

| Property | Meaning |
|---|---|
| `status` | `ok`, or `needs_review` when `errors` is not empty. |
| `errors[]` | `{ field, message }`. `field` is a key or a row path like `projectMembers[1].age`. Examples: required field empty, `"abc" is not a number`, value not in the dropdown list, field missing (deleted in Word), field appears twice (pasted from another document). |
| `warnings[]` | Text: no field map found, loaded map is another template/version, unknown tagged fields ignored. |
| `data` | The values. Fixed fields by key (dotted keys nested), tables as arrays of row objects. Rows the client left completely empty are skipped. Only text: pictures are in `images`. |
| `images[]` | Pictures the client put in fields (usually rich text): `field` (same form as in `errors`), `fileName`, `contentType`, `size` in bytes, `path` in the `.docx` zip. A picture used twice in one field is listed once. Linked (not embedded) pictures have no bytes in the file and are skipped. With `parseSubmission(data, { withImageBytes: true })` each entry also has `bytes` (Uint8Array). When saved, the server stores the bytes in GridFS and adds `fileId` (section 9.1). |

## 8. Components and modules

All React components are **controlled and driven by props**: they don't use the router or the workspace store, so you can
drop them into another React app (e.g. your MERN frontend) and keep the data wherever you want. Everything is exported from
`src/index.js`:

```jsx
import { FieldMatcher, SubmissionParser, readDefinition, parseSubmission } from './docform/src/index.js';
```

### 8.1 Core (`src/core/`): .docx logic, no React

Plain JavaScript that runs in the browser and, bundled to CommonJS by `npm run build` (`dist-core/docform-core.js`), in the
Node 12 server.
Dependencies: `jszip`, `@xmldom/xmldom`.

| Function | Signature | Description |
|---|---|---|
| `loadDocx` | `(bytes) → Promise<{ zip, doc }>` | Opens a `.docx` (Uint8Array, ArrayBuffer or Node Buffer). Throws for non-Word files. |
| `buildPreview` | `(doc) → { blocks, paras }` | Light model of paragraphs and tables (text runs, bold/italic/underline, merged cells, widths) for drawing and click-to-link. |
| `suggestTargets` | `(preview, labelPath) → [{ mode, title, paths }]` | Candidate input areas for a clicked label: `below-text`, `right`, `below-cell`, `self`, most likely first. |
| `describeGroupRow` | `(preview, [table, row]) → { header, template, sampleRows, title, columns }` | Info for making a repeating table from a header row. |
| `generateTemplate` | `(originalBytes, definition) → Promise<Uint8Array>` | Builds the client template: content controls, repeating sections, embedded field map. Throws a readable error when a path doesn't match the file or two fields share an area. |
| `exportDefinition` | `(definition) → object` | Definition → the field map JSON object (section 6). Use it for downloads and for sending to the API. |
| `readDefinition` | `(jsonStringOrObject) → definition` | Validates a field map from a file, the API or MongoDB. Throws `Invalid field map: …` listing the problems. |
| `parseSubmission` | `(filledBytes, { definition?, fallback? }) → Promise<result>` | Filled `.docx` → result JSON (section 7). |
| `keyFromLabel`, `uniqueKey`, `KEY_RE`, `FIELD_TYPES`, `pathKey`, `DEFINITION_FORMAT` | | Helpers and constants for keys and types. |

Files: `xml.js` (namespace-aware XML helpers), `docx.js` (open file, resolve paths), `preview.js`, `generate.js`,
`definition.js`, `parse.js`, `keys.js`, `index.js`.

### 8.2 Feature components (`src/features/`)

#### `TemplateUploader`: step 1
Choose / drop a `.docx`, check it opens, build its preview. Nothing is uploaded to a server.

| Prop | Type | Description |
|---|---|---|
| `onLoaded` | `({ fileName, bytes, preview }) => void` | `bytes`: the original file (keep it for `generateTemplate`); `preview`: for `FieldMatcher`. |

#### `FieldMatcher`: step 2
The three-panel editor. Holds only the current click in local state; the definition belongs to the parent.

| Prop | Type | Description |
|---|---|---|
| `preview` | object | From `TemplateUploader` / `buildPreview`. |
| `definition` | object | `{ templateId, name, version, fields, groups }`. Start with `newDefinition(fileName)` (`src/state/definition.js`). |
| `onChange` | `(definition) => void` | Called with a new object after every add / remove. |
| `footer` | node | Optional, shown under the field list (the Match page puts the JSON buttons and *Next* there). |

Built from:
- **`DocPreview`**: renders the document; props `preview`, `deco` / `rowDeco` (highlight maps), `onPick(para)`.
  Usable alone as a read-only viewer.
- **`FieldList`**: the list of fields and tables; `onRemove(kind, key)` optional (without it the list is read-only).
- **`FixedFieldForm`**, **`RepeatingTableForm`**: the two link forms (controlled; values in `form`, changes via `onChange`).
- **`matcherModel.js`**: all the decisions as pure functions: `startSelection` (suggestions and default form values for a
  click), `fieldFromForm` / `groupFromForm` (form → definition entry, or `{ error }`), `usedAreas`, `decorations`. Unit
  tested; reuse it to build a different UI.

#### `FieldMapActions`: field map buttons
**Download field map (.json)** and **View JSON** (dialog). Props: `definition`, `disabled`. Also exports
`fieldMapJson(definition)` (pretty JSON text) and `fieldMapFileName(definition)`.

#### `FieldMapLoader`: load a `.fields.json`
Validates with `readDefinition`; shows a summary card with **Remove**, or the error.

| Prop | Type | Description |
|---|---|---|
| `value` | `{ definition, fileName } \| null` | The loaded map. |
| `onChange` | `(value \| null) => void` | New map, or `null` after Remove. |

#### `SubmissionParser`: step 4
Drop a filled `.docx`; parses it in the browser and shows `ParseResult`. Re-parses when `definition` changes.

| Prop | Type | Description |
|---|---|---|
| `definition` | definition \| null | Map to use; wins over the one embedded in the file. |
| `fallbackDefinition` | definition \| null | Used only when there's no `definition` and the file has no embedded map. |
| `onParsed` | `(result, fileName, bytes) => void` | After every parse (also re-parses). The Parse page keeps the latest one for its *Save to database* button. |

#### `ParseResult`
Shows a result: status badge, errors, warnings, JSON, **Copy JSON** (works on plain-http LAN pages too) and **Download JSON**.
Props: `result`, `fileName`.

#### Database components (`src/features/database/`)
They call the API through `src/lib/api.js` and show their own success / error message next to the button.

| Component | Props | What it does |
|---|---|---|
| `SaveTemplateButton` | `templateBytes`, `fileName`, `definition`, `status` (`'new'` / `'saved'` / `'changed'`), `onSaved(definition)` | State line plus **Save to database** (`POST /api/templates`), **Save changes** (`PUT /api/templates/:id/:v`) and **Save as new version** (`POST …?newVersion=1`), as in the table on page 2. Each also stores the generated file (`PUT …/file`) and the original (`PUT …/source`). `onSaved` gets the definition with the version actually saved. |
| `SaveSubmissionButton` | `bytes`, `fileName`, `result`, `onSaved?({ id, result })` | Uploads the client file (`POST /api/submissions?templateId&version`, taken from `result`). Disabled when `result` has no template. Give it a `key` that changes with the file / map so its message resets. |
| `TemplatePicker` | `onPick(value)`, `withSource?`, `label?`, `buttonText?` | Lists saved templates (`GET /api/templates`). The button loads one and checks it with `readDefinition`. Without `withSource` (Parse page): `value = { definition, fileName }`, the same shape as `FieldMapLoader`. With `withSource` (Match page): also loads the original `.docx`, so `value = { definition, fileName, template: { fileName, bytes, preview } }`; versions without a stored original are disabled. Shows one muted line when the database isn't available. |
| `SavedTemplateDownload` | `preselect?` `{ templateId, version }` | Lists saved templates; **Download .docx** saves the chosen version's stored template file (`GET …/file`). Versions without a file are disabled. |

**`src/lib/api.js`**: `health()`, `listTemplates()`, `loadTemplate(templateId, version | 'latest')`, `saveTemplate(definition)`,
`saveTemplateFile(templateId, version, bytes)`, `saveTemplateSource(templateId, version, bytes, fileName)`,
`loadTemplateFile(templateId, version)` / `loadTemplateSource(templateId, version)` → `{ fileName, bytes }`, `saveSubmission(bytes, fileName, { templateId, version })`. Each returns a
Promise and rejects with an `Error` whose message is ready to show (`err.status` and `err.body` hold the HTTP details).
URLs are relative (`api/…`), so the app works under a sub-path too.

### 8.3 Shared components (`src/components/`), helpers (`src/lib/`)

- **`FileDrop`**: click-or-drop file picker. Props: `onFile(file)`, `label`, `accept` (default `.docx`), `buttonText`.
- **`Layout`**: top bar with the step navigation. Props: `steps: [{ path, label, enabled }]`, `right`, `children`.
- **`lib/files.js`**: `saveFile(data, name, type)` (browser download), `readFile(file)` → Uint8Array, `safeFileName`,
  `DOCX_MIME`.

### 8.4 App wiring (only used by this app)

- **`src/pages/`**: one file per page. A page connects a feature component to the shared workspace and navigation; it holds
  no .docx logic. `NeedTemplate` is shown when Match / Download is opened with no template. `OpenSavedTemplate` (Match page
  and `NeedTemplate`) opens a version from MongoDB with `setTemplate(template, definition)`.
- **`src/state/Workspace.jsx`**: `WorkspaceProvider` + `useWorkspace()` → `{ ready, template, definition, setTemplate,
  setDefinition, dbStatus, markStored }`. `setTemplate(t, definition?)` starts with no fields, or with the given ones
  (opened from MongoDB, so they count as saved). `dbStatus` compares the definition with the last save / open
  (`state/definition.js`: `storedSnapshot`, `dbStatus`); `markStored(definition)` is called after a save. Restores the saved state on start.
- **`src/state/persist.js`**: browser storage: IndexedDB for the template file (can be several MB), localStorage for the
  definition (written immediately, so nothing is lost on a quick refresh). Memory fallback when storage is blocked.
- **`src/state/definition.js`**: `newDefinition(fileName)`, `hasFields(definition)`.
- **`src/router/hashRouter.jsx`**: tiny hash router: `useRoute()`, `navigate(path)`, `<Link to>`, `<Routes routes fallback>`.
- **`src/App.jsx`**: the route table and the step rules. **`src/main.jsx`**: mounts the app.

## 9. MongoDB

`server.js` saves templates and client files in MongoDB through a small JSON API under `/api`. Stack: Express 4 +
Mongoose 6 (the last Mongoose line that runs on Node 12), tested with MongoDB 4.2, 4.4 and 7.0.

### 9.1 What is stored

| Collection | One document per | Created by |
|---|---|---|
| `templates` | template **version** | the save buttons on the Match page |
| `submissions` | client file | **Save to database** on the Parse page |
| `images.files`, `images.chunks` | picture from a client file (GridFS bucket `images`) | the same save, one file per picture |

```js
// templates
{ _id, templateId: "tpl_sample", version: 1, name: "Sample",
  definition: { format: "docform.definition", formatVersion: 1, templateId: "tpl_sample", version: 1,
                fields: [...], groups: [...] },          // the field map JSON (section 6), exactly as exported
  file: BinData(...),                                     // the template .docx sent to clients
  source: BinData(...), sourceName: "Sample.docx",         // the manager's original .docx, to edit this version again
  createdAt, updatedAt }

// submissions
{ _id, templateId: "tpl_sample", version: 1, fileName: "filled.docx",
  status: "ok",                                           // or "needs_review"
  parseErrors: [], warnings: [],                          // result.errors / result.warnings (section 7)
  data: { title: "Customer portal", projectMembers: [{ name: "Jack", age: 31 }] },
  images: [{ fileId: ObjectId("…"), field: "taskRequirements",   // pictures in fields; bytes in GridFS
             fileName: "image1.png", contentType: "image/png", size: 48213 }],
  fileHash: "9f2c…",                                      // SHA-256 of the file
  file: BinData(...),                                     // the client's original .docx
  createdAt, updatedAt }

// images.files (GridFS; the bytes are in images.chunks)
{ _id: ObjectId("…") /* = fileId above */, filename: "image1.png", length: 48213, uploadDate,
  metadata: { submissionId: ObjectId("…"), contentType: "image/png" } }
```

Indexes (created when the server connects): `templates { templateId, version }` unique; `submissions { fileHash }` unique,
`{ templateId, version, createdAt }`, `{ status, createdAt }`.

Design rules:

- **Pictures go to GridFS**, not into the submission: the document already holds the whole `.docx` and must stay under
  16 MB. A picture file used in several fields is stored once (the entries share its `fileId`). Saving is all or nothing:
  if a picture can't be stored, the submission and the pictures already stored are removed and the save fails.
- **One record per version.** The unique index stops a second record for the same `templateId` + `version` (`409`).
  Changing a saved version is an explicit overwrite (`PUT`, "Save changes"); keep a version unchanged once clients have
  it and save a new version instead (`?newVersion=1`).
- **Submissions are parsed on the server** with the field map stored for their template, never taken from the browser's
  JSON. The browser only says *which* template (`templateId` / `version` of its result); without that, the map embedded in
  the file decides. A template that isn't in the database is refused, so every submission points to a stored field map.
- **The same file is saved once** (`fileHash`), e.g. a double click or a re-upload answers `409`.
- **Files with problems are saved too**, as `status: "needs_review"` with `parseErrors`, so nothing a client sent is lost.
- `definition` is stored as-is (`Mixed`): every field has a property named `type`, which a nested Mongoose schema would
  read as a schema type, and the format can grow without a migration.
- The parser's `errors` is stored as `parseErrors`: Mongoose reserves `errors` for validation errors.
- `.docx` files are kept inside the documents (`file`, not returned unless asked for). Uploads are limited to 15 MB to stay
  under MongoDB's 16 MB document limit.
- `data` keys are field keys; `KEY_RE` makes them safe MongoDB names (no `$`, dotted keys are nested objects), so they can
  be queried directly.

### 9.2 API

All responses are JSON; errors are `{ error: "message" }` with the HTTP status below. While MongoDB is not connected,
every route except `/api/health` answers **503** "The database is not connected."

| Method and path | Body | Answer |
|---|---|---|
| `GET /api/health` | | `{ db: true \| false }` |
| `POST /api/templates` | field map JSON (section 6) | `201 { templateId, version }`; `400` invalid map (same checks as the Parse page), no `templateId`, or version not a whole number ≥ 1; `409` version already saved |
| `POST /api/templates?newVersion=1` | field map JSON | saved as the next free version of its `templateId` (highest + 1, or 1), whatever its `version` says; `201 { templateId, version }` |
| `PUT /api/templates/:templateId/:version` | field map JSON with the same `templateId` / `version` | overwrites that version's field map and name; `200 { templateId, version }`; `400` invalid map or other ID / version; `404` not saved |
| `GET /api/templates` | | `[{ templateId, version, name, createdAt, hasFile, hasSource }]`, by `templateId`, newest version first; `hasFile` / `hasSource`: the template / original `.docx` is stored |
| `GET /api/templates/:templateId/:version` | | the field map JSON; `:version` may be `latest`; `404` |
| `PUT /api/templates/:templateId/:version/file` | the template `.docx` (raw bytes) | `204`; `404` when the field map isn't saved |
| `GET /api/templates/:templateId/:version/file` | | the template `.docx` (download), its file name in `X-File-Name` |
| `PUT /api/templates/:templateId/:version/source` | the manager's original `.docx` (raw bytes); header `X-File-Name` (URI-encoded) | `204`; `404` when the field map isn't saved |
| `GET /api/templates/:templateId/:version/source` | | the original `.docx`, its file name in `X-File-Name`; `404` when not stored |
| `POST /api/submissions?templateId=&version=` | the filled `.docx` (raw bytes); header `X-File-Name` (URI-encoded) | `201 { id, result }` (`result` = the server's parse, section 7); `400` not a `.docx` / unknown template; `409 { id }` file already saved |
| `GET /api/submissions?templateId=&version=&status=&limit=` | | newest first, without files; `limit` 1–1000, default 100 |
| `GET /api/submissions/:id` | | one submission, without the file; `404` |
| `GET /api/submissions/:id/file` | | the original `.docx` |
| `GET /api/submissions/:id/images/:fileId` | | one picture from GridFS, with its `Content-Type` (sent as a download, so an SVG can't run scripts; `<img src>` still works); `404` when it isn't one of this submission's pictures |

Examples with `curl`:

```bash
curl -X POST -H 'Content-Type: application/json' --data @Sample_v1.fields.json http://localhost:8090/api/templates
curl -X POST --data-binary @filled.docx -H 'X-File-Name: filled.docx' http://localhost:8090/api/submissions
curl 'http://localhost:8090/api/submissions?templateId=tpl_sample&status=needs_review'
```

### 9.3 Server code (`server/`)

| File | What it does |
|---|---|
| `server.js` | Entry point: reads `--host` / `--port` / `--mongo` / `--dir`, checks the build exists, starts the app, connects MongoDB. |
| `server/app.js` | `createApp({ core, isConnected, distDir? })`: Express app with `/api` and the static web app. No `listen`, no database connection: tests and other servers can mount it. |
| `server/db.js` | `connect(url)` (retries every 5 s, creates indexes, never throws), `isConnected()`, `disconnect()`. Commands are not buffered, so requests fail at once while MongoDB is down instead of hanging. |
| `server/images.js` | GridFS bucket `images`: `upload(bytes, fileName, metadata)` → fileId, `download(fileId)` → stream, `remove(fileIds)`. |
| `server/models/Template.js`, `Submission.js` | Mongoose schemas and indexes (9.1). |
| `server/routes/index.js` | `/api` router: `/health`, the 503 guard, JSON 404 and error handler. |
| `server/routes/templates.js`, `submissions.js` | The routes in 9.2. They get the DocForm core as a parameter (`readDefinition`, `parseSubmission`). |
| `server/routes/util.js` | `wrap` (async errors → Express), `httpError(status, message)`, `rawDocx` (15 MB raw body parser). |

The server uses the same core as the browser: `npm run build` bundles `src/core` into `dist-core/docform-core.js`
(`vite.core.config.js`), because Node 12.16 can't load the ES module source directly.

### 9.4 Using it from your MERN backend

The simplest setup runs the DocForm server next to your app, both on the same MongoDB. To serve it from an existing
Express backend instead, mount the app on a path:

```js
// in your backend (CommonJS, Node 12+)
const path = require('path');
const { createApp } = require('./docform/server/app');
const db = require('./docform/server/db');
const core = require('./docform/dist-core/docform-core.js');

db.connect(process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/docform');
app.use('/docform', createApp({ core, isConnected: db.isConnected, distDir: path.join(__dirname, 'docform/dist') }));
// open http://host:port/docform/  (with the trailing slash: the app calls "api/…" relative to the page)
```

`db.connect` uses DocForm's own Mongoose (from `docform/node_modules`). If your backend has its own Mongoose install, that
is a separate connection: connect it as usual, and use DocForm's models (below) for DocForm's collections.

Your own code can read the collections with the models:

```js
const Submission = require('./docform/server/models/Submission');

// members older than 30 in files of a template that passed all checks
const rows = await Submission.find(
  { templateId: 'tpl_sample', status: 'ok', 'data.projectMembers.age': { $gt: 30 } },
  { data: 1, fileName: 1, createdAt: 1 }, // never load `file` unless needed
).lean();
```

## 10. Code layout

```
docform/
  index.html                 page shell, loads src/main.jsx
  vite.config.js             web app build (relative asset paths: works under any sub-path; dev proxy for /api)
  vite.core.config.js        builds src/core into dist-core/docform-core.js (CommonJS) for the server
  server.js                  server entry: options, MongoDB connection, listen (Node 12+)
  server/                    Express + Mongoose (section 9.3)
    app.js                   createApp(): /api + static web app
    db.js                    MongoDB connection with retry
    images.js                GridFS bucket "images": store / read / delete pictures
    models/                  Template.js, Submission.js
    routes/                  index.js (/api), templates.js, submissions.js, util.js
  src/
    main.jsx                 mounts <App/>
    App.jsx                  routes + step rules
    index.js                 public exports for reuse in another React app
    styles.css               all styles
    core/                    .docx logic, no React (browser + Node)
      xml.js                 namespace-aware XML helpers
      docx.js                open a .docx, resolve paragraph / row paths
      preview.js             document model, input-area suggestions, table header info
      generate.js            tagged template: content controls, repeating sections, embedded field map
      definition.js          field map JSON: exportDefinition() / readDefinition()
      parse.js               filled .docx -> result JSON with checks
      keys.js                key rules, key suggestions, field types
      index.js               core exports
    features/                reusable React components (props only)
      upload/TemplateUploader.jsx
      match/FieldMatcher.jsx, DocPreview.jsx, FieldList.jsx, FixedFieldForm.jsx,
            RepeatingTableForm.jsx, matcherModel.js
      definition/FieldMapActions.jsx, FieldMapLoader.jsx
      parse/SubmissionParser.jsx, ParseResult.jsx
      database/SaveTemplateButton.jsx, SaveSubmissionButton.jsx, TemplatePicker.jsx,
                             SavedTemplateDownload.jsx
    pages/                   one file per page (connects features to state + navigation)
      UploadPage.jsx, MatchPage.jsx, DownloadPage.jsx, ParsePage.jsx, NeedTemplate.jsx
    state/                   Workspace.jsx (shared state), persist.js (browser storage), definition.js
    router/hashRouter.jsx    tiny hash router
    components/              Layout.jsx (step bar), FileDrop.jsx
    lib/files.js             browser download / read helpers
    lib/api.js               browser client for the /api routes
  test/
    core.test.js             generate + parse round trips, checks, embedded map
    matcher.test.js          matcherModel suggestions and validation
    definition.test.js       field map export / validation, loaded-map precedence
    api.test.js              the MongoDB API (needs MONGO_URL)
    helpers.js, fixtures/Sample.docx
```

## 11. Tests

`npm test` runs the Jest tests on Node 12. They generate a template from `test/fixtures/Sample.docx`, fill it the way Word
does (`fillDocx` in `test/helpers.js`), parse it back and check the values and errors. They also cover the matcher logic and
the field map format, and pictures in fields (`addImage` pastes one the way Word stores it) (24 tests).

The 10 API tests (`test/api.test.js`) need a MongoDB server and are skipped without one:

```bash
MONGO_URL=mongodb://127.0.0.1:27017 npm test
```

They use a new throw-away database (`docform_test_<time>`) and drop it at the end. They cover saving a field map once
per version, invalid maps, the template file, server-side parsing and saving a client file once, pictures stored in GridFS, unknown templates, non-.docx
uploads, and the 503 answer while the database is down.

## 12. Limits and known issues

- Clients need **Word 2013 or newer** for the **+** button on repeating rows. Word 2007/2010 can fill fields but can't add
  rows. `.doc` files are not supported (save as `.docx`).
- Rich text fields return plain text; formatting is not kept. Pictures are extracted (`images`, GridFS) but where they
  sat in the text is not recorded.
- The generated templates pass Office Open XML schema validation but were not opened in real Microsoft Word on this
  machine: test one template in Word before sending it to clients.
- If a client copies a filled field from another document, the same tag appears twice. The parser reports it as an
  error instead of guessing.
- The Match page preview is simplified (no images, shapes, headers/footers, or exact fonts). Labels inside text boxes,
  headers or footers can't be linked.
- The app has no login: anyone who can open the page can save to and read from the database API. Keep it on the
  local network (or put it behind your MERN app's authentication, section 9.4).
- Node 12 limits the versions: Vite 2 and Jest 26 (build and test only) and Mongoose 6 / Express 4 (used by the server).
  `npm audit` reports warnings for some of these old versions. Moving to Node 18+ would allow current versions.
- Submissions are stored with their original `.docx` (up to 15 MB each). For very large volumes, move the files to GridFS
  or a file store and keep only the reference in the document.
