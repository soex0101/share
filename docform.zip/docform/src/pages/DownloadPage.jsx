import SavedTemplateDownload from '../features/database/SavedTemplateDownload.jsx';
import { useWorkspace } from '../state/Workspace.jsx';
import { Link } from '../router/hashRouter.jsx';

/**
 * Page 3 (#/download): choose a template version saved in MongoDB and download its client
 * template .docx. Templates are made and saved on the Match page; this page only downloads them.
 * The version being edited on the Match page is preselected when it is saved.
 */
export default function DownloadPage() {
  const { ready, definition, dbStatus } = useWorkspace();
  if (!ready) return null;
  const current = dbStatus === 'new' ? null : { templateId: definition.templateId, version: definition.version };

  return (
    <section className="center-card">
      <h1>Download a template</h1>
      <p className="muted">
        Choose a template saved in the database and download it. Clients fill it in Microsoft Word 2013 or newer; the field definitions
        are stored inside the file, so any returned copy can be read on the Parse page.
      </p>
      <SavedTemplateDownload preselect={current} />
      <p className="muted small">
        To create or change a template, <Link to="/match">match its fields</Link> and save it to the database. Then{' '}
        <Link to="/parse">parse the files clients return →</Link>
      </p>
    </section>
  );
}
