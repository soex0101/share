import FieldMatcher from '../features/match/FieldMatcher.jsx';
import FieldMapActions from '../features/definition/FieldMapActions.jsx';
import SaveTemplateButton from '../features/database/SaveTemplateButton.jsx';
import { useWorkspace, hasFields } from '../state/Workspace.jsx';
import { navigate } from '../router/hashRouter.jsx';
import NeedTemplate from './NeedTemplate.jsx';
import OpenSavedTemplate from './OpenSavedTemplate.jsx';

/**
 * Page 2 (#/match): link labels to fields. Every change is saved to the browser right away.
 * The footer offers the field map JSON (download / view), the way to the Download page, Template ID /
 * Name and saving to the database (Save changes / Save as new version), and opening a saved template instead.
 * The version is set by the save buttons (Save as new version picks the next free one).
 * The `key` resets the matcher's local state when another template is uploaded or opened.
 */
export default function MatchPage() {
  const { ready, template, definition, setDefinition, dbStatus, markStored } = useWorkspace();
  if (!ready) return null;
  if (!template) return <NeedTemplate />;
  const empty = !hasFields(definition);

  return (
    <FieldMatcher
      key={template.openedAt}
      preview={template.preview}
      definition={definition}
      onChange={setDefinition}
      footer={
        <>
          <FieldMapActions definition={definition} disabled={empty} />
          <button className="btn primary block" disabled={empty} onClick={() => navigate('/download')}>
            Next: download template
          </button>
          {!empty && (
            <div className="id-fields">
              {/* templateId + version identify the template everywhere (database, parse results) */}
              <label>
                Template ID
                <input value={definition.templateId} onChange={(e) => setDefinition({ ...definition, templateId: e.target.value })} />
              </label>
              <label>
                Name
                <input value={definition.name} onChange={(e) => setDefinition({ ...definition, name: e.target.value })} />
              </label>
            </div>
          )}
          {!empty && (
            <SaveTemplateButton
              templateBytes={template.bytes}
              fileName={template.fileName}
              definition={definition}
              status={dbStatus}
              onSaved={(d) => {
                setDefinition(d);
                markStored(d);
              }}
            />
          )}
          <OpenSavedTemplate label="Open a saved template instead (replaces the current fields):" />
        </>
      }
    />
  );
}
