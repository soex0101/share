import { Link } from '../router/hashRouter.jsx';
import OpenSavedTemplate from './OpenSavedTemplate.jsx';

/**
 * Shown by the Match page when no template is uploaded yet (e.g. a bookmarked URL in a new browser).
 * Offers an upload, or opening a template saved in the database.
 */
export default function NeedTemplate() {
  return (
    <section className="center-card">
      <h1>No template yet</h1>
      <p className="muted">
        <Link to="/upload">Upload a Word template</Link> first.
      </p>
      <OpenSavedTemplate label="or open a saved template:" />
    </section>
  );
}
