import TemplateUploader from '../features/upload/TemplateUploader.jsx';
import { useWorkspace } from '../state/Workspace.jsx';
import { navigate, Link } from '../router/hashRouter.jsx';

/**
 * Page 1 (#/upload): choose the manager's Word template.
 * Uploading a new file replaces the template and clears the fields, then opens the Match page.
 */
export default function UploadPage() {
  const { template, setTemplate } = useWorkspace();

  return (
    <section className="center-card">
      <h1>Upload a Word template</h1>
      <p className="muted">
        Design the form in Microsoft Word as usual: labels, tables, empty cells. No placeholders needed. Save it as <b>.docx</b> and
        upload it here.
      </p>
      <TemplateUploader
        onLoaded={(t) => {
          setTemplate(t);
          navigate('/match');
        }}
      />
      {template && (
        <p className="muted small">
          Current template: <b>{template.fileName}</b>. Uploading a new file starts over. <Link to="/match">Continue matching →</Link>
        </p>
      )}
    </section>
  );
}
