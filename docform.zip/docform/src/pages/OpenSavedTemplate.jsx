import TemplatePicker from '../features/database/TemplatePicker.jsx';
import { useWorkspace } from '../state/Workspace.jsx';
import { navigate } from '../router/hashRouter.jsx';

/**
 * Open a template version saved in MongoDB for editing (Match page, and the "No template yet" page).
 * Loads its original .docx and field map into the workspace, replacing the current work, and opens
 * the Match page. After changing fields, "Save changes" overwrites this version and "Save as new
 * version" keeps it and saves the next version (SaveTemplateButton).
 */
export default function OpenSavedTemplate({ label }) {
  const { setTemplate } = useWorkspace();
  return (
    <TemplatePicker
      withSource
      label={label}
      buttonText="Open"
      onPick={({ definition, template }) => {
        setTemplate(template, definition);
        navigate('/match');
      }}
    />
  );
}
