import { useMemo, useState } from 'react';
import FieldMapLoader from '../features/definition/FieldMapLoader.jsx';
import SubmissionParser from '../features/parse/SubmissionParser.jsx';
import TemplatePicker from '../features/database/TemplatePicker.jsx';
import SaveSubmissionButton from '../features/database/SaveSubmissionButton.jsx';
import { useWorkspace, hasFields } from '../state/Workspace.jsx';

/**
 * Page 4 (#/parse): read a client's filled file. Works without the earlier steps.
 *   1. optional field map: a .json file or a template saved in MongoDB  -> wins over everything
 *   2. client .docx  -> parsed in the browser with: the chosen map, else the map inside the file,
 *                       else the map being edited on the Match page
 *   3. save to MongoDB: the server parses the file again with the stored map and keeps it
 */
export default function ParsePage() {
  const { definition } = useWorkspace();
  const [fieldMap, setFieldMap] = useState(null); // { definition, fileName }
  const [last, setLast] = useState(null); // { result, fileName, bytes } of the latest parse
  // The field map being edited is only a last resort (files carry their own map).
  const fallback = useMemo(() => (hasFields(definition) ? definition : null), [definition]);

  return (
    <section className="center-card wide">
      <h1>Parse a client's filled file</h1>

      <h2 className="sub">1. Field map</h2>
      <p className="muted small">
        Load the field map JSON saved on the Match fields page, or a template saved in the database. Optional: templates made with
        this app also carry their field map inside the .docx, which is used when none is chosen.
      </p>
      <FieldMapLoader value={fieldMap} onChange={setFieldMap} />
      {!fieldMap && <TemplatePicker onPick={setFieldMap} />}

      <h2 className="sub">2. Client file</h2>
      <SubmissionParser
        definition={fieldMap && fieldMap.definition}
        fallbackDefinition={fallback}
        onParsed={(result, fileName, bytes) => setLast({ result, fileName, bytes })}
      />

      {last && (
        <>
          <h2 className="sub">3. Save to database</h2>
          <p className="muted small">
            The server reads the file again with the field map saved for {last.result.templateId || 'its template'}
            {last.result.version ? ` v${last.result.version}` : ''} and stores the values.
          </p>
          <SaveSubmissionButton
            key={`${last.fileName}|${last.result.templateId}|${last.result.version}|${last.result.definitionSource}`}
            bytes={last.bytes}
            fileName={last.fileName}
            result={last.result}
          />
        </>
      )}
    </section>
  );
}
