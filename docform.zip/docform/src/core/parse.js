/**
 * Reads a client's filled .docx back into JSON.
 *
 * Every value the client typed sits in a content control whose w:tag is the field key
 * (see generate.js). The parser collects all tagged controls, then checks them against the
 * field map: missing fields, required fields left empty, numbers that are not numbers,
 * dropdown values not in the list. Problems never stop the parse: they are listed in
 * `errors` and the result gets status "needs_review", so nothing the client wrote is lost.
 *
 * Pictures: `data` holds only the text of a field. Pictures inside fields (usually rich text) are
 * listed in `images` with the field they belong to; with { withImageBytes: true } each entry also
 * carries its bytes (the server stores them in GridFS). A field with only a picture counts as filled.
 */
import { NS, child, descendants, elements, wAttr, textOf } from './xml.js';
import { loadDocx } from './docx.js';
import { DEFINITION_NS } from './generate.js';
import { imageRelIds, readImageRels, imageContentType } from './images.js';

// Kinds of content control
/** The outer control of a repeating table (its tag is the table key). */
const isRepeating = (sdt) => {
  const pr = child(sdt, 'sdtPr');
  return !!(pr && child(pr, 'repeatingSection', NS.w15));
};
/** One row of a repeating table. */
const isRepeatingItem = (sdt) => {
  const pr = child(sdt, 'sdtPr');
  return !!(pr && child(pr, 'repeatingSectionItem', NS.w15));
};
/** The control's w:tag (= field key), '' when it has none. */
const tagOf = (sdt) => {
  const pr = child(sdt, 'sdtPr');
  return pr && child(pr, 'tag') ? wAttr(child(pr, 'tag'), 'val') : '';
};

/** True for column controls inside a repeating table (they are read per row, not as fixed fields). */
function insideRepeating(sdt) {
  for (let n = sdt.parentNode; n && n.nodeType === 1; n = n.parentNode) {
    if (n.namespaceURI === NS.w && n.localName === 'sdt' && isRepeating(n)) return true;
  }
  return false;
}

/**
 * Raw value the client entered; '' while the gray placeholder is still showing.
 * Dates come from w:fullDate (always ISO, whatever the display format), everything else is the text.
 */
function rawValue(sdt) {
  const pr = child(sdt, 'sdtPr');
  if (child(pr, 'showingPlcHdr')) return '';
  const date = child(pr, 'date');
  if (date && wAttr(date, 'fullDate')) return wAttr(date, 'fullDate').slice(0, 10);
  const content = child(sdt, 'sdtContent');
  return content ? textOf(content).trim() : '';
}

/** What the client put in a control: { text, images: [relationship id] }. Nothing while the placeholder shows. */
function cellOf(sdt) {
  const text = rawValue(sdt);
  const pr = child(sdt, 'sdtPr');
  const content = child(sdt, 'sdtContent');
  const images = child(pr, 'showingPlcHdr') || !content ? [] : imageRelIds(content);
  return { text, images };
}

const isEmpty = (cell) => cell.text === '' && !cell.images.length;

/** coerce() for a control's content: a field holding only a picture is filled (value ''). */
function check(spec, cell) {
  if (cell.text === '' && cell.images.length) return { value: '' };
  return coerce(spec, cell.text);
}

/** setPath(obj, 'client.name', 'Ann') -> obj.client.name = 'Ann' (dotted keys become nested objects). */
function setPath(obj, key, value) {
  const parts = key.split('.');
  let o = obj;
  for (const p of parts.slice(0, -1)) {
    if (typeof o[p] !== 'object' || o[p] === null) o[p] = {};
    o = o[p];
  }
  o[parts[parts.length - 1]] = value;
}

/** The field map stored in the file by generate.js (customXml part), or null. */
async function readEmbeddedDefinition(zip) {
  const files = zip.file(/^customXml\/item\d+\.xml$/);
  for (const f of files) {
    const xml = await f.async('string');
    if (!xml.includes(DEFINITION_NS)) continue;
    const m = xml.match(/<docform[^>]*>([\s\S]*)<\/docform>/);
    if (!m) continue;
    const json = m[1].replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
    try {
      return JSON.parse(json);
    } catch {
      return null;
    }
  }
  return null;
}

/**
 * Convert and check one value against its field spec. Returns { value, error }.
 *   ''           -> null (error when required)
 *   number       "1,200 $" -> 1200; error when not a number or outside min/max
 *   dropdown     error when the value is not one of `options`
 *   text/rich/date  unchanged string
 * On error the original value is still returned, so a reviewer can see what was typed.
 */
export function coerce(spec, raw) {
  if (raw === '') return spec.required ? { value: null, error: 'Required field is empty' } : { value: null };
  switch (spec.type) {
    case 'number': {
      const n = Number(raw.replace(/[\s,$€£¥₩]/g, ''));
      if (!Number.isFinite(n)) return { value: raw, error: `"${raw}" is not a number` };
      if (spec.min != null && spec.min !== '' && n < Number(spec.min)) return { value: n, error: `${n} is below the minimum ${spec.min}` };
      if (spec.max != null && spec.max !== '' && n > Number(spec.max)) return { value: n, error: `${n} is above the maximum ${spec.max}` };
      return { value: n };
    }
    case 'dropdown':
      if (spec.options && spec.options.length && !spec.options.includes(raw)) return { value: raw, error: `"${raw}" is not one of: ${spec.options.join(', ')}` };
      return { value: raw };
    default:
      return { value: raw };
  }
}

/**
 * Read a client's filled .docx and return a JSON object.
 * Which field map is used, in order:
 *   options.definition  a field map the user loaded (JSON), always wins
 *   the map embedded in the .docx when the template was published
 *   options.fallback    e.g. the field map currently being edited
 * With no map at all, every tagged value is returned as text, without checks.
 *
 * @param {Uint8Array|ArrayBuffer|Buffer} data  the filled .docx
 * @param {{ definition?: object, fallback?: object, withImageBytes?: boolean }} [options]
 *   definition / fallback: maps from readDefinition() or the editor; withImageBytes: add `bytes` to each image
 * @returns {Promise<{
 *   templateId, templateName, version,      // from the map that was used
 *   definitionSource: 'loaded'|'embedded'|'fallback'|'none',
 *   status: 'ok'|'needs_review',            // needs_review when errors is not empty
 *   errors: [{ field, message }],           // field e.g. "budget" or "projectMembers[1].age"
 *   warnings: [string],
 *   data: { [key]: value, [tableKey]: [{ [columnKey]: value }] },
 *   images: [{ field, fileName, contentType, size, path, bytes? }]   // field like errors; path = file in the zip
 * }>}
 */
export async function parseSubmission(data, options = {}) {
  const { zip, doc } = await loadDocx(data);
  const embedded = await readEmbeddedDefinition(zip);
  const loaded = options.definition || null;
  const def = loaded || embedded || options.fallback || null;
  const source = loaded ? 'loaded' : embedded ? 'embedded' : def ? 'fallback' : 'none';
  const errors = [];
  const warnings = [];
  if (loaded && embedded && (loaded.templateId !== embedded.templateId || String(loaded.version) !== String(embedded.version))) {
    warnings.push(
      `This file was made from template "${embedded.templateId}" v${embedded.version}, but the loaded field map is "${loaded.templateId}" v${loaded.version}. Fields that don't match are reported as missing.`,
    );
  }

  // Pass 1: collect content by tag (cell = { text, images }). fixedRaw: key -> cell; groupRaw: tableKey -> [Map(columnKey -> cell)]
  const fixedRaw = new Map();
  const groupRaw = new Map();
  for (const sdt of descendants(doc, 'sdt')) {
    const tag = tagOf(sdt);
    if (isRepeating(sdt)) {
      const rows = [];
      for (const item of elements(child(sdt, 'sdtContent')).filter((n) => n.localName === 'sdt' && isRepeatingItem(n))) {
        const row = new Map();
        for (const inner of descendants(item, 'sdt')) {
          const t = tagOf(inner);
          if (t) row.set(t, cellOf(inner));
        }
        rows.push(row);
      }
      if (groupRaw.has(tag)) errors.push({ field: tag, message: 'Table appears more than once in the document' });
      groupRaw.set(tag, rows);
    } else if (tag && !isRepeatingItem(sdt) && !insideRepeating(sdt)) {
      if (fixedRaw.has(tag)) errors.push({ field: tag, message: 'Field appears more than once (copied from another document?)' });
      else fixedRaw.set(tag, cellOf(sdt));
    }
  }

  // Pass 2: build `data` from the field map (types, required, missing), or as plain text without one
  const data_ = {};
  const found = []; // [{ field, rel }]: pictures of the fields that are returned
  const addImages = (field, cell) => cell.images.forEach((rel) => found.push({ field, rel }));
  if (!def) {
    warnings.push('No template definition found: values are returned as text without checks.');
    for (const [k, cell] of fixedRaw) {
      setPath(data_, k, cell.text);
      addImages(k, cell);
    }
    for (const [k, rows] of groupRaw) {
      const out = rows.map((r, i) => {
        const obj = {};
        for (const [col, cell] of r) {
          obj[col] = cell.text;
          addImages(`${k}[${i}].${col}`, cell);
        }
        return obj;
      });
      setPath(data_, k, out);
    }
  } else {
    for (const f of def.fields) {
      if (!fixedRaw.has(f.key)) {
        errors.push({ field: f.key, message: 'Field is missing from the document (deleted or not filled in Word?)' });
        setPath(data_, f.key, null);
        continue;
      }
      const cell = fixedRaw.get(f.key);
      const { value, error } = check(f, cell);
      if (error) errors.push({ field: f.key, message: error });
      setPath(data_, f.key, value);
      addImages(f.key, cell);
    }
    for (const g of def.groups || []) {
      const rows = groupRaw.get(g.key);
      if (!rows) {
        errors.push({ field: g.key, message: 'Table is missing from the document' });
        setPath(data_, g.key, []);
        continue;
      }
      const out = [];
      rows.forEach((row) => {
        if ([...row.values()].every(isEmpty)) return; // untouched row
        const obj = {};
        for (const col of g.columns) {
          const cell = row.get(col.key) || { text: '', images: [] };
          const field = `${g.key}[${out.length}].${col.key}`;
          const { value, error } = check(col, cell);
          if (error) errors.push({ field, message: error });
          setPath(obj, col.key, value);
          addImages(field, cell);
        }
        out.push(obj);
      });
      setPath(data_, g.key, out);
    }
    const known = new Set(def.fields.map((f) => f.key));
    for (const k of fixedRaw.keys()) if (!known.has(k)) warnings.push(`Unknown field "${k}" ignored.`);
  }

  // Pass 3: the picture files of those fields
  const rels = found.length ? await readImageRels(zip) : new Map();
  const images = [];
  for (const { field, rel } of found) {
    const path = rels.get(rel);
    const file = path && zip.file(path);
    if (!file) continue; // linked (not embedded) picture, or a broken reference
    const bytes = await file.async('uint8array');
    const fileName = path.split('/').pop();
    const image = { field, fileName, contentType: imageContentType(fileName), size: bytes.length, path };
    if (options.withImageBytes) image.bytes = bytes;
    images.push(image);
  }

  return {
    templateId: def ? def.templateId : null,
    templateName: def ? def.name : null,
    version: def ? def.version : null,
    definitionSource: source,
    status: errors.length ? 'needs_review' : 'ok',
    errors,
    warnings,
    data: data_,
    images,
  };
}
