/**
 * Builds the client template: the manager's .docx with each linked input area turned into
 * a Word content control (w:sdt) whose w:tag is the field key.
 *
 * What a fixed field becomes:
 *   <w:sdt>
 *     <w:sdtPr>
 *       <w:alias w:val="Title"/>          label shown by Word on the control
 *       <w:tag w:val="title"/>            field key: how the parser finds the value
 *       <w:lock w:val="sdtLocked"/>       client can type in it but not delete it
 *       <w:showingPlcHdr/>                gray placeholder is showing (= still empty)
 *       <w:text/> | <w:date/> | <w:dropDownList/> | (nothing for rich text)
 *     </w:sdtPr>
 *     <w:sdtContent>…placeholder run…</w:sdtContent>
 *   </w:sdt>
 *
 * A repeating table wraps the input row in a Word 2013 repeating section
 * (w15:repeatingSection > w15:repeatingSectionItem > w:tr); Word shows a + button to add rows.
 *
 * The field map is also stored inside the file (customXml part), so a returned file can be
 * parsed even without the separate .json.
 */
import { NS, child, children, descendants, elements, wAttr, wEl, w15El, textOf, serializeXml, parseXml } from './xml.js';
import { loadDocx, resolvePara, resolveRow, pathKey } from './docx.js';
import { exportDefinition } from './definition.js';

/** XML namespace of the embedded field map part; parse.js looks for it. */
export const DEFINITION_NS = 'urn:docform:template:1';

/** Gray text shown in an empty control when the input area had no text of its own. */
const PLACEHOLDERS = {
  text: 'Enter text',
  rich: 'Write text.',
  number: 'Enter number',
  date: 'Select date',
  dropdown: 'Choose an item',
};

/** Date picker display format; Word also stores the picked date as w:fullDate (ISO). */
const DATE_FORMAT = 'yyyy-MM-dd';

// crypto.randomUUID is unavailable on plain-http LAN pages, so build the GUID ourselves.
const guid = () =>
  '{' + 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.floor(Math.random() * 16);
    return (c === 'x' ? r : (r & 3) | 8).toString(16).toUpperCase();
  }) + '}';

/** Returns a function giving w:id values not yet used in the document (Word needs them unique). */
function newIdFactory(doc) {
  const used = new Set(descendants(doc, 'id').map((e) => wAttr(e, 'val')));
  return () => {
    let id;
    do id = String(100000000 + Math.floor(Math.random() * 1900000000));
    while (used.has(id));
    used.add(id);
    return id;
  };
}

/** Formatting (font, size, …) of the first run in a paragraph, so the control keeps the look. */
function firstRunProps(p) {
  const r = descendants(p, 'rPr').find((e) => e.parentNode && e.parentNode.localName === 'r');
  if (r) return r;
  const pPr = child(p, 'pPr');
  return pPr ? child(pPr, 'rPr') : null;
}

/** Copy of run properties without tracked-change marks (an empty w:rPr when there are none). */
function cloneRunProps(doc, rPr) {
  const copy = rPr ? rPr.cloneNode(true) : wEl(doc, 'rPr');
  // rPr inside pPr may hold paragraph-mark-only children; drop revision marks
  for (const n of elements(copy)) if (['ins', 'del', 'rPrChange'].includes(n.localName)) copy.removeChild(n);
  return copy;
}

/** The gray placeholder text run shown inside an empty control. */
function placeholderRun(doc, text, rPr) {
  const props = cloneRunProps(doc, rPr);
  for (const c of children(props, 'color')) props.removeChild(c);
  props.appendChild(wEl(doc, 'color', { val: '808080' }));
  const t = wEl(doc, 't');
  t.setAttributeNS(NS.xml, 'xml:space', 'preserve');
  t.appendChild(doc.createTextNode(text));
  return wEl(doc, 'r', {}, [props, t]);
}

/**
 * <w:sdtPr> for a field: alias, tag (= key), id, lock, placeholder flag and the type element.
 * @param spec  field or column from the definition ({ key, label, type, options })
 */
function sdtProps(doc, spec, rPr, newId) {
  const pr = wEl(doc, 'sdtPr');
  if (rPr) pr.appendChild(cloneRunProps(doc, rPr));
  pr.appendChild(wEl(doc, 'alias', { val: spec.label || spec.key }));
  pr.appendChild(wEl(doc, 'tag', { val: spec.key }));
  pr.appendChild(wEl(doc, 'id', { val: newId() }));
  pr.appendChild(wEl(doc, 'lock', { val: 'sdtLocked' })); // control can't be deleted, content stays editable
  pr.appendChild(wEl(doc, 'showingPlcHdr'));
  if (spec.type === 'text' || spec.type === 'number') pr.appendChild(wEl(doc, 'text', { multiLine: '1' }));
  if (spec.type === 'dropdown') {
    pr.appendChild(wEl(doc, 'dropDownList', {}, (spec.options || []).map((o) => wEl(doc, 'listItem', { displayText: o, value: o }))));
  }
  if (spec.type === 'date') {
    pr.appendChild(
      wEl(doc, 'date', {}, [
        wEl(doc, 'dateFormat', { val: DATE_FORMAT }),
        wEl(doc, 'lid', { val: 'en-US' }),
        wEl(doc, 'storeMappedDataAs', { val: 'dateTime' }),
        wEl(doc, 'calendar', { val: 'gregorian' }),
      ]),
    );
  }
  // type 'rich': no type element = rich text control
  return pr;
}

/** Placeholder = the text already in the input area (e.g. "Write the goals here"), else a default. */
function placeholderText(spec, paras) {
  const original = paras.map((p) => textOf(p).trim()).filter(Boolean).join(' ');
  return original || PLACEHOLDERS[spec.type] || PLACEHOLDERS.text;
}

/** Replace the content of one paragraph with a run-level content control. */
function inlineControl(doc, p, spec, newId) {
  const placeholder = placeholderText(spec, [p]);
  const rPr = firstRunProps(p);
  const rPrCopy = rPr ? cloneRunProps(doc, rPr) : null;
  for (const n of elements(p)) if (n.localName !== 'pPr' || n.namespaceURI !== NS.w) p.removeChild(n);
  const sdt = wEl(doc, 'sdt', {}, [sdtProps(doc, spec, rPrCopy, newId), wEl(doc, 'sdtContent', {}, [placeholderRun(doc, placeholder, rPrCopy)])]);
  p.appendChild(sdt);
}

/** Replace consecutive paragraphs with one block-level rich text control. */
function blockControl(doc, paras, spec, newId) {
  const placeholder = placeholderText(spec, paras);
  const first = paras[0];
  const rPr = firstRunProps(first);
  const rPrCopy = rPr ? cloneRunProps(doc, rPr) : null;
  const newP = wEl(doc, 'p');
  const pPr = child(first, 'pPr');
  if (pPr) newP.appendChild(pPr.cloneNode(true));
  newP.appendChild(placeholderRun(doc, placeholder, rPrCopy));
  const sdt = wEl(doc, 'sdt', {}, [sdtProps(doc, spec, rPrCopy, newId), wEl(doc, 'sdtContent', {}, [newP])]);
  first.parentNode.insertBefore(sdt, first);
  for (const p of paras) p.parentNode.removeChild(p);
}

/** Rich text needs a block control (may hold paragraphs); every other type is inline. */
function makeControl(doc, paras, spec, newId) {
  if (spec.type === 'rich') blockControl(doc, paras, spec, newId);
  else inlineControl(doc, paras[0], spec, newId);
}

/**
 * Declare the w15 namespace and list it in mc:Ignorable, so Word 2013+ understands repeating
 * sections and older Word versions safely ignore them instead of reporting a damaged file.
 */
function ensureW15(doc) {
  const root = doc.documentElement;
  if (!root.getAttribute('xmlns:w15')) root.setAttributeNS(NS.xmlns, 'xmlns:w15', NS.w15);
  const ign = root.getAttributeNS(NS.mc, 'Ignorable');
  if (root.getAttribute('xmlns:mc') && !ign.split(/\s+/).includes('w15')) {
    root.setAttributeNS(NS.mc, 'mc:Ignorable', `${ign} w15`.trim());
  }
}

const escapeXml = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/**
 * Store the definition inside the .docx as a custom XML part, so returned files describe themselves.
 * Adds four things to the package:
 *   customXml/itemN.xml               <docform xmlns="urn:docform:template:1">{…field map JSON…}</docform>
 *   customXml/itemPropsN.xml          the part's properties (Word requires them)
 *   customXml/_rels/itemN.xml.rels    links item -> itemProps
 *   a relationship in word/_rels/document.xml.rels and a content type in [Content_Types].xml
 * Word normally keeps custom XML parts when the client saves, so the map comes back with the file
 * (if it is lost, load the .fields.json on the Parse page instead).
 */
async function embedDefinition(zip, def) {
  let n = 1;
  while (zip.file(`customXml/item${n}.xml`)) n++;
  zip.file(
    `customXml/item${n}.xml`,
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<docform xmlns="${DEFINITION_NS}">${escapeXml(JSON.stringify(def))}</docform>`,
  );
  zip.file(
    `customXml/itemProps${n}.xml`,
    `<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n<ds:datastoreItem ds:itemID="${guid()}" xmlns:ds="http://schemas.openxmlformats.org/officeDocument/2006/customXml"><ds:schemaRefs><ds:schemaRef ds:uri="${DEFINITION_NS}"/></ds:schemaRefs></ds:datastoreItem>`,
  );
  zip.file(
    `customXml/_rels/item${n}.xml.rels`,
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXmlProps" Target="itemProps${n}.xml"/></Relationships>`,
  );

  const relsPath = 'word/_rels/document.xml.rels';
  const rels = parseXml(await zip.file(relsPath).async('string'));
  const ids = new Set(Array.from({ length: rels.documentElement.childNodes.length }, (_, i) => rels.documentElement.childNodes[i]).filter((x) => x.nodeType === 1).map((x) => x.getAttribute('Id')));
  let rid = 1;
  while (ids.has(`rIdDocform${rid}`)) rid++;
  const rel = rels.createElementNS('http://schemas.openxmlformats.org/package/2006/relationships', 'Relationship');
  rel.setAttribute('Id', `rIdDocform${rid}`);
  rel.setAttribute('Type', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml');
  rel.setAttribute('Target', `../customXml/item${n}.xml`);
  rels.documentElement.appendChild(rel);
  zip.file(relsPath, serializeXml(rels));

  const ctPath = '[Content_Types].xml';
  const ct = parseXml(await zip.file(ctPath).async('string'));
  const ctNs = 'http://schemas.openxmlformats.org/package/2006/content-types';
  const items = Array.from(ct.documentElement.getElementsByTagNameNS(ctNs, 'Default'));
  if (!items.some((d) => d.getAttribute('Extension') === 'xml')) {
    const d = ct.createElementNS(ctNs, 'Default');
    d.setAttribute('Extension', 'xml');
    d.setAttribute('ContentType', 'application/xml');
    ct.documentElement.insertBefore(d, ct.documentElement.firstChild);
  }
  const o = ct.createElementNS(ctNs, 'Override');
  o.setAttribute('PartName', `/customXml/itemProps${n}.xml`);
  o.setAttribute('ContentType', 'application/vnd.openxmlformats-officedocument.customXmlProperties+xml');
  ct.documentElement.appendChild(o);
  zip.file(ctPath, serializeXml(ct));
}

/**
 * Apply a definition to the manager's uploaded .docx.
 * definition = { templateId, name, version, fields: [...], groups: [...] }
 *   field: { key, label, type, required, options, min, max, unit, labelPath, targetPaths: [paragraph paths] }
 *   group: { key, label, headerRow: [i, r], removeSampleRows, columns: [{ key, label, type, required, options, cell }] }
 *
 * Steps:
 *   1. resolve every path to its element and check no two fields share an input area
 *      (done first: changing the document would shift the positions)
 *   2. turn each fixed field's paragraphs into a content control
 *   3. for each group: make a control in each column cell of the input row, wrap the row in a
 *      repeating section, and delete the manager's sample rows when asked
 *   4. embed the field map, drop zip folder entries, zip it again
 *
 * @param {Uint8Array|ArrayBuffer|Buffer} data  the manager's original .docx (not a generated one)
 * @returns {Promise<Uint8Array>}  the template .docx to send to clients
 * @throws Error with a readable message when a path no longer matches the file or areas overlap
 */
export async function generateTemplate(data, definition) {
  const { zip, doc } = await loadDocx(data);
  const newId = newIdFactory(doc);

  // Resolve every target before changing anything (changes shift indices).
  const used = new Map();
  const claim = (path, owner) => {
    const k = pathKey(path);
    if (used.has(k)) throw new Error(`"${owner}" and "${used.get(k)}" use the same input area.`);
    used.set(k, owner);
  };
  const fixed = definition.fields.map((f) => {
    f.targetPaths.forEach((p) => claim(p, f.key));
    const paras = f.targetPaths.map((p) => resolvePara(doc, p));
    if (!paras.length || paras.some((p) => !p)) throw new Error(`Field "${f.key}": input area not found in the document.`);
    return { f, paras };
  });
  const groups = (definition.groups || []).map((g) => {
    const header = resolveRow(doc, g.headerRow);
    const template = resolveRow(doc, [g.headerRow[0], g.headerRow[1] + 1]);
    if (!header || !template) throw new Error(`Group "${g.key}": table rows not found.`);
    const tbl = template.parentNode;
    const cells = children(template, 'tc');
    const extras = []; // sample rows to delete: following rows with the same number of cells
    if (g.removeSampleRows) {
      for (let n = template.nextSibling; n; n = n.nextSibling) {
        if (n.nodeType !== 1) continue;
        if (n.localName !== 'tr' || children(n, 'tc').length !== cells.length) break;
        extras.push(n);
      }
    }
    const cols = g.columns.map((col) => {
      const tc = cells[col.cell];
      if (!tc) throw new Error(`Group "${g.key}": column "${col.key}" has no cell in the input row.`);
      claim([g.headerRow[0], g.headerRow[1] + 1, col.cell, 0], `${g.key}.${col.key}`);
      return { col, paras: children(tc, 'p') };
    });
    return { g, tbl, template, extras, cols };
  });

  // 2. fixed fields
  for (const { f, paras } of fixed) makeControl(doc, paras, f, newId);

  // 3. repeating tables: <w:tbl> … <w:sdt repeatingSection><w:sdt repeatingSectionItem><w:tr/>…
  ensureW15(doc);
  for (const { g, tbl, template, extras, cols } of groups) {
    for (const { col, paras } of cols) makeControl(doc, paras, col, newId);
    const item = wEl(doc, 'sdt', {}, [wEl(doc, 'sdtPr', {}, [wEl(doc, 'id', { val: newId() }), w15El(doc, 'repeatingSectionItem')]), wEl(doc, 'sdtContent')]);
    const section = wEl(doc, 'sdt', {}, [
      wEl(doc, 'sdtPr', {}, [
        wEl(doc, 'alias', { val: g.label || g.key }),
        wEl(doc, 'tag', { val: g.key }),
        wEl(doc, 'id', { val: newId() }),
        wEl(doc, 'lock', { val: 'sdtLocked' }),
        w15El(doc, 'repeatingSection'),
      ]),
      wEl(doc, 'sdtContent', {}, [item]),
    ]);
    tbl.insertBefore(section, template);
    child(item, 'sdtContent').appendChild(template);
    for (const r of extras) tbl.removeChild(r);
  }

  // 4. write back and embed the field map
  zip.file('word/document.xml', serializeXml(doc));
  await embedDefinition(zip, exportDefinition(definition));
  // JSZip adds folder entries; Word can refuse files that contain them.
  // (zip.remove() on a folder would delete its files too, so drop only the folder entries)
  for (const [name, entry] of Object.entries(zip.files)) if (entry.dir) delete zip.files[name];
  return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE' });
}
