/**
 * XML helpers for WordprocessingML (the XML inside a .docx).
 *
 * Uses @xmldom/xmldom so the same code runs in the browser and in Node (no DOM needed).
 * Word elements live in the "w" namespace, so every lookup here is namespace-aware:
 * `child(p, 'r')` means "the first direct <w:r> child of p".
 */
import { DOMParser, XMLSerializer } from '@xmldom/xmldom';

/** Namespace URIs used by the app. */
export const NS = {
  w: 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
  w15: 'http://schemas.microsoft.com/office/word/2012/wordml',
  mc: 'http://schemas.openxmlformats.org/markup-compatibility/2006',
  xml: 'http://www.w3.org/XML/1998/namespace',
  xmlns: 'http://www.w3.org/2000/xmlns/',
};

/** XML text -> DOM Document. */
export const parseXml = (text) => new DOMParser().parseFromString(text, 'text/xml');
/** DOM Document -> XML text (written back into the zip). */
export const serializeXml = (doc) => new XMLSerializer().serializeToString(doc);

// xmldom NodeLists are not iterable in every environment, so copy them into arrays.
const toArray = (list) => {
  const out = [];
  for (let i = 0; i < list.length; i++) out.push(list[i]);
  return out;
};

/** Direct child elements (skips text, comments, whitespace). */
export const elements = (el) => toArray(el.childNodes).filter((n) => n.nodeType === 1);
/** Direct children with a given local name, e.g. children(tbl, 'tr') = the table's rows. */
export const children = (el, local, ns = NS.w) =>
  elements(el).filter((n) => n.namespaceURI === ns && n.localName === local);
/** First direct child with that name, or null. */
export const child = (el, local, ns = NS.w) => children(el, local, ns)[0] || null;
/** All descendants with that name, at any depth, in document order. */
export const descendants = (el, local, ns = NS.w) => toArray(el.getElementsByTagNameNS(ns, local));
/** True when el is the Word element <w:local>. */
export const isW = (el, local) => el && el.nodeType === 1 && el.namespaceURI === NS.w && el.localName === local;
/** Value of the w:name attribute ('' when missing or el is null). */
export const wAttr = (el, name) => (el ? el.getAttributeNS(NS.w, name) || '' : '');

/**
 * Create a w: element with w: attributes and children.
 *   wEl(doc, 'tag', { val: 'title' })  ->  <w:tag w:val="title"/>
 */
export function wEl(doc, local, attrs = {}, kids = []) {
  const el = doc.createElementNS(NS.w, `w:${local}`);
  for (const [k, v] of Object.entries(attrs)) el.setAttributeNS(NS.w, `w:${k}`, String(v));
  for (const k of kids) el.appendChild(k);
  return el;
}

/** Create a w15: element (Word 2013 extensions such as repeating sections). */
export function w15El(doc, local) {
  return doc.createElementNS(NS.w15, `w15:${local}`);
}

/**
 * Plain text of an element, as the client would read it:
 * <w:t> text, <w:tab/> -> "\t", <w:br/>/<w:cr/> -> "\n", and one "\n" between paragraphs.
 * Used to read values out of content controls and to build placeholder text.
 */
export function textOf(el) {
  let out = '';
  const walk = (node) => {
    for (const n of elements(node)) {
      if (isW(n, 't')) out += n.textContent;
      else if (isW(n, 'tab')) out += '\t';
      else if (isW(n, 'br') || isW(n, 'cr')) out += '\n';
      else if (isW(n, 'p')) {
        if (out && !out.endsWith('\n')) out += '\n';
        walk(n);
      } else walk(n);
    }
  };
  walk(el);
  return out;
}
