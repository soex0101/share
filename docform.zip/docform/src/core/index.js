/**
 * DocForm core: everything that reads or writes .docx files. No React, no browser APIs,
 * so it runs in the browser and, bundled to CommonJS by `npm run build` (dist-core/), in the Node server.
 *
 *   buildPreview / suggestTargets / describeGroupRow   Match page: understand the uploaded template
 *   generateTemplate                                   Match page save: write the tagged template
 *   exportDefinition / readDefinition                  field map JSON (save / load / validate)
 *   parseSubmission                                    Parse page: filled .docx -> JSON
 */
export { loadDocx, pathKey } from './docx.js';
export { buildPreview, suggestTargets, describeGroupRow } from './preview.js';
export { generateTemplate } from './generate.js';
export { exportDefinition, readDefinition, DEFINITION_FORMAT } from './definition.js';
export { parseSubmission } from './parse.js';
export { keyFromLabel, uniqueKey, KEY_RE, FIELD_TYPES } from './keys.js';
