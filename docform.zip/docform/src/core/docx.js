/**
 * Opening a .docx and finding things in it by position.
 *
 * A .docx is a zip file; the visible document is word/document.xml. The app refers to
 * paragraphs and table rows by their position ("paths", see below) instead of by text, so
 * a field stays linked even when two labels have the same wording.
 */
import JSZip from 'jszip';
import { parseXml, child, children, elements, isW } from './xml.js';

/**
 * Open a .docx.
 * @param {Uint8Array|ArrayBuffer|Buffer} data  file bytes (browser File bytes or a Node Buffer)
 * @returns {Promise<{ zip: JSZip, doc: Document }>}  the zip (to read/write other parts) and the parsed document.xml
 * @throws when the file is not a zip or has no word/document.xml (e.g. an old .doc or a renamed file)
 */
export async function loadDocx(data) {
  const zip = await JSZip.loadAsync(data);
  const file = zip.file('word/document.xml');
  if (!file) throw new Error('Not a Word .docx file (word/document.xml missing).');
  const doc = parseXml(await file.async('string'));
  return { zip, doc };
}

/** The <w:body> element (holds the top-level paragraphs and tables). */
export const getBody = (doc) => child(doc.documentElement, 'body');

/**
 * Paragraph paths (all indexes start at 0):
 *   [i]          -> i-th element of <w:body>, a paragraph
 *   [i, r, c, k] -> body element i is a table; row r, cell c, paragraph k (direct children only)
 * Row paths: [i, r]
 *
 * Example: [0, 5, 2, 0] = first table in the body, 6th row, 3rd cell, first paragraph.
 * Paths are only valid for the original uploaded file: generating the template moves
 * elements around, so all paths are resolved *before* the document is changed.
 */

/** i-th element of the body (paragraph, table, or section properties), or null. */
export function resolveBlock(doc, i) {
  return elements(getBody(doc))[i] || null;
}

/** Row path [i, r] -> <w:tr>, or null when body element i is not a table. */
export function resolveRow(doc, [i, r]) {
  const tbl = resolveBlock(doc, i);
  if (!isW(tbl, 'tbl')) return null;
  return children(tbl, 'tr')[r] || null;
}

/** Paragraph path ([i] or [i, r, c, k]) -> <w:p>, or null when it does not exist. */
export function resolvePara(doc, path) {
  if (path.length === 1) {
    const p = resolveBlock(doc, path[0]);
    return isW(p, 'p') ? p : null;
  }
  const [i, r, c, k] = path;
  const tr = resolveRow(doc, [i, r]);
  const tc = tr && children(tr, 'tc')[c];
  return (tc && children(tc, 'p')[k]) || null;
}

/** Path as a string, for Map keys: [0, 5, 2, 0] -> "0.5.2.0". */
export const pathKey = (path) => path.join('.');
