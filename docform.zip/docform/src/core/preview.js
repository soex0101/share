/**
 * A light, JSON-like model of the uploaded template, used by the Match page to draw the
 * document and to guess where the client is meant to write for each label.
 *
 * Preview shape:
 *   {
 *     blocks: [
 *       { type: 'p', index, para },
 *       { type: 'table', index, rows: [{ r, path: [i, r], cells: [{ c, col, span, vMerge, width, rowSpan, paras: [para] }] }] }
 *     ],
 *     paras: Map(pathKey -> { para, block, row?, cell? })   // fast lookup for a clicked paragraph
 *   }
 *   para = { path, key, runs: [{ text, b, i, u }], text, align }
 */
import { child, children, elements, isW, wAttr, descendants } from './xml.js';
import { getBody, pathKey } from './docx.js';

/** One paragraph: its text split into runs with bold/italic/underline, and its alignment. */
function paraInfo(p, path) {
  const runs = [];
  for (const r of descendants(p, 'r')) {
    const rPr = child(r, 'rPr');
    const fmt = {
      b: !!(rPr && child(rPr, 'b') && wAttr(child(rPr, 'b'), 'val') !== '0'),
      i: !!(rPr && child(rPr, 'i') && wAttr(child(rPr, 'i'), 'val') !== '0'),
      u: !!(rPr && child(rPr, 'u') && wAttr(child(rPr, 'u'), 'val') !== 'none'),
    };
    let text = '';
    for (const n of elements(r)) {
      if (isW(n, 't')) text += n.textContent;
      else if (isW(n, 'tab')) text += '\t';
      else if (isW(n, 'br')) text += '\n';
    }
    if (text) runs.push({ text, ...fmt });
  }
  const pPr = child(p, 'pPr');
  const jc = pPr && child(pPr, 'jc');
  return { path, key: pathKey(path), runs, text: runs.map((r) => r.text).join(''), align: jc ? wAttr(jc, 'val') : '' };
}

/**
 * One table. For each cell:
 *   c       index of the <w:tc> inside its row (used in paths)
 *   col     grid column where the cell starts (differs from c when cells span columns)
 *   span    number of grid columns (w:gridSpan)
 *   vMerge  'restart' | 'continue' | null  (vertically merged cells)
 *   width   width in twips (dxa), when given
 *   rowSpan rows covered, computed from vMerge below
 */
function tableInfo(tbl, i) {
  const rows = children(tbl, 'tr').map((tr, r) => {
    let col = 0; // grid column of the next cell
    const cells = children(tr, 'tc').map((tc, c) => {
      const tcPr = child(tc, 'tcPr');
      const gs = tcPr && child(tcPr, 'gridSpan');
      const vm = tcPr && child(tcPr, 'vMerge');
      const tcW = tcPr && child(tcPr, 'tcW');
      const span = gs ? parseInt(wAttr(gs, 'val'), 10) || 1 : 1;
      const cell = {
        c,
        col,
        span,
        vMerge: vm ? wAttr(vm, 'val') || 'continue' : null,
        width: tcW && wAttr(tcW, 'type') === 'dxa' ? parseInt(wAttr(tcW, 'w'), 10) : null,
        rowSpan: 1,
        paras: children(tc, 'p').map((p, k) => paraInfo(p, [i, r, c, k])),
      };
      col += span;
      return cell;
    });
    return { r, path: [i, r], cells };
  });
  // vertical merges -> rowSpan on the restart cell
  rows.forEach((row, r) => {
    for (const cell of row.cells) {
      if (cell.vMerge !== 'restart') continue;
      for (let rr = r + 1; rr < rows.length; rr++) {
        const below = rows[rr].cells.find((x) => x.col === cell.col);
        if (below && below.vMerge === 'continue') cell.rowSpan++;
        else break;
      }
    }
  });
  return { type: 'table', index: i, rows };
}

/**
 * Lightweight model of the document for rendering and click-to-link.
 * @param {Document} doc  parsed word/document.xml (from loadDocx)
 * @returns {{ blocks: Array, paras: Map }}  see the shape at the top of this file
 */
export function buildPreview(doc) {
  const blocks = [];
  elements(getBody(doc)).forEach((el, i) => {
    if (isW(el, 'p')) blocks.push({ type: 'p', index: i, para: paraInfo(el, [i]) });
    else if (isW(el, 'tbl')) blocks.push(tableInfo(el, i));
  });
  const paras = new Map();
  for (const b of blocks) {
    if (b.type === 'p') paras.set(b.para.key, { para: b.para, block: b });
    else
      for (const row of b.rows)
        for (const cell of row.cells)
          for (const para of cell.paras) paras.set(para.key, { para, block: b, row, cell });
  }
  return { blocks, paras };
}

const nonEmpty = (p) => p.text.trim() !== '';

/**
 * Candidate input areas for a clicked label paragraph.
 * Returns [{ mode, title, paths }] in order of likelihood (first = suggested):
 *   below-text  the paragraph(s) right after the label in the same cell / body
 *               (a run of non-empty paragraphs is taken together, for rich text answers)
 *   right       the cell to the right of the label cell            ("Name: | ______ |")
 *   below-cell  the cell under the label cell, skipping merged cells ("Name" / "______")
 *   self        the clicked paragraph itself (label replaced by the input)
 * `paths` are the paragraph paths that become the input area.
 */
export function suggestTargets(preview, labelPath) {
  const entry = preview.paras.get(pathKey(labelPath));
  if (!entry) return [];
  const out = [];
  let siblings;
  if (entry.cell) siblings = entry.cell.paras;
  else siblings = preview.blocks.filter((b) => b.type === 'p').map((b) => b.para);
  const idx = siblings.findIndex((p) => p.key === entry.para.key);
  const next = siblings[idx + 1];
  // only text that directly follows the label inside the same container
  if (next && (entry.cell || next.path[0] === entry.para.path[0] + 1)) {
    const paths = [next.path];
    if (nonEmpty(next)) {
      for (let j = idx + 2; j < siblings.length && nonEmpty(siblings[j]); j++) {
        if (!entry.cell && siblings[j].path[0] !== siblings[j - 1].path[0] + 1) break;
        paths.push(siblings[j].path);
      }
    }
    out.push({ mode: 'below-text', title: 'Text below', paths });
  }
  if (entry.cell) {
    const right = entry.row.cells[entry.cell.c + 1];
    if (right && right.vMerge !== 'continue') out.push({ mode: 'right', title: 'Cell right', paths: right.paras.map((p) => p.path) });
    const rows = entry.block.rows;
    for (let rr = entry.row.r + entry.cell.rowSpan; rr < rows.length; rr++) {
      const below = rows[rr].cells.find((x) => x.col === entry.cell.col);
      if (below && below.vMerge !== 'continue') {
        out.push({ mode: 'below-cell', title: 'Cell below', paths: below.paras.map((p) => p.path) });
        break;
      }
      if (!below) break;
    }
  }
  out.push({ mode: 'self', title: 'Replace label', paths: [labelPath] });
  return out;
}

/**
 * Header-row info for making a repeating table from a table row.
 * The clicked row is the header; the row under it becomes the row the client repeats.
 * @param preview  from buildPreview
 * @param rowPath  [i, r] of the header row
 * @returns {null | {
 *   header, template,   // preview rows: header row and the row to repeat
 *   sampleRows,         // rows after `template` with the same cell count (example rows the manager typed)
 *   title,              // text of a one-cell row just above the header, used as the table name
 *   columns: [{ cell, label, ok }]   // ok = the repeat row has a cell under this header cell
 * }}
 */
export function describeGroupRow(preview, rowPath) {
  const block = preview.blocks.find((b) => b.type === 'table' && b.index === rowPath[0]);
  if (!block) return null;
  const header = block.rows[rowPath[1]];
  const template = block.rows[rowPath[1] + 1];
  if (!header || !template) return null;
  let sampleRows = 0;
  for (let rr = rowPath[1] + 2; rr < block.rows.length; rr++) {
    if (block.rows[rr].cells.length !== template.cells.length) break;
    sampleRows++;
  }
  const prev = block.rows[rowPath[1] - 1];
  const title = prev && prev.cells.length === 1 ? prev.cells[0].paras.map((p) => p.text).join(' ').trim() : '';
  return {
    header,
    template,
    sampleRows,
    title,
    columns: header.cells.map((cell) => ({
      cell: cell.c,
      label: cell.paras.map((p) => p.text).join(' ').trim(),
      ok: cell.c < template.cells.length,
    })),
  };
}
