/**
 * The field map ("definition") as a portable JSON object.
 * Written on the Match page, embedded in published templates, loaded on the Parse page.
 *
 * {
 *   format: "docform.definition", formatVersion: 1,
 *   templateId, name, version,
 *   fields: [{ key, label, type, required, options?, min?, max?, unit?, labelPath?, targetPaths? }],
 *   groups: [{ key, label, headerRow?, removeSampleRows?, sampleRows?,
 *              columns: [{ key, label, type, required, options?, cell? }] }]
 * }
 * Document positions (labelPath, targetPaths, headerRow, cell) describe where each field sits in the
 * manager's original .docx; parsing only needs keys and types.
 */
import { FIELD_TYPES, KEY_RE } from './keys.js';

export const DEFINITION_FORMAT = 'docform.definition';
export const DEFINITION_FORMAT_VERSION = 1;

const pick = (obj, keys) => {
  const out = {};
  for (const k of keys) if (obj[k] !== undefined) out[k] = obj[k];
  return out;
};

const FIELD_KEYS = ['key', 'label', 'type', 'required', 'options', 'min', 'max', 'unit'];

/**
 * Definition -> plain JSON-ready object (what is downloaded as .fields.json, embedded in the
 * template, and what you would store in MongoDB). Keeps only known properties, so editor-only
 * state never leaks into the saved file.
 */
export function exportDefinition(def) {
  return {
    format: DEFINITION_FORMAT,
    formatVersion: DEFINITION_FORMAT_VERSION,
    templateId: def.templateId,
    name: def.name,
    version: def.version,
    fields: def.fields.map((f) => ({ ...pick(f, FIELD_KEYS), required: !!f.required, ...pick(f, ['labelPath', 'targetPaths']) })),
    groups: (def.groups || []).map((g) => ({
      ...pick(g, ['key', 'label', 'headerRow', 'removeSampleRows', 'sampleRows']),
      columns: g.columns.map((c) => ({ ...pick(c, FIELD_KEYS), required: !!c.required, ...pick(c, ['cell']) })),
    })),
  };
}

/** Push a message to `problems` for each thing wrong with one field/column. */
function checkField(f, where, problems) {
  if (!f || typeof f !== 'object') return problems.push(`${where} is not an object`);
  if (typeof f.key !== 'string' || !KEY_RE.test(f.key)) problems.push(`${where}: invalid key "${f.key}"`);
  if (!FIELD_TYPES.includes(f.type)) problems.push(`${where} (${f.key}): unknown type "${f.type}"`);
  if (f.type === 'dropdown' && (!Array.isArray(f.options) || !f.options.length)) problems.push(`${where} (${f.key}): dropdown needs "options"`);
}

/**
 * Accepts a JSON string or object, checks it, returns a normalized definition.
 * Throws an Error listing the problems when it isn't a usable field map.
 *
 * Checks: valid JSON object, known format and version, `fields`/`groups` arrays, every key
 * matches KEY_RE, every type is known, dropdowns have options, no key used twice, not empty.
 * Use it wherever a map comes from outside: a loaded file, an API request, a MongoDB document.
 *
 * @param {string|object} input
 * @returns {{ templateId, name, version, fields, groups }}  ready for parseSubmission({ definition })
 */
export function readDefinition(input) {
  let obj = input;
  if (typeof input === 'string') {
    try {
      obj = JSON.parse(input);
    } catch (e) {
      throw new Error(`Not valid JSON: ${e.message}`);
    }
  }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) throw new Error('The field map must be a JSON object.');
  if (obj.format && obj.format !== DEFINITION_FORMAT) throw new Error(`Unknown format "${obj.format}" (expected "${DEFINITION_FORMAT}").`);
  if (obj.formatVersion > DEFINITION_FORMAT_VERSION) throw new Error(`Field map format version ${obj.formatVersion} is newer than this app supports.`);

  const problems = [];
  if (!Array.isArray(obj.fields)) problems.push('"fields" must be an array');
  if (obj.groups !== undefined && !Array.isArray(obj.groups)) problems.push('"groups" must be an array');
  const fields = Array.isArray(obj.fields) ? obj.fields : [];
  const groups = Array.isArray(obj.groups) ? obj.groups : [];
  fields.forEach((f, i) => checkField(f, `fields[${i}]`, problems));
  groups.forEach((g, i) => {
    if (!g || typeof g.key !== 'string' || !KEY_RE.test(g.key)) problems.push(`groups[${i}]: invalid key "${g && g.key}"`);
    if (!g || !Array.isArray(g.columns)) problems.push(`groups[${i}]: "columns" must be an array`);
    else g.columns.forEach((c, j) => checkField(c, `groups[${i}].columns[${j}]`, problems));
  });
  const keys = fields.map((f) => f && f.key).concat(groups.map((g) => g && g.key));
  const dup = keys.find((k, i) => k && keys.indexOf(k) !== i);
  if (dup) problems.push(`key "${dup}" is used twice`);
  if (!fields.length && !groups.length) problems.push('the field map has no fields');
  if (problems.length) throw new Error(`Invalid field map: ${problems.slice(0, 5).join('; ')}${problems.length > 5 ? ` (+${problems.length - 5} more)` : ''}`);

  return {
    templateId: obj.templateId || null,
    name: obj.name || obj.templateId || 'Unnamed template',
    version: obj.version || null,
    fields,
    groups,
  };
}
