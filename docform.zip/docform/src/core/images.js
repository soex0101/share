/**
 * Pictures inside a filled .docx.
 *
 * In document.xml a picture is only a reference: <a:blip r:embed="rId7"/> (DrawingML, Word 2007+)
 * or <v:imagedata r:id="rId7"/> (VML, old files). The relationship rId7 in
 * word/_rels/document.xml.rels points to the file in the zip, e.g. word/media/image1.png.
 * Linked pictures (TargetMode="External") have no bytes in the file and are skipped.
 */
import { descendants, parseXml } from './xml.js';

const NS_A = 'http://schemas.openxmlformats.org/drawingml/2006/main';
const NS_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const NS_V = 'urn:schemas-microsoft-com:vml';
const NS_PKG_REL = 'http://schemas.openxmlformats.org/package/2006/relationships';

/** Relationship ids of the pictures inside an element, in document order, without repeats. */
export function imageRelIds(el) {
  const ids = [];
  for (const blip of descendants(el, 'blip', NS_A)) ids.push(blip.getAttributeNS(NS_R, 'embed'));
  for (const img of descendants(el, 'imagedata', NS_V)) ids.push(img.getAttributeNS(NS_R, 'id'));
  return ids.filter((id, i) => id && ids.indexOf(id) === i);
}

/** Map relationship id -> zip path ("word/media/image1.png") of the main document's embedded files. */
export async function readImageRels(zip) {
  const map = new Map();
  const file = zip.file('word/_rels/document.xml.rels');
  if (!file) return map;
  const rels = parseXml(await file.async('string'));
  for (const rel of descendants(rels, 'Relationship', NS_PKG_REL)) {
    if (rel.getAttribute('TargetMode') === 'External') continue;
    map.set(rel.getAttribute('Id'), resolveTarget(rel.getAttribute('Target')));
  }
  return map;
}

/** Target relative to word/ ("media/a.png", "../media/a.png") or absolute ("/word/media/a.png") -> zip path. */
function resolveTarget(target) {
  const parts = target.startsWith('/') ? [] : ['word'];
  for (const p of target.replace(/^\//, '').split('/')) {
    if (p === '..') parts.pop();
    else if (p && p !== '.') parts.push(p);
  }
  return parts.join('/');
}

const TYPES = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  bmp: 'image/bmp',
  tif: 'image/tiff',
  tiff: 'image/tiff',
  svg: 'image/svg+xml',
  webp: 'image/webp',
  emf: 'image/emf',
  wmf: 'image/wmf',
};

/** "image1.png" -> "image/png" ("application/octet-stream" when unknown). */
export const imageContentType = (fileName) => TYPES[(fileName.split('.').pop() || '').toLowerCase()] || 'application/octet-stream';
