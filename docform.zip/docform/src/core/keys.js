/**
 * Field names (keys) and field types.
 * A key is the name of the value in the parsed JSON and in the MongoDB document.
 */

/**
 * Suggest a camelCase key from a label the manager wrote in Word.
 *   "6. Project members" -> "projectMembers"   (leading numbering is dropped)
 *   "Age (years)"        -> "ageYears"
 *   "2024"               -> "f2024"            (keys may not start with a digit)
 * @param {string} label
 * @param {string} [fallback='field']  returned when the label has no letters or digits
 */
export function keyFromLabel(label, fallback = 'field') {
  const words = String(label)
    .replace(/^\s*[\d.)]+\s*/, '')
    .replace(/[^A-Za-z0-9]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!words.length) return fallback;
  const key = words.map((w, i) => (i === 0 ? w.toLowerCase() : w[0].toUpperCase() + w.slice(1).toLowerCase())).join('');
  return /^[0-9]/.test(key) ? `f${key}` : key;
}

/**
 * Valid key: letters, digits and _, not starting with a digit. Dots create nesting:
 * "client.name" is returned as { client: { name } }.
 * This also keeps keys safe as MongoDB field names (no "$" prefix, no empty parts).
 */
export const KEY_RE = /^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$/;

/** base, or base2, base3, ... when base is already in the `taken` Set. */
export function uniqueKey(base, taken) {
  if (!taken.has(base)) return base;
  let n = 2;
  while (taken.has(`${base}${n}`)) n++;
  return `${base}${n}`;
}

/**
 * Field types and how each becomes a Word content control / JSON value:
 *   text      plain text control (multi-line allowed)        -> string
 *   rich      rich text block (several paragraphs)            -> string (plain text; pictures in result.images)
 *   number    plain text control, checked when parsed         -> number (min/max checked)
 *   date      date picker, stored as yyyy-MM-dd               -> "2026-11-18"
 *   dropdown  drop-down list with fixed `options`             -> one of the options
 */
export const FIELD_TYPES = ['text', 'rich', 'number', 'date', 'dropdown'];
