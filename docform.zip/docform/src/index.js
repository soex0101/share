/**
 * Public entry for reusing DocForm pieces in another React app (e.g. your MERN frontend).
 * Each feature component works on props alone; no router or WorkspaceProvider needed.
 */
export { default as TemplateUploader } from './features/upload/TemplateUploader.jsx';
export { default as FieldMatcher } from './features/match/FieldMatcher.jsx';
export { default as DocPreview } from './features/match/DocPreview.jsx';
export { default as SubmissionParser } from './features/parse/SubmissionParser.jsx';
export { default as ParseResult } from './features/parse/ParseResult.jsx';
export { default as FieldMapActions } from './features/definition/FieldMapActions.jsx';
export { default as FieldMapLoader } from './features/definition/FieldMapLoader.jsx';
export { default as SaveTemplateButton } from './features/database/SaveTemplateButton.jsx';
export { default as SaveSubmissionButton } from './features/database/SaveSubmissionButton.jsx';
export { default as TemplatePicker } from './features/database/TemplatePicker.jsx';
export { default as SavedTemplateDownload } from './features/database/SavedTemplateDownload.jsx';
export * as api from './lib/api.js';
export { default as FileDrop } from './components/FileDrop.jsx';
export * from './core/index.js';
