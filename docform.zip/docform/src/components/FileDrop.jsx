import { useRef, useState } from 'react';

/**
 * Click-or-drop file picker. Calls onFile(file) with the first chosen file (a browser File).
 * Props:
 *   onFile(file)  required
 *   label         hint text next to the button
 *   accept        file input filter, default ".docx" (only a hint: check the file in onFile)
 *   buttonText    default "Choose .docx file"
 * The input is cleared after each pick, so choosing the same file again fires onFile again.
 */
export default function FileDrop({ onFile, label, accept = '.docx', buttonText = 'Choose .docx file' }) {
  const input = useRef(null);
  const [over, setOver] = useState(false);

  const pick = (files) => {
    const file = files && files[0];
    if (file) onFile(file);
  };

  return (
    <div
      className={`drop ${over ? 'over' : ''}`}
      onDragOver={(e) => {
        e.preventDefault();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        pick(e.dataTransfer.files);
      }}
    >
      <button type="button" className="btn primary" onClick={() => input.current.click()}>
        {buttonText}
      </button>
      {label && <span className="muted">{label}</span>}
      <input
        ref={input}
        type="file"
        accept={accept}
        hidden
        onChange={(e) => {
          pick(e.target.files);
          e.target.value = '';
        }}
      />
    </div>
  );
}
