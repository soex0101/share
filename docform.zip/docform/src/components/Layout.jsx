import { Link, useRoute } from '../router/hashRouter.jsx';

/**
 * App shell with the step navigation.
 * Props:
 *   steps     [{ path, label, enabled }]; disabled steps are shown but not clickable
 *   right     optional node at the right of the top bar (the current file name)
 *   children  the page
 * Steps before the current one show a check mark.
 */
export default function Layout({ steps, right, children }) {
  const path = useRoute();
  const currentIndex = steps.findIndex((s) => s.path === path);

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="logo" aria-hidden="true">D</span>
          DocForm
        </div>
        <nav className="stepper" aria-label="Steps">
          {steps.map((s, i) => {
            const state = i === currentIndex ? 'current' : i < currentIndex ? 'done' : '';
            const content = (
              <>
                <span className="num">{i < currentIndex ? '✓' : i + 1}</span>
                {s.label}
              </>
            );
            return s.enabled ? (
              <Link key={s.path} to={s.path} className={`step ${state}`} aria-current={i === currentIndex ? 'page' : undefined}>
                {content}
              </Link>
            ) : (
              <span key={s.path} className="step disabled" aria-disabled="true">
                {content}
              </span>
            );
          })}
        </nav>
        {right && <div className="topbar-right">{right}</div>}
      </header>
      <main className="content">{children}</main>
    </div>
  );
}
