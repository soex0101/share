import Layout from './components/Layout.jsx';
import { Routes } from './router/hashRouter.jsx';
import { WorkspaceProvider, useWorkspace } from './state/Workspace.jsx';
import UploadPage from './pages/UploadPage.jsx';
import MatchPage from './pages/MatchPage.jsx';
import DownloadPage from './pages/DownloadPage.jsx';
import ParsePage from './pages/ParsePage.jsx';

/**
 * The DocForm app: four pages, one per step, sharing the workspace (template + field map).
 * To add a page: create it in src/pages, add it to ROUTES and to `steps` below.
 */

/** URL hash -> page component. */
const ROUTES = {
  '/upload': UploadPage,
  '/match': MatchPage,
  '/download': DownloadPage,
  '/parse': ParsePage,
};

/** Top bar + current page. A step is clickable only when the data it needs exists. */
function Shell() {
  const { template } = useWorkspace();
  const steps = [
    { path: '/upload', label: 'Upload template', enabled: true },
    { path: '/match', label: 'Match fields', enabled: !!template },
    { path: '/download', label: 'Download template', enabled: true },
    { path: '/parse', label: 'Parse client file', enabled: true },
  ];
  return (
    <Layout steps={steps} right={template && <span className="file-name">{template.fileName}</span>}>
      <Routes routes={ROUTES} fallback="/upload" />
    </Layout>
  );
}

export default function App() {
  return (
    <WorkspaceProvider>
      <Shell />
    </WorkspaceProvider>
  );
}
