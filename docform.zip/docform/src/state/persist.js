/**
 * Tiny IndexedDB key-value store so work survives a page refresh.
 * Falls back to memory when IndexedDB is unavailable (e.g. private windows).
 *
 * Stored keys:
 *   IndexedDB    "template"    { fileName, bytes }   (the .docx can be several MB: too big for localStorage)
 *   localStorage "docform:definition"                 (small JSON, written synchronously)
 * This is per browser only (work in progress). Finished templates are saved for everyone in
 * MongoDB with "Save to database" on the Match page.
 */
const DB = 'docform';
const STORE = 'workspace';
const memory = new Map();

/** Open (and on first use create) the database. */
function open() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('no indexedDB'));
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Run one request in a transaction; resolves with its result when the transaction completes. */
function run(mode, fn) {
  return open().then(
    (db) =>
      new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, mode);
        const req = fn(tx.objectStore(STORE));
        tx.oncomplete = () => resolve(req && req.result);
        tx.onerror = () => reject(tx.error);
      }),
  );
}

/** Promise of the stored value (undefined when none). */
export function load(key) {
  return run('readonly', (s) => s.get(key)).catch(() => memory.get(key));
}

/** Store a value (undefined deletes it). Never rejects. */
export function save(key, value) {
  memory.set(key, value);
  return run('readwrite', (s) => (value === undefined ? s.delete(key) : s.put(value, key))).catch(() => undefined);
}

/**
 * Small JSON values (the definition) go to localStorage: it writes immediately, so a change
 * made just before a page refresh is never lost. Falls back to memory when storage is blocked.
 */
export function loadSync(key) {
  try {
    const raw = window.localStorage.getItem(`${DB}:${key}`);
    return raw ? JSON.parse(raw) : memory.get(key);
  } catch (e) {
    return memory.get(key);
  }
}

export function saveSync(key, value) {
  memory.set(key, value);
  try {
    if (value === undefined) window.localStorage.removeItem(`${DB}:${key}`);
    else window.localStorage.setItem(`${DB}:${key}`, JSON.stringify(value));
  } catch (e) {
    // storage full or blocked: memory copy still works for this session
  }
}
