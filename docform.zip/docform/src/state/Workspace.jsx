/**
 * Shared state for the pages: the uploaded template and its field definition.
 * Saved to the browser so each page can be opened or refreshed on its own.
 *
 * useWorkspace() returns:
 *   ready               false until the saved state has been read (pages render nothing before)
 *   template            { fileName, bytes, preview, openedAt } | null   (openedAt: changes with every new upload / open)
 *   definition          { templateId, name, version, fields, groups } | null
 *   setTemplate(t, d?)  new upload: replaces the template and starts an empty definition,
 *                       or definition d (a template version opened from the database: it counts as saved)
 *   dbStatus            'new' | 'saved' | 'changed': is the current definition saved in MongoDB (state/definition.js)
 *   markStored(d)       call after d was saved to MongoDB
 *   setDefinition(d)    value or updater function (like React's setState); saved immediately
 *
 * Only the pages use this. The feature components get everything through props, so they can
 * be used in another app with a different store (Redux, server state, …).
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { loadDocx, buildPreview } from '../core/index.js';
import { load, save, loadSync, saveSync } from './persist.js';
import { newDefinition, hasFields, storedSnapshot, dbStatus } from './definition.js';

export { newDefinition, hasFields };

const WorkspaceContext = createContext(null);

export function WorkspaceProvider({ children }) {
  const [ready, setReady] = useState(false);
  const [template, setTemplateState] = useState(null); // { fileName, bytes, preview }
  const [definition, setDefinitionState] = useState(null);
  const [stored, setStored] = useState(null); // storedSnapshot() of the last save / open from MongoDB

  // On start: restore the saved template (preview is rebuilt, it isn't stored) and definition.
  useEffect(() => {
    let alive = true;
    load('template')
      .then(async (t) => {
        if (!alive || !t) return;
        const { doc } = await loadDocx(t.bytes);
        if (!alive) return;
        setTemplateState({ ...t, preview: buildPreview(doc), openedAt: Date.now() });
        setDefinitionState(loadSync('definition') || newDefinition(t.fileName));
        setStored(loadSync('stored') || null);
      })
      .catch(() => undefined)
      .then(() => alive && setReady(true));
    return () => {
      alive = false;
    };
  }, []);

  /** Start over with a new template. t = { fileName, bytes, preview }; def = its fields (default: none yet). */
  const setTemplate = useCallback((t, def) => {
    const snap = def ? storedSnapshot(def) : undefined; // a given definition comes from the database
    if (!def) def = newDefinition(t.fileName);
    setTemplateState({ ...t, openedAt: Date.now() });
    setDefinitionState(def);
    setStored(snap || null);
    save('template', { fileName: t.fileName, bytes: t.bytes });
    saveSync('definition', def);
    saveSync('stored', snap);
  }, []);

  /** Remember that `def` is now saved in MongoDB (as def.templateId / def.version). */
  const markStored = useCallback((def) => {
    const snap = storedSnapshot(def);
    setStored(snap);
    saveSync('stored', snap);
  }, []);

  /** Replace the definition; next = new value or (prev) => new value. */
  const setDefinition = useCallback((next) => {
    setDefinitionState((prev) => {
      const value = typeof next === 'function' ? next(prev) : next;
      saveSync('definition', value);
      return value;
    });
  }, []);

  const status = useMemo(() => dbStatus(definition, stored), [definition, stored]);

  return (
    <WorkspaceContext.Provider value={{ ready, template, definition, setTemplate, setDefinition, dbStatus: status, markStored }}>
      {children}
    </WorkspaceContext.Provider>
  );
}

/** Access the workspace from a page. Throws when used outside <WorkspaceProvider>. */
export function useWorkspace() {
  const ctx = useContext(WorkspaceContext);
  if (!ctx) throw new Error('useWorkspace must be used inside <WorkspaceProvider>');
  return ctx;
}

