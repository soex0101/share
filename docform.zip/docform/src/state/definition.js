/** Pure helpers for template definitions (no React). */
import { exportDefinition } from '../core/index.js';

/**
 * Empty definition for a newly uploaded file.
 *   "Project Task.docx" -> { templateId: "tpl_project_task", name: "Project Task", version: 1, fields: [], groups: [] }
 * templateId + version identify the template everywhere (parsed results, MongoDB).
 */
export function newDefinition(fileName) {
  const base = fileName.replace(/\.docx$/i, '');
  return {
    templateId: `tpl_${base.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')}`,
    name: base,
    version: 1,
    fields: [],
    groups: [],
  };
}

/** True when at least one fixed field or repeating table is linked. */
export const hasFields =(def) => !!def && def.fields.length + def.groups.length > 0;

/**
 * Snapshot of a definition as saved in MongoDB: { templateId, version, json }.
 * Kept by the workspace so the pages know whether the current fields are saved.
 */
export const storedSnapshot = (def) => ({ templateId: def.templateId, version: def.version, json: JSON.stringify(exportDefinition(def)) });

/**
 * Database state of the current definition, compared with the last snapshot:
 *   'new'      this templateId + version is not known to be saved (new upload, or ID / version changed)
 *   'saved'    saved, no changes since
 *   'changed'  saved, but fields / name changed since ("Save changes" overwrites it)
 */
export function dbStatus(def, stored) {
  if (!def || !stored || stored.templateId !== def.templateId || stored.version !== def.version) return 'new';
  return stored.json === JSON.stringify(exportDefinition(def)) ? 'saved' : 'changed';
}
