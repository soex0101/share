import { useState } from 'react';
import { saveFile } from '../../lib/files.js';

/**
 * Shows a parseSubmission() result: status badge, errors (red), warnings (yellow), and the JSON
 * with Copy / Download buttons.
 * Props: result (from parseSubmission), fileName (of the client's .docx; used for the .json name)
 */
export default function ParseResult({ result, fileName }) {
  const [note, setNote] = useState('');
  const json = JSON.stringify(result, null, 2);

  const copy = () => {
    // navigator.clipboard needs https; plain-http LAN pages fall back to selecting the text
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(json).then(() => setNote('Copied'), () => setNote('Copy failed'));
    } else {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(document.getElementById('parse-json'));
      sel.removeAllRanges();
      sel.addRange(range);
      setNote(document.execCommand('copy') ? 'Copied' : 'Selected: press Ctrl+C');
    }
  };

  return (
    <div className="result">
      <div className="result-head">
        <span className={`status ${result.status}`}>{result.status === 'ok' ? 'OK' : 'Needs review'}</span>
        <span className="muted">
          {fileName} · {result.templateName || 'unknown template'}
          {result.version ? ` v${result.version}` : ''} · definition: {result.definitionSource}
        </span>
        <span className="spacer" />
        <button className="btn" onClick={copy}>{note || 'Copy JSON'}</button>
        <button className="btn" onClick={() => saveFile(json, fileName.replace(/\.docx$/i, '') + '.json', 'application/json')}>
          Download JSON
        </button>
      </div>
      {result.errors.length > 0 && (
        <ul className="issues">
          {result.errors.map((e, i) => (
            <li key={i}>
              <code>{e.field}</code> {e.message}
            </li>
          ))}
        </ul>
      )}
      {result.warnings.length > 0 && (
        <ul className="issues warn">
          {result.warnings.map((w, i) => (
            <li key={i}>{w}</li>
          ))}
        </ul>
      )}
      <pre className="json" id="parse-json">{json}</pre>
    </div>
  );
}
