import { useEffect, useState } from 'react';
import { parseSubmission } from '../../core/index.js';
import { readFile } from '../../lib/files.js';
import FileDrop from '../../components/FileDrop.jsx';
import ParseResult from './ParseResult.jsx';

/**
 * Upload a filled .docx and show the parsed JSON.
 * Props:
 *   definition          field map to use (e.g. loaded from JSON); wins over the one inside the file
 *   fallbackDefinition  used only when there is no `definition` and the file has none embedded
 *   onParsed(result, fileName, bytes)  called after every parse (also re-parses); the Parse page
 *                               keeps it for its "Save to database" button
 * Changing `definition` re-parses the current file.
 * Parsing runs in the browser; the file is not uploaded anywhere by this component.
 */
export default function SubmissionParser({ definition = null, fallbackDefinition = null, onParsed }) {
  const [file, setFile] = useState(null); // { name, bytes }
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!file) return undefined;
    let alive = true;
    setError('');
    parseSubmission(file.bytes, { definition, fallback: fallbackDefinition })
      .then((res) => {
        if (!alive) return;
        setResult(res);
        if (onParsed) onParsed(res, file.name, file.bytes);
      })
      .catch((e) => alive && (setResult(null), setError(`Could not read ${file.name}: ${e.message}`)));
    return () => {
      alive = false;
    };
    // onParsed is left out on purpose: a new callback identity must not re-parse the file
  }, [file, definition, fallbackDefinition]);

  const handle = async (f) => {
    setResult(null);
    setError('');
    try {
      setFile({ name: f.name, bytes: await readFile(f) });
    } catch (e) {
      setError(`Could not read ${f.name}: ${e.message}`);
    }
  };

  return (
    <div>
      <FileDrop onFile={handle} label="Drop the filled .docx here, or click to choose" />
      {error && <p className="error">{error}</p>}
      {result && <ParseResult result={result} fileName={file.name} />}
    </div>
  );
}
