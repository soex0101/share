import { useState } from 'react';
import { readDefinition } from '../../core/index.js';
import FileDrop from '../../components/FileDrop.jsx';

/**
 * Load a field map (.json) saved from the Match page.
 * The file is checked with readDefinition(); a bad file shows the reason and is not used.
 * When loaded, shows a summary card (name, ID, version, counts) with a Remove button.
 *
 * Props (controlled):
 *   value                          { definition, fileName } | null
 *   onChange(value | null)         null when Remove is clicked
 * For maps saved in MongoDB, see features/database/TemplatePicker.jsx (gives the same value shape).
 */
export default function FieldMapLoader({ value, onChange }) {
  const [error, setError] = useState('');

  const handle = async (file) => {
    setError('');
    try {
      const definition = readDefinition(await file.text());
      onChange({ definition, fileName: file.name });
    } catch (e) {
      setError(`${file.name}: ${e.message}`);
    }
  };

  if (value) {
    const d = value.definition;
    return (
      <div className="map-loaded">
        <span className="dot" />
        <div>
          <b>{value.fileName}</b>
          <div className="muted small">
            {d.name}
            {d.templateId ? ` · ${d.templateId}` : ''}
            {d.version ? ` v${d.version}` : ''} · {d.fields.length} field{d.fields.length === 1 ? '' : 's'} · {d.groups.length} table{d.groups.length === 1 ? '' : 's'}
          </div>
        </div>
        <button className="btn" onClick={() => onChange(null)}>
          Remove
        </button>
      </div>
    );
  }

  return (
    <div>
      <FileDrop onFile={handle} accept=".json,application/json" buttonText="Choose field map (.json)" label="Drop the .fields.json here, or click to choose" />
      {error && <p className="error">{error}</p>}
    </div>
  );
}
