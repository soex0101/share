import { useEffect, useState } from 'react';
import { exportDefinition } from '../../core/index.js';
import { saveFile, safeFileName } from '../../lib/files.js';

/** "Sample", version 1 -> "Sample_v1.fields.json" */
export const fieldMapFileName = (def) => `${safeFileName(`${def.name}_v${def.version}`)}.fields.json`;
// Pretty JSON, with number-only arrays (document positions) kept on one line.
export const fieldMapJson = (def) =>
  JSON.stringify(exportDefinition(def), null, 2).replace(/\[\s*(-?\d+(?:,\s*-?\d+)*)\s*\]/g, (m, nums) => `[${nums.split(/,\s*/).join(', ')}]`);

/**
 * "Download field map" + "View JSON" for a definition (Match page footer).
 * View JSON opens a dialog with the exact JSON that would be downloaded; Escape or a click
 * outside closes it.
 * Props: definition, disabled (e.g. while no field is linked)
 */
export default function FieldMapActions({ definition, disabled }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <div className="map-actions">
        <button className="btn" disabled={disabled} onClick={() => saveFile(fieldMapJson(definition), fieldMapFileName(definition), 'application/json')}>
          Download field map (.json)
        </button>
        <button className="btn" disabled={disabled} onClick={() => setOpen(true)}>
          View JSON
        </button>
      </div>
      {open && (
        <div className="overlay" onClick={() => setOpen(false)}>
          <div className="dialog" role="dialog" aria-modal="true" aria-label="Field map JSON" onClick={(e) => e.stopPropagation()}>
            <div className="dialog-head">
              <h2>Field map · {fieldMapFileName(definition)}</h2>
              <button className="icon-btn" aria-label="Close" onClick={() => setOpen(false)}>
                ×
              </button>
            </div>
            <p className="muted small">Load this file on the Parse page to read clients' filled documents with these fields.</p>
            <pre className="json">{fieldMapJson(definition)}</pre>
          </div>
        </div>
      )}
    </>
  );
}
