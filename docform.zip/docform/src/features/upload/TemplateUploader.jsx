import { useState } from 'react';
import { loadDocx, buildPreview } from '../../core/index.js';
import { readFile } from '../../lib/files.js';
import FileDrop from '../../components/FileDrop.jsx';

/**
 * Reads a Word template chosen by the user (step 1).
 * Checks the extension, opens the zip and builds the preview; nothing is uploaded anywhere.
 *
 * Props:
 *   onLoaded({ fileName, bytes, preview })
 *     fileName  e.g. "Sample.docx"
 *     bytes     Uint8Array of the original file (keep it: generateTemplate needs it later)
 *     preview   from buildPreview(), for FieldMatcher
 */
export default function TemplateUploader({ onLoaded }) {
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const handle = async (file) => {
    setError('');
    if (!/\.docx$/i.test(file.name)) {
      setError('Please choose a .docx file. Old .doc files must be saved as .docx in Word first.');
      return;
    }
    setBusy(true);
    try {
      const bytes = await readFile(file);
      const { doc } = await loadDocx(bytes);
      onLoaded({ fileName: file.name, bytes, preview: buildPreview(doc) });
    } catch (e) {
      setError(`Could not read this file: ${e.message}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <FileDrop onFile={handle} label={busy ? 'Reading…' : 'Drop the template .docx here, or click to choose'} />
      {error && <p className="error">{error}</p>}
    </div>
  );
}
