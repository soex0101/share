import { FIELD_TYPES, pathKey } from '../../core/index.js';
import { TYPE_LABELS } from './matcherModel.js';

/**
 * Form for linking one label to a fixed field (one value per document).
 * Controlled: FieldMatcher owns all values; this only renders them and reports changes.
 *
 * Props:
 *   sel            from startSelection(): sel.para (clicked label), sel.suggestions (input areas)
 *   used           Map(paraKey -> key) of areas already linked; such choices get a warning dot
 *   targetIdx      index of the chosen suggestion; onTarget(i) to change it
 *   form           { key, label, type, required, options, min, max, unit } (strings as typed)
 *   onChange(form) called with the whole updated form
 *   error          message to show (from fieldFromForm)
 *   onCancel, onSubmit
 */
export default function FixedFieldForm({ sel, used, targetIdx, onTarget, form, onChange, error, onCancel, onSubmit }) {
  const target = sel.suggestions[targetIdx];
  const set = (patch) => onChange({ ...form, ...patch });

  return (
    <div className="form">
      <span className="lbl">Client writes in</span>
      <div className="choices">
        {sel.suggestions.map((s, i) => {
          const taken = s.paths.map((p) => used.get(pathKey(p))).find(Boolean);
          return (
            <button key={s.mode} className={`choice ${i === targetIdx ? 'on' : ''}`} onClick={() => onTarget(i)} title={taken ? `Linked to ${taken}` : ''}>
              {s.mode === 'self' ? (sel.para.text.trim() ? 'Replace label' : 'This area') : s.title}
              {taken && <span className="warn-dot" aria-label="already linked" />}
            </button>
          );
        })}
      </div>
      {target && target.paths.length > 1 && form.type !== 'rich' && (
        <p className="note">Only the first paragraph is used for this type. Choose Rich text to take all {target.paths.length}.</p>
      )}
      <label>
        Field name (DB key)
        <input value={form.key} onChange={(e) => set({ key: e.target.value })} />
      </label>
      <label>
        Display label
        <input value={form.label} onChange={(e) => set({ label: e.target.value })} />
      </label>
      <label>
        Type
        <select value={form.type} onChange={(e) => set({ type: e.target.value })}>
          {FIELD_TYPES.map((t) => (
            <option key={t} value={t}>
              {TYPE_LABELS[t]}
            </option>
          ))}
        </select>
      </label>
      {form.type === 'dropdown' && (
        <label>
          Choices (one per line or comma separated)
          <textarea rows={4} value={form.options} onChange={(e) => set({ options: e.target.value })} />
        </label>
      )}
      {form.type === 'number' && (
        <div className="row3">
          <label>
            Min
            <input value={form.min} onChange={(e) => set({ min: e.target.value })} />
          </label>
          <label>
            Max
            <input value={form.max} onChange={(e) => set({ max: e.target.value })} />
          </label>
          <label>
            Unit
            <input value={form.unit} onChange={(e) => set({ unit: e.target.value })} />
          </label>
        </div>
      )}
      <label className="check">
        <input type="checkbox" checked={form.required} onChange={(e) => set({ required: e.target.checked })} />
        Required
      </label>
      {error && <p className="error">{error}</p>}
      <div className="actions">
        <button className="btn" onClick={onCancel}>
          Cancel
        </button>
        <button className="btn primary" onClick={onSubmit}>
          Create &amp; link
        </button>
      </div>
    </div>
  );
}
