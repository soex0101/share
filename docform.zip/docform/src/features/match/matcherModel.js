/**
 * Pure logic behind the field matcher: what is already linked, how the preview is highlighted,
 * and turning the link forms into definition entries (with validation).
 * No React here, so it is easy to test (test/matcher.test.js) and to reuse in another UI.
 */
import { suggestTargets, describeGroupRow, keyFromLabel, uniqueKey, KEY_RE, pathKey } from '../../core/index.js';

/** Names shown in the type drop-down. */
export const TYPE_LABELS = {
  text: 'Text',
  rich: 'Rich text (paragraphs, images)',
  number: 'Number',
  date: 'Date',
  dropdown: 'Dropdown',
};

/** "Web, Mobile\nHybrid" -> ['Web', 'Mobile', 'Hybrid'] */
export const parseOptions = (s) => String(s || '').split(/[\n,]/).map((x) => x.trim()).filter(Boolean);
/** Form text -> number, or undefined when blank (so min/max are left out of the JSON). */
const toNum = (s) => (String(s).trim() === '' ? undefined : Number(s));
/** "1. Task requirements" -> "Task requirements" */
const stripNumbering = (s) => String(s).replace(/^\s*[\d.)]+\s*/, '').trim();

/** All keys in use (fields and tables share one namespace in the JSON). */
export const takenKeys = (def) => new Set([...def.fields.map((f) => f.key), ...def.groups.map((g) => g.key)]);

/** Map(paragraph key -> field/group key) of input areas already in use. */
export function usedAreas(def, preview) {
  const m = new Map();
  for (const f of def.fields) f.targetPaths.forEach((p) => m.set(pathKey(p), f.key));
  for (const g of def.groups) {
    const block = preview.blocks.find((b) => b.type === 'table' && b.index === g.headerRow[0]);
    const row = block && block.rows[g.headerRow[1] + 1];
    if (row) row.cells.forEach((c) => c.paras.forEach((p) => m.set(p.key, g.key)));
  }
  return m;
}

/**
 * Everything the side panel needs after a paragraph is clicked.
 * Picks the first suggestion that is not linked yet, suggests a key from the label text,
 * defaults to rich text when the input area has several paragraphs, and, when a table cell
 * was clicked, prepares the repeating-table form from that row.
 * @returns {{ para, suggestions, groupInfo, targetIdx, fieldForm, groupForm }}
 */
export function startSelection(preview, def, para) {
  const used = usedAreas(def, preview);
  const taken = takenKeys(def);
  const suggestions = suggestTargets(preview, para.path);
  const free = suggestions.findIndex((s) => s.paths.every((p) => !used.has(pathKey(p))));
  const targetIdx = free >= 0 ? free : 0;
  const label = para.text.trim();
  const groupInfo = para.path.length === 4 ? describeGroupRow(preview, para.path.slice(0, 2)) : null;

  const fieldForm = {
    key: uniqueKey(keyFromLabel(label), taken),
    label: stripNumbering(label) || 'Field',
    type: suggestions[targetIdx] && suggestions[targetIdx].paths.length > 1 ? 'rich' : 'text',
    required: false,
    options: '',
    min: '',
    max: '',
    unit: '',
  };

  let groupForm = null;
  if (groupInfo) {
    const colKeys = new Set();
    groupForm = {
      key: uniqueKey(keyFromLabel(groupInfo.title || 'items'), taken),
      label: stripNumbering(groupInfo.title) || 'Items',
      removeSampleRows: true,
      columns: groupInfo.columns
        .filter((c) => c.ok)
        .map((c) => {
          const key = uniqueKey(keyFromLabel(c.label, `col${c.cell + 1}`), colKeys);
          colKeys.add(key);
          return { include: !!c.label, cell: c.cell, label: c.label, key, type: 'text', required: false, options: '' };
        }),
    };
  }
  return { para, suggestions, groupInfo, targetIdx, fieldForm, groupForm };
}

/**
 * Fixed-field form -> definition field. Returns { field } or { error }.
 * Rejects invalid or duplicate keys, input areas already linked, dropdowns without choices.
 * Only rich text keeps several paragraphs; other types use the first one.
 */
export function fieldFromForm(def, preview, sel, targetIdx, form) {
  const target = sel.suggestions[targetIdx];
  const key = form.key.trim();
  if (!KEY_RE.test(key)) return { error: 'Field name: letters, digits and _ (dots for nesting), starting with a letter.' };
  if (takenKeys(def).has(key)) return { error: `A field named "${key}" already exists.` };
  const paths = form.type === 'rich' ? target.paths : target.paths.slice(0, 1);
  const used = usedAreas(def, preview);
  const clash = paths.map((p) => used.get(pathKey(p))).find(Boolean);
  if (clash) return { error: `That input area is already linked to "${clash}".` };
  const options = parseOptions(form.options);
  if (form.type === 'dropdown' && !options.length) return { error: 'Add at least one dropdown choice.' };
  const field = {
    key,
    label: form.label.trim() || key,
    type: form.type,
    required: !!form.required,
    labelPath: sel.para.path,
    targetPaths: paths.map((p) => p.slice()),
  };
  if (form.type === 'dropdown') field.options = options;
  if (form.type === 'number') {
    field.min = toNum(form.min);
    field.max = toNum(form.max);
    field.unit = form.unit.trim() || undefined;
  }
  return { field };
}

/**
 * Repeating-table form -> definition group. Returns { group } or { error }.
 * Table keys may not contain dots (each row is one object). Checks column keys and
 * that the row to repeat is not already used by another field.
 */
export function groupFromForm(def, preview, sel, form) {
  const key = form.key.trim();
  if (!KEY_RE.test(key) || key.includes('.')) return { error: 'Table name: letters, digits and _, starting with a letter.' };
  if (takenKeys(def).has(key)) return { error: `A field named "${key}" already exists.` };
  const cols = form.columns.filter((c) => c.include);
  if (!cols.length) return { error: 'Include at least one column.' };
  const seen = new Set();
  for (const c of cols) {
    const k = c.key.trim();
    if (!KEY_RE.test(k)) return { error: `Column "${c.label}": invalid field name "${k}".` };
    if (seen.has(k)) return { error: `Column name "${k}" is used twice.` };
    seen.add(k);
    if (c.type === 'dropdown' && !parseOptions(c.options).length) return { error: `Column "${k}": add dropdown choices.` };
  }
  const used = usedAreas(def, preview);
  const rowUsed = sel.groupInfo.template.cells
    .reduce((all, c) => all.concat(c.paras), [])
    .map((p) => used.get(p.key))
    .find(Boolean);
  if (rowUsed) return { error: `The row below is already linked to "${rowUsed}".` };
  return {
    group: {
      key,
      label: form.label.trim() || key,
      headerRow: sel.para.path.slice(0, 2),
      removeSampleRows: !!form.removeSampleRows,
      sampleRows: sel.groupInfo.sampleRows,
      columns: cols.map((c) => {
        const col = { key: c.key.trim(), label: c.label, cell: c.cell, type: c.type, required: !!c.required };
        if (c.type === 'dropdown') col.options = parseOptions(c.options);
        return col;
      }),
    },
  };
}

/**
 * Highlights for the document preview: linked areas (with key chips), labels, table rows,
 * sample rows to be removed, and the current click/suggestion on top.
 * @returns {{ deco: Map, rowDeco: Map }}  props for DocPreview
 */
export function decorations(def, sel, mode, targetIdx, groupForm) {
  const deco = new Map();
  const rowDeco = new Map();
  for (const f of def.fields) {
    if (f.labelPath && !f.targetPaths.some((p) => pathKey(p) === pathKey(f.labelPath))) deco.set(pathKey(f.labelPath), { cls: 'is-label' });
    f.targetPaths.forEach((p, i) => deco.set(pathKey(p), { cls: 'is-linked', chip: i === 0 ? f.key : null }));
  }
  for (const g of def.groups) {
    const [i, r] = g.headerRow;
    rowDeco.set(`${i}.${r}`, { cls: 'is-group-header' });
    rowDeco.set(`${i}.${r + 1}`, { cls: 'is-group-row', chip: `${g.key}[ ] · client adds rows` });
    if (g.removeSampleRows) for (let k = 1; k <= g.sampleRows; k++) rowDeco.set(`${i}.${r + 1 + k}`, { cls: 'is-removed' });
  }
  if (sel) {
    if (mode === 'fixed') {
      const t = sel.suggestions[targetIdx];
      if (t) t.paths.forEach((p) => deco.set(pathKey(p), { cls: 'is-suggested' }));
      if (!t || !t.paths.some((p) => pathKey(p) === sel.para.key)) deco.set(sel.para.key, { cls: 'is-selected' });
    } else if (sel.groupInfo) {
      const [i, r] = sel.para.path;
      rowDeco.set(`${i}.${r}`, { cls: 'is-group-header pending' });
      rowDeco.set(`${i}.${r + 1}`, { cls: 'is-group-row pending', chip: 'repeating row' });
      if (groupForm && groupForm.removeSampleRows)
        for (let k = 1; k <= sel.groupInfo.sampleRows; k++) rowDeco.set(`${i}.${r + 1 + k}`, { cls: 'is-removed' });
    }
  }
  return { deco, rowDeco };
}
