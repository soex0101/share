/**
 * Renders the uploaded document (paragraphs and tables) and makes every paragraph clickable.
 * It is a simplified view (text, bold/italic/underline, alignment, merged cells, widths), not
 * a full Word renderer: enough to see the layout and click labels.
 *
 * Props:
 *   preview   from buildPreview()
 *   deco      Map(paraKey -> { cls, chip })  CSS class for a paragraph + optional label chip
 *             (classes: is-selected, is-suggested, is-linked, is-label)
 *   rowDeco   Map("i.r" -> { cls, chip })    same for table rows
 *             (is-group-header, is-group-row, is-removed, pending)
 *   onPick(para)  called with the preview paragraph that was clicked
 */

/** One paragraph with its formatted runs. Empty paragraphs get a clickable blank. */
function Para({ para, deco, onPick }) {
  const d = deco.get(para.key);
  return (
    <p
      className={`para ${d ? d.cls : ''}`}
      style={{ textAlign: para.align === 'center' ? 'center' : para.align === 'right' ? 'right' : undefined }}
      onClick={(e) => {
        e.stopPropagation();
        onPick(para);
      }}
    >
      {para.runs.length === 0 && <span className="empty">&nbsp;</span>}
      {para.runs.map((r, i) => (
        <span key={i} style={{ fontWeight: r.b ? 700 : undefined, fontStyle: r.i ? 'italic' : undefined, textDecoration: r.u ? 'underline' : undefined }}>
          {r.text}
        </span>
      ))}
      {d && d.chip && <span className="chip">{d.chip}</span>}
    </p>
  );
}

export default function DocPreview({ preview, deco = new Map(), rowDeco = new Map(), onPick = () => {} }) {
  return (
    <div className="page">
      {preview.blocks.map((b) =>
        b.type === 'p' ? (
          <Para key={b.para.key} para={b.para} deco={deco} onPick={onPick} />
        ) : (
          <table key={`t${b.index}`} className="doc-table">
            <tbody>
              {b.rows.map((row) => {
                const rd = rowDeco.get(row.path.join('.'));
                // cells continuing a vertical merge are covered by the rowSpan of the cell above
                const shown = row.cells.filter((cell) => cell.vMerge !== 'continue');
                return (
                  <tr key={row.r} className={rd ? rd.cls : ''}>
                    {shown.map((cell, ci) => (
                      // width is in twips (1/1440 inch); /15 gives about 1 px at 96 dpi
                      <td key={cell.c} colSpan={cell.span} rowSpan={cell.rowSpan} style={{ width: cell.width ? `${Math.round(cell.width / 15)}px` : undefined }}>
                        {/* row chip (e.g. "projectMembers[ ]") goes in the last cell */}
                        {ci === shown.length - 1 && rd && rd.chip && <span className="row-chip">{rd.chip}</span>}
                        {cell.paras.map((p) => (
                          <Para key={p.key} para={p} deco={deco} onPick={onPick} />
                        ))}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        ),
      )}
    </div>
  );
}
