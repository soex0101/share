import { FIELD_TYPES } from '../../core/index.js';

/**
 * Form for turning a table header row into a repeating table (a list of rows in the JSON).
 * Controlled, like FixedFieldForm.
 *
 * Props:
 *   sampleRows     number of example rows under the input row (offered for removal)
 *   form           { key, label, removeSampleRows,
 *                    columns: [{ include, cell, label, key, type, required, options }] }
 *                  one column per header cell; `include: false` leaves that column out of the data
 *   onChange(form), error, onCancel, onSubmit
 */
export default function RepeatingTableForm({ sampleRows, form, onChange, error, onCancel, onSubmit }) {
  const setCol = (idx, patch) => onChange({ ...form, columns: form.columns.map((c, i) => (i === idx ? { ...c, ...patch } : c)) });

  return (
    <div className="form">
      <p className="note">This row becomes the table header. The row below becomes the row clients repeat with the + button in Word.</p>
      <label>
        Table name (DB key)
        <input value={form.key} onChange={(e) => onChange({ ...form, key: e.target.value })} />
      </label>
      <span className="lbl">Columns</span>
      <div className="col-table">
        {form.columns.map((c, i) => (
          <div key={c.cell} className={`col-row ${c.include ? '' : 'off'}`}>
            <input type="checkbox" aria-label={`Include ${c.label}`} checked={c.include} onChange={(e) => setCol(i, { include: e.target.checked })} />
            <input className="ckey" aria-label={`Key for ${c.label}`} value={c.key} onChange={(e) => setCol(i, { key: e.target.value })} />
            <select aria-label={`Type for ${c.label}`} value={c.type} onChange={(e) => setCol(i, { type: e.target.value })}>
              {FIELD_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
            <label className="check mini" title="Required">
              <input type="checkbox" checked={c.required} onChange={(e) => setCol(i, { required: e.target.checked })} />
              req
            </label>
            {c.type === 'dropdown' && (
              <input className="copts" placeholder="Choices: M, F" aria-label={`Choices for ${c.label}`} value={c.options} onChange={(e) => setCol(i, { options: e.target.value })} />
            )}
          </div>
        ))}
      </div>
      {sampleRows > 0 && (
        <label className="check">
          <input type="checkbox" checked={form.removeSampleRows} onChange={(e) => onChange({ ...form, removeSampleRows: e.target.checked })} />
          Remove {sampleRows} sample row{sampleRows > 1 ? 's' : ''} below
        </label>
      )}
      {error && <p className="error">{error}</p>}
      <div className="actions">
        <button className="btn" onClick={onCancel}>
          Cancel
        </button>
        <button className="btn primary" onClick={onSubmit}>
          Create table
        </button>
      </div>
    </div>
  );
}
