import { useMemo, useState } from 'react';
import DocPreview from './DocPreview.jsx';
import FieldList from './FieldList.jsx';
import FixedFieldForm from './FixedFieldForm.jsx';
import RepeatingTableForm from './RepeatingTableForm.jsx';
import { startSelection, usedAreas, fieldFromForm, groupFromForm, decorations } from './matcherModel.js';

/**
 * Click-to-link editor: shows the template, lets the user create fixed fields and repeating tables.
 * Three columns: field list | document preview | link panel for the clicked label.
 *
 * Props:
 *   preview               from buildPreview() (TemplateUploader gives it)
 *   definition            { templateId, name, version, fields, groups }; controlled by the parent
 *   onChange(definition)  called with a new definition object after each add/remove
 *   footer                optional node shown under the field list (e.g. download buttons)
 *
 * The component never mutates `definition`, and keeps only the current click in local state,
 * so the parent decides where definitions are stored (browser, server, MongoDB…).
 * All decisions live in matcherModel.js (pure functions, unit tested).
 */
export default function FieldMatcher({ preview, definition, onChange, footer }) {
  const [sel, setSel] = useState(null); // from startSelection(): clicked paragraph + suggestions, null = nothing clicked
  const [mode, setMode] = useState('fixed'); // 'fixed' | 'group' (tab in the link panel)
  const [targetIdx, setTargetIdx] = useState(0); // which suggestion in sel.suggestions is chosen
  const [fieldForm, setFieldForm] = useState(null); // FixedFieldForm values
  const [groupForm, setGroupForm] = useState(null); // RepeatingTableForm values
  const [error, setError] = useState('');

  const used = useMemo(() => usedAreas(definition, preview), [definition, preview]);
  const { deco, rowDeco } = useMemo(() => decorations(definition, sel, mode, targetIdx, groupForm), [definition, sel, mode, targetIdx, groupForm]);

  // A paragraph was clicked: reset the panel with fresh suggestions and default form values.
  const pick = (para) => {
    const s = startSelection(preview, definition, para);
    setSel(s);
    setMode('fixed');
    setTargetIdx(s.targetIdx);
    setFieldForm(s.fieldForm);
    setGroupForm(s.groupForm);
    setError('');
  };

  // "Create & link" / "Create table": validate, then hand the new definition to the parent.
  const linkField = () => {
    const { field, error: err } = fieldFromForm(definition, preview, sel, targetIdx, fieldForm);
    if (err) return setError(err);
    onChange({ ...definition, fields: definition.fields.concat(field) });
    setSel(null);
  };

  const linkGroup = () => {
    const { group, error: err } = groupFromForm(definition, preview, sel, groupForm);
    if (err) return setError(err);
    onChange({ ...definition, groups: definition.groups.concat(group) });
    setSel(null);
  };

  const remove = (kind, key) => onChange({ ...definition, [kind]: definition[kind].filter((x) => x.key !== key) });

  return (
    <div className="match">
      <aside className="panel fields-panel" aria-label="Fields of this template">
        <h2>Fields of this template</h2>
        <p className="muted small">Click a label in the document to create and link a field.</p>
        <FieldList definition={definition} onRemove={remove} />
        {footer && <div className="panel-foot">{footer}</div>}
      </aside>

      <div className="doc-area">
        <div className="legend">
          <span><i className="lg selected" />Clicked label</span>
          <span><i className="lg suggested" />Input area</span>
          <span><i className="lg linked" />Linked</span>
          <span><i className="lg removed" />Sample rows removed</span>
        </div>
        <DocPreview preview={preview} deco={deco} rowDeco={rowDeco} onPick={pick} />
      </div>

      <aside className="panel link-panel" aria-label="Link field">
        {!sel && (
          <div className="empty-state">
            <h2>Link a label</h2>
            <ol className="muted small">
              <li>Click a label in the document, e.g. “Title” or “1. Task requirements”.</li>
              <li>Choose where the client writes: text below, the cell to the right or below, or the clicked area itself.</li>
              <li>Name the field and choose its type.</li>
              <li>For tables, click a header cell and choose “Repeating table”.</li>
            </ol>
          </div>
        )}
        {sel && (
          <>
            <div className="small muted upper">Clicked</div>
            <div className="clicked">{sel.para.text.trim() ? `“${sel.para.text.trim()}”` : '(empty area)'}</div>
            <div className="seg" role="tablist">
              <button role="tab" aria-selected={mode === 'fixed'} className={mode === 'fixed' ? 'on' : ''} onClick={() => setMode('fixed')}>
                Fixed field
              </button>
              <button
                role="tab"
                aria-selected={mode === 'group'}
                className={mode === 'group' ? 'on' : ''}
                disabled={!sel.groupInfo}
                title={sel.groupInfo ? '' : 'Click a table header cell to create a repeating table'}
                onClick={() => setMode('group')}
              >
                Repeating table
              </button>
            </div>
            {mode === 'fixed' && (
              <FixedFieldForm
                sel={sel}
                used={used}
                targetIdx={targetIdx}
                onTarget={setTargetIdx}
                form={fieldForm}
                onChange={setFieldForm}
                error={error}
                onCancel={() => setSel(null)}
                onSubmit={linkField}
              />
            )}
            {mode === 'group' && groupForm && (
              <RepeatingTableForm
                sampleRows={sel.groupInfo.sampleRows}
                form={groupForm}
                onChange={setGroupForm}
                error={error}
                onCancel={() => setSel(null)}
                onSubmit={linkGroup}
              />
            )}
          </>
        )}
      </aside>
    </div>
  );
}
