/**
 * Lists a definition's fixed fields and repeating tables (left panel of the Match page).
 * Props:
 *   definition          { fields, groups }
 *   onRemove(kind, key) optional; kind is 'fields' or 'groups'. Without it, no × buttons (read-only list).
 */
export default function FieldList({ definition, onRemove }) {
  return (
    <div>
      <h3>
        Fixed fields <span>{definition.fields.length}</span>
      </h3>
      {definition.fields.length === 0 && <p className="muted small">None yet.</p>}
      <ul className="field-list">
        {definition.fields.map((f) => (
          <li key={f.key}>
            <span className="dot" />
            <span className="fkey" title={f.key}>{f.key}</span>
            <span className="badge">
              {f.type}
              {f.required ? ' · req' : ''}
            </span>
            {onRemove && (
              <button className="icon-btn" aria-label={`Remove ${f.key}`} onClick={() => onRemove('fields', f.key)}>
                ×
              </button>
            )}
          </li>
        ))}
      </ul>
      <h3>
        Repeating tables <span>{definition.groups.length}</span>
      </h3>
      {definition.groups.length === 0 && <p className="muted small">Click a table header cell to make a repeating table.</p>}
      <ul className="field-list">
        {definition.groups.map((g) => (
          <li key={g.key} className="group">
            <div className="group-head">
              <span className="dot" />
              <span className="fkey" title={g.key}>{g.key}</span>
              <span className="badge">table · {g.columns.length} cols</span>
              {onRemove && (
                <button className="icon-btn" aria-label={`Remove ${g.key}`} onClick={() => onRemove('groups', g.key)}>
                  ×
                </button>
              )}
            </div>
            <div className="cols">{g.columns.map((c) => `${c.key}${c.type !== 'text' ? ` (${c.type})` : ''}`).join(' · ')}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
