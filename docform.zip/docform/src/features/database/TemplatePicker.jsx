import { useEffect, useState } from 'react';
import { readDefinition, loadDocx, buildPreview } from '../../core/index.js';
import { listTemplates, loadTemplate, loadTemplateSource } from '../../lib/api.js';

/**
 * Choose a template version saved in MongoDB.
 *
 * Two uses:
 *   Parse page   <TemplatePicker onPick={…} />            only the field map is loaded
 *                onPick({ definition, fileName })          same shape as FieldMapLoader;
 *                                                          fileName is a label like "tpl_sample v1 (database)"
 *   Match page   <TemplatePicker withSource onPick={…} />  also loads the manager's original .docx, to edit the fields
 *                onPick({ definition, fileName, template })
 *                  template        { fileName, bytes, preview }, same shape as TemplateUploader gives
 *                Versions saved without their original (before this was stored) are listed but disabled.
 *
 * Props:
 *   onPick(value)      see above
 *   withSource         boolean, see above
 *   label              text before the list (default "or use a saved template:")
 *   buttonText         default "Use"
 * When the API or the database is not available it shows one muted line instead.
 */
export default function TemplatePicker({ onPick, withSource = false, label = 'or use a saved template:', buttonText = 'Use' }) {
  const [list, setList] = useState(null);
  const [choice, setChoice] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const usable = (t) => !withSource || t.hasSource;

  useEffect(() => {
    let alive = true;
    listTemplates()
      .then((l) => {
        if (!alive) return;
        setList(l);
        const first = l.find(usable);
        if (first) setChoice(`${first.templateId}\n${first.version}`);
      })
      .catch((e) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, []);

  const use = async () => {
    const [templateId, v] = choice.split('\n');
    const version = Number(v);
    setError('');
    setBusy(true);
    try {
      const definition = readDefinition(await loadTemplate(templateId, version));
      const fileName = `${templateId} v${version} (database)`;
      if (!withSource) return onPick({ definition, fileName });

      const source = await loadTemplateSource(templateId, version);
      const { doc } = await loadDocx(source.bytes);
      onPick({ definition, fileName, template: { ...source, preview: buildPreview(doc) } });
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  if (!list) return error ? <p className="muted small">Saved templates are not available: {error}</p> : null;
  if (!list.length) return <p className="muted small">No templates are saved in the database yet.</p>;

  return (
    <div className="picker">
      <span className="muted small">{label}</span>
      <select aria-label="Saved template" value={choice} onChange={(e) => setChoice(e.target.value)}>
        {list.map((t) => (
          <option key={`${t.templateId}\n${t.version}`} value={`${t.templateId}\n${t.version}`} disabled={!usable(t)}>
            {t.name} · {t.templateId} v{t.version}
            {usable(t) ? '' : ' (original .docx not saved)'}
          </option>
        ))}
      </select>
      <button className="btn" disabled={busy || !choice} onClick={use}>
        {busy ? 'Loading…' : buttonText}
      </button>
      {error && <span className="error small">{error}</span>}
    </div>
  );
}
