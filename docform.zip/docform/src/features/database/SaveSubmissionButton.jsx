import { useState } from 'react';
import { saveSubmission } from '../../lib/api.js';

/**
 * "Save to database" for a parsed client file (Parse page).
 * Uploads the .docx; the server parses it again with the template's field map from MongoDB and
 * stores the result, so the saved data never depends on the browser. The same file is saved once.
 *
 * Props:
 *   bytes     the client's .docx
 *   fileName
 *   result    the browser's parseSubmission() result: tells the server which template to use
 *   onSaved({ id, result })   optional; result = the server's parse
 * Give it a `key` that changes with the file / field map, so the note resets.
 */
export default function SaveSubmissionButton({ bytes, fileName, result, onSaved }) {
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState(null); // { ok, text }

  const canSave = !!result.templateId;

  const save = async () => {
    setBusy(true);
    setNote(null);
    try {
      const saved = await saveSubmission(bytes, fileName, { templateId: result.templateId, version: result.version });
      const n = saved.result.errors.length;
      const pics = saved.result.images.length;
      const withPics = pics ? ` with ${pics} picture${pics === 1 ? '' : 's'}` : '';
      setNote({
        ok: true,
        text:
          saved.result.status === 'ok'
            ? `Saved to the database${withPics}.`
            : `Saved to the database${withPics}, marked "needs review" (${n} problem${n === 1 ? '' : 's'}).`,
      });
      if (onSaved) onSaved(saved);
    } catch (e) {
      setNote({ ok: false, text: e.status === 409 ? 'This file is already saved in the database.' : `Not saved: ${e.message}` });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="db-save">
      <button className="btn primary" disabled={busy || !canSave} onClick={save} title={canSave ? '' : 'Load the field map of this file first'}>
        {busy ? 'Saving…' : 'Save to database'}
      </button>
      {!canSave && <span className="muted small">No template is known for this file: load its field map first.</span>}
      {note && <span className={note.ok ? 'ok-text small' : 'error small'}>{note.text}</span>}
    </div>
  );
}
