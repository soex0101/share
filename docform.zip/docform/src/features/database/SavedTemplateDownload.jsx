import { useEffect, useState } from 'react';
import { listTemplates, loadTemplateFile } from '../../lib/api.js';
import { saveFile, DOCX_MIME } from '../../lib/files.js';

/**
 * Download the client template .docx of any version saved in MongoDB (Download page), e.g. to
 * send an older version again. The file is the one saved with "Save to database", unchanged.
 *
 * Props:
 *   preselect   optional { templateId, version } to select first (e.g. the template being edited)
 * Versions saved without a template file are listed but disabled.
 * When the API or the database is not available it shows one muted line instead.
 */
export default function SavedTemplateDownload({ preselect = null }) {
  const [list, setList] = useState(null);
  const [choice, setChoice] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    listTemplates()
      .then((l) => {
        if (!alive) return;
        setList(l);
        const wanted = preselect && l.find((t) => t.hasFile && t.templateId === preselect.templateId && t.version === preselect.version);
        const first = wanted || l.find((t) => t.hasFile);
        if (first) setChoice(`${first.templateId}\n${first.version}`);
      })
      .catch((e) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, []);

  const download = async () => {
    const [templateId, version] = choice.split('\n');
    setError('');
    setBusy(true);
    try {
      const { fileName, bytes } = await loadTemplateFile(templateId, version);
      saveFile(bytes, fileName, DOCX_MIME);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  if (!list) return error ? <p className="muted small">Saved templates are not available: {error}</p> : null;
  if (!list.length) return <p className="muted small">No templates are saved in the database yet.</p>;

  return (
    <div className="picker">
      <select aria-label="Saved template to download" value={choice} onChange={(e) => setChoice(e.target.value)}>
        {list.map((t) => (
          <option key={`${t.templateId}\n${t.version}`} value={`${t.templateId}\n${t.version}`} disabled={!t.hasFile}>
            {t.name} · {t.templateId} v{t.version}
            {t.hasFile ? '' : ' (no template file saved)'}
          </option>
        ))}
      </select>
      <button className="btn" disabled={busy || !choice} onClick={download}>
        {busy ? 'Downloading…' : 'Download .docx'}
      </button>
      {error && <span className="error small">{error}</span>}
    </div>
  );
}
