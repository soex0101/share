import { useState } from 'react';
import { generateTemplate } from '../../core/index.js';
import { saveTemplate, updateTemplate, saveTemplateFile, saveTemplateSource } from '../../lib/api.js';

/**
 * Save a template to MongoDB (Match page): its field map, the generated template
 * .docx sent to clients, and the original .docx (so the version can be opened again for editing).
 *
 * Buttons, by `status` (from the workspace, see state/definition.js dbStatus):
 *   'new'                 Save to database      creates templateId / version; if that version already exists (409),
 *                                               "Save as new version" is offered too
 *   'saved' | 'changed'   Save changes          overwrites the opened / last saved version (only when changed)
 *                         Save as new version   keeps it and saves the next free version (highest saved + 1)
 * Overwriting is for templates not sent out yet: client files made from the old fields are then
 * read with the new ones. After clients have the template, save a new version.
 *
 * Props:
 *   templateBytes  the manager's original .docx
 *   fileName       its file name (shown when the version is opened again)
 *   definition     the field map
 *   status         'new' | 'saved' | 'changed'
 *   onSaved(def)   called with the saved definition (its version is the one actually saved);
 *                  the page stores it and marks it as saved
 */
export default function SaveTemplateButton({ templateBytes, fileName, definition, status, onSaved }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [conflict, setConflict] = useState(false); // 'new' and the version exists: offer a new version

  /** mode: 'create' (POST), 'update' (PUT, overwrite), 'newVersion' (POST, next free version) */
  const store = async (mode) => {
    setBusy(true);
    setError('');
    try {
      const bytes = await generateTemplate(templateBytes, definition); // fails early if the map doesn't fit the file
      const saved =
        mode === 'update' ? await updateTemplate(definition) : await saveTemplate(definition, { newVersion: mode === 'newVersion' });
      const def = { ...definition, version: saved.version };
      // a new version number is embedded in the template, so generate it again for that version
      const file = def.version === definition.version ? bytes : await generateTemplate(templateBytes, def);
      await saveTemplateFile(def.templateId, def.version, file);
      await saveTemplateSource(def.templateId, def.version, templateBytes, fileName);
      setConflict(false);
      onSaved(def);
    } catch (e) {
      if (e.status === 409) setConflict(true);
      setError(`Not saved: ${e.message}`);
    } finally {
      setBusy(false);
    }
  };

  const name = `${definition.templateId} v${definition.version}`;
  const text = {
    new: 'Not saved in the database yet.',
    saved: `Saved in the database as ${name}.`,
    changed: `Changed since saved as ${name}.`,
  }[status];

  return (
    <div className="db-save-box">
      <p className={status === 'saved' ? 'ok-text small' : 'muted small'}>{text}</p>
      <div className="db-save">
        {status === 'new' ? (
          <button className="btn" disabled={busy} onClick={() => store('create')}>
            Save to database
          </button>
        ) : (
          <button className="btn" disabled={busy || status === 'saved'} onClick={() => store('update')}>
            Save changes
          </button>
        )}
        {(status !== 'new' || conflict) && (
          <button className="btn" disabled={busy} onClick={() => store('newVersion')}>
            Save as new version
          </button>
        )}
        {busy && <span className="muted small">Saving…</span>}
      </div>
      {status === 'changed' && (
        <p className="muted small">
          Save changes replaces {name}; files clients made from it are then read with the new fields. If clients already have
          it, save a new version.
        </p>
      )}
      {error && <p className="error small">{error}</p>}
    </div>
  );
}
