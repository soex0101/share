/**
 * Minimal hash router (#/upload, #/match, ...). Hash URLs work on any static server
 * and under any sub-path, with no server-side route configuration.
 * (Written by hand because current react-router versions need Node 14 or newer.)
 */
import { useEffect, useState } from 'react';

const currentPath = () => window.location.hash.replace(/^#/, '') || '/';

/** Current path ("/match"), re-rendering the component when the hash changes. */
export function useRoute() {
  const [path, setPath] = useState(currentPath);
  useEffect(() => {
    const onChange = () => setPath(currentPath());
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return path;
}

/** Go to a page from code: navigate('/download'). */
export function navigate(to) {
  window.location.hash = to;
}

/** <Link to="/parse">…</Link>: a normal <a href="#/parse">; other props are passed through. */
export function Link({ to, children, ...rest }) {
  return (
    <a href={`#${to}`} {...rest}>
      {children}
    </a>
  );
}

/** routes: { '/path': Component }. Unknown paths go to `fallback`. */
export function Routes({ routes, fallback }) {
  const path = useRoute();
  const Page = routes[path];
  useEffect(() => {
    if (!Page) navigate(fallback);
  }, [Page, fallback]);
  return Page ? <Page /> : null;
}
