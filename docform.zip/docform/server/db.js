/**
 * MongoDB connection.
 *
 * The web app must keep working while MongoDB is down (pages, parsing in the browser), so:
 *   - connect() never throws: it logs and retries every few seconds until MongoDB answers;
 *   - commands are not buffered: while disconnected, API calls fail at once with 503
 *     (see requireDb in routes/index.js) instead of hanging.
 * After the first connection the MongoDB driver reconnects by itself.
 */
'use strict';
const mongoose = require('mongoose');
const Template = require('./models/Template');
const Submission = require('./models/Submission');

mongoose.set('strictQuery', true);
mongoose.set('bufferCommands', false);

/** Redact the password in a connection string before logging it. */
const safeUrl = (url) => url.replace(/\/\/([^:@/]+):([^@/]+)@/, '//$1:***@');

/**
 * Connect and create the indexes (the unique indexes guard against duplicate versions / files).
 * @param {string} url  e.g. mongodb://127.0.0.1:27017/docform
 * @param {{ retryMs?: number, log?: Console }} [options]
 * @returns {Promise<void>} resolves once connected (keeps retrying until then)
 */
function connect(url, { retryMs = 5000, log = console } = {}) {
  return new Promise((resolve) => {
    const attempt = () =>
      mongoose
        .connect(url, { serverSelectionTimeoutMS: 5000 })
        .then(() => Promise.all([Template.init(), Submission.init()]))
        .then(() => {
          log.log(`MongoDB connected: ${safeUrl(url)}`);
          resolve();
        })
        .catch((e) => {
          log.error(`MongoDB not reachable (${e.message}). Retrying in ${retryMs / 1000}s…`);
          setTimeout(attempt, retryMs);
        });
    attempt();
  });
}

/** True while the connection is open. */
const isConnected = () => mongoose.connection.readyState === 1;

const disconnect = () => mongoose.disconnect();

module.exports = { connect, isConnected, disconnect };
