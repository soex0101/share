/**
 * Pictures from client files, stored in GridFS (bucket "images": collections images.files and
 * images.chunks). GridFS keeps them out of the submission document, which already holds the
 * whole .docx and must stay under MongoDB's 16 MB document limit.
 *
 * Each file's metadata: { submissionId, contentType }. The submission lists its pictures in
 * `images: [{ fileId, field, fileName, contentType, size }]` (see models/Submission.js).
 */
'use strict';
const mongoose = require('mongoose');

const BUCKET = 'images';

/** The GridFS bucket on the current connection (cheap to create; call after connecting). */
const bucket = () => new mongoose.mongo.GridFSBucket(mongoose.connection.db, { bucketName: BUCKET });

/** Store bytes; resolves with the new file's ObjectId. */
function upload(bytes, fileName, metadata) {
  return new Promise((resolve, reject) => {
    const stream = bucket().openUploadStream(fileName, { metadata });
    stream.once('finish', () => resolve(stream.id));
    stream.once('error', reject);
    stream.end(Buffer.from(bytes));
  });
}

/** Delete files (ignores ids that are already gone). */
const remove = (ids) => Promise.all(ids.map((id) => bucket().delete(id).catch(() => undefined)));

/** Readable stream of one file's bytes. */
const download = (id) => bucket().openDownloadStream(id);

module.exports = { BUCKET, upload, remove, download };
