/**
 * submissions collection: one document per client file saved from the Parse page.
 *
 *   { templateId: "tpl_sample", version: 1, fileName: "filled.docx",
 *     status: "ok" | "needs_review", parseErrors: [{ field, message }], warnings: [String],
 *     data: { title: "…", projectMembers: [{ name: "Jack", age: 31 }] },   // keys = field keys
 *     images: [{ fileId, field: "taskRequirements", fileName: "image1.png", contentType: "image/png", size }],
 *                                       // pictures in fields; bytes in GridFS (server/images.js)
 *     fileHash: "<sha256>", file: <Buffer original .docx>,
 *     createdAt, updatedAt }
 *
 * `data` keys are safe MongoDB names (see KEY_RE in src/core/keys.js), so they can be queried
 * directly: Submission.find({ 'data.projectMembers.age': { $gt: 30 } }).
 */
'use strict';
const mongoose = require('mongoose');

const SubmissionSchema = new mongoose.Schema(
  {
    templateId: { type: String, required: true },
    version: { type: Number, required: true },
    fileName: String,
    status: { type: String, enum: ['ok', 'needs_review'], required: true },
    // The parser calls this "errors"; Mongoose reserves that name for validation errors.
    parseErrors: [{ _id: false, field: String, message: String }],
    warnings: [String],
    data: { type: mongoose.Schema.Types.Mixed, default: {} },
    // Pictures found in fields (result.images of the parser). The bytes are in GridFS, bucket "images".
    images: [
      {
        _id: false,
        fileId: mongoose.Schema.Types.ObjectId,
        field: String, // e.g. "taskRequirements" or "members[0].photo"
        fileName: String,
        contentType: String,
        size: Number,
      },
    ],
    // SHA-256 of the file: the same file can't be saved twice (e.g. a double click).
    fileHash: { type: String, required: true },
    // The client's original file, kept for review. Not loaded unless asked for.
    file: { type: Buffer, select: false },
  },
  { timestamps: true, minimize: false },
);

SubmissionSchema.index({ fileHash: 1 }, { unique: true });
SubmissionSchema.index({ templateId: 1, version: 1, createdAt: -1 });
SubmissionSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.models.Submission || mongoose.model('Submission', SubmissionSchema);
