/**
 * templates collection: one document per template VERSION.
 *
 *   { templateId: "tpl_sample", version: 1, name: "Sample",
 *     definition: { format: "docform.definition", fields: [...], groups: [...] },   // field map JSON, as exported
 *     file: <Buffer .docx>,                                                          // published template (optional)
 *     source: <Buffer .docx>, sourceName: "Sample.docx",                             // manager's original, for re-editing (optional)
 *     createdAt, updatedAt }
 *
 * The unique index on { templateId, version } keeps one record per version. Changing a saved version is an
 * explicit overwrite ("Save changes", PUT); once clients have a version, save a new one instead.
 */
'use strict';
const mongoose = require('mongoose');

const TemplateSchema = new mongoose.Schema(
  {
    templateId: { type: String, required: true },
    version: { type: Number, required: true },
    name: { type: String, required: true },
    // Stored as-is (Mixed): every field has a property named "type", which a nested Mongoose
    // schema would read as a schema type, and the format can grow without a migration.
    definition: { type: mongoose.Schema.Types.Mixed, required: true },
    // The template .docx sent to clients. Not loaded unless asked for (.select('+file')).
    file: { type: Buffer, select: false },
    // The manager's original (untagged) .docx, so the Match page can open this version again and
    // change its fields. Also not loaded unless asked for (.select('+source')).
    source: { type: Buffer, select: false },
    sourceName: String,
  },
  { timestamps: true, minimize: false },
);

TemplateSchema.index({ templateId: 1, version: 1 }, { unique: true });

module.exports = mongoose.models.Template || mongoose.model('Template', TemplateSchema);
