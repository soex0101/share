/**
 * The Express app: the DocForm API under /api and the built web app (dist/) at /.
 * Kept separate from server.js (which reads options, connects MongoDB and listens) so tests
 * and other servers can mount it: e.g. app.use('/docform', createApp(...)) in your MERN backend.
 */
'use strict';
const express = require('express');
const apiRouter = require('./routes');

/**
 * @param {{ core: object, isConnected: () => boolean, distDir?: string }} options
 *   core         DocForm core functions (readDefinition, parseSubmission)
 *   isConnected  () => boolean, database state
 *   distDir      folder with the built app; omit to serve only the API
 */
function createApp({ core, isConnected, distDir }) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.set('X-Content-Type-Options', 'nosniff');
    next();
  });

  app.use('/api', apiRouter({ core, isConnected }));

  if (distDir) {
    app.use(
      express.static(distDir, {
        // index.html must always be fresh; hashed build assets never change
        setHeaders(res, file) {
          res.set('Cache-Control', /[\\/]assets[\\/]/.test(file) ? 'public, max-age=31536000, immutable' : 'no-cache');
        },
      }),
    );
  }

  // Real 404 (not index.html), so a missing script shows a clear error instead of a MIME error.
  app.use((req, res) => res.status(404).type('text/plain').send(`Not found: ${req.path}`));
  return app;
}

module.exports = { createApp };
