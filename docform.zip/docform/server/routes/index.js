/**
 * The /api router.
 *
 *   GET /api/health        { db: true | false }   (works without MongoDB; the app uses it to show the DB status)
 *   /api/templates/…       see templates.js
 *   /api/submissions/…     see submissions.js
 *
 * Errors are JSON: { error: "message" } with a matching HTTP status. While MongoDB is not
 * connected, every route except /health answers 503.
 */
'use strict';
const express = require('express');
const templatesRouter = require('./templates');
const submissionsRouter = require('./submissions');

/**
 * @param {{ core: object, isConnected: () => boolean }} deps
 *   core         DocForm core (dist-core/docform-core.js, or src/core in tests)
 *   isConnected  database state, from db.js
 */
module.exports = function apiRouter({ core, isConnected }) {
  const router = express.Router();

  router.get('/health', (req, res) => res.json({ db: isConnected() }));

  // fail fast instead of waiting for a database that isn't there
  router.use((req, res, next) => (isConnected() ? next() : res.status(503).json({ error: 'The database is not connected.' })));

  router.use('/templates', templatesRouter(core));
  router.use('/submissions', submissionsRouter(core));

  router.use((req, res) => res.status(404).json({ error: `No API route ${req.method} ${req.originalUrl}` }));

  // JSON errors: expected ones (httpError, body too large, bad JSON) with their status, others as 500
  // eslint-disable-next-line no-unused-vars
  router.use((err, req, res, next) => {
    const status = err.status || err.statusCode || 500;
    if (status >= 500) console.error(err);
    const message = status === 413 ? 'The file is too large (15 MB maximum).' : err.expose ? err.message : 'Server error.';
    res.status(status).json(Object.assign({ error: message }, err.extra));
  });

  return router;
};
