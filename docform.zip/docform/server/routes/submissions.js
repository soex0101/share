/**
 * /api/submissions: clients' filled files, parsed and stored.
 *
 *   POST /api/submissions?templateId=…&version=…   body: the filled .docx (raw), header X-File-Name
 *        -> 201 { id, result }        409 when this exact file is already saved
 *   GET  /api/submissions?templateId=&version=&status=&limit=   list (newest first, without files)
 *   GET  /api/submissions/:id                       one submission (without the file)
 *   GET  /api/submissions/:id/file                  the original .docx
 *   GET  /api/submissions/:id/images/:fileId        one picture from a field (GridFS)
 *
 * The server parses the file itself, with the field map saved in MongoDB, so stored data never
 * depends on what a browser sent. Which template: the templateId/version query (what the Parse
 * page used), else the field map embedded in the file.
 *
 * Pictures inside fields are stored in GridFS (server/images.js) and listed in the submission's
 * `images` with the field they belong to; `data` keeps the text.
 */
'use strict';
const crypto = require('crypto');
const express = require('express');
const mongoose = require('mongoose');
const Template = require('../models/Template');
const Submission = require('../models/Submission');
const images = require('../images');
const { wrap, httpError, rawDocx, DOCX_MIME } = require('./util');

/** Fields returned by list / get (never the file). */
const PUBLIC = { file: 0, __v: 0 };

/** @param core  DocForm core (parseSubmission, readDefinition) */
module.exports = function submissionsRouter(core) {
  const router = express.Router();

  router.post(
    '/',
    rawDocx,
    wrap(async (req, res) => {
      const bytes = req.body;
      if (!Buffer.isBuffer(bytes) || !bytes.length) throw httpError(400, 'Send the filled .docx as the request body.');

      // 1. which template?
      let first;
      try {
        first = await core.parseSubmission(bytes);
      } catch (e) {
        throw httpError(400, `Not a readable .docx: ${e.message}`);
      }
      const templateId = req.query.templateId ? String(req.query.templateId) : first.templateId;
      const version = req.query.version ? Number(req.query.version) : first.version;
      if (!templateId || !Number.isInteger(version)) {
        throw httpError(400, 'Unknown template: this file has no field map inside. Choose or load the template\'s field map first.');
      }
      const t = await Template.findOne({ templateId, version }, { definition: 1 }).lean();
      if (!t) throw httpError(400, `${templateId} v${version} is not saved in the database. Save it on the Match fields page first.`);

      // 2. parse with the stored field map
      const parsed = await core.parseSubmission(bytes, { definition: core.readDefinition(t.definition), withImageBytes: true });
      const { images: found, ...result } = parsed;

      // 3. store
      const fileHash = crypto.createHash('sha256').update(bytes).digest('hex');
      let doc;
      try {
        doc = await Submission.create({
          templateId,
          version,
          fileName: req.get('X-File-Name') ? decodeURIComponent(req.get('X-File-Name')) : null,
          status: result.status,
          parseErrors: result.errors,
          warnings: result.warnings,
          data: result.data,
          fileHash,
          file: bytes,
        });
      } catch (e) {
        if (e.code === 11000) {
          const existing = await Submission.findOne({ fileHash }, { _id: 1 }).lean();
          throw httpError(409, 'This file is already saved.', { id: existing && existing._id });
        }
        throw e;
      }

      // 4. pictures -> GridFS (each picture file once, even when used in several fields)
      const uploaded = new Map(); // zip path -> fileId
      try {
        for (const img of found) {
          if (!uploaded.has(img.path)) {
            uploaded.set(img.path, await images.upload(img.bytes, img.fileName, { submissionId: doc._id, contentType: img.contentType }));
          }
        }
        result.images = found.map((img) => ({
          fileId: uploaded.get(img.path),
          field: img.field,
          fileName: img.fileName,
          contentType: img.contentType,
          size: img.size,
        }));
        if (result.images.length) await Submission.updateOne({ _id: doc._id }, { images: result.images });
      } catch (e) {
        // all or nothing: no submission without its pictures
        await images.remove([...uploaded.values()]);
        await Submission.deleteOne({ _id: doc._id });
        throw e;
      }
      res.status(201).json({ id: doc._id, result });
    }),
  );

  router.get(
    '/',
    wrap(async (req, res) => {
      const filter = {};
      if (req.query.templateId) filter.templateId = String(req.query.templateId);
      if (req.query.version) filter.version = Number(req.query.version);
      if (req.query.status) filter.status = String(req.query.status);
      const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 1000);
      res.json(await Submission.find(filter, PUBLIC).sort({ createdAt: -1 }).limit(limit).lean());
    }),
  );

  /** :id must be an ObjectId, otherwise 404 (not a 500 cast error). */
  const byId = (id, fields) => {
    if (!mongoose.isValidObjectId(id)) throw httpError(404, 'Submission not found.');
    return Submission.findById(id, fields);
  };

  router.get(
    '/:id',
    wrap(async (req, res) => {
      const s = await byId(req.params.id, PUBLIC).lean();
      if (!s) throw httpError(404, 'Submission not found.');
      res.json(s);
    }),
  );

  router.get(
    '/:id/file',
    wrap(async (req, res) => {
      const s = await byId(req.params.id, { file: 1, fileName: 1 }).select('+file').lean();
      if (!s || !s.file) throw httpError(404, 'Submission not found.');
      res.set('Content-Type', DOCX_MIME);
      res.set('Content-Disposition', `attachment; filename="${encodeURIComponent(s.fileName || 'submission.docx')}"`);
      res.send(s.file.buffer || s.file);
    }),
  );

  router.get(
    '/:id/images/:fileId',
    wrap(async (req, res) => {
      if (!mongoose.isValidObjectId(req.params.fileId)) throw httpError(404, 'Picture not found.');
      const fileId = new mongoose.Types.ObjectId(req.params.fileId);
      const s = await byId(req.params.id, { images: 1 }).lean();
      const img = s && (s.images || []).find((i) => i.fileId && i.fileId.equals(fileId));
      if (!img) throw httpError(404, 'Picture not found.');
      res.set('Content-Type', img.contentType || 'application/octet-stream');
      // attachment: an SVG opened directly could run scripts on this site; <img src> still works
      res.set('Content-Disposition', `attachment; filename="${encodeURIComponent(img.fileName || 'image')}"`);
      images
        .download(fileId)
        .on('error', (e) => {
          if (res.headersSent) return res.destroy(e);
          res.removeHeader('Content-Disposition');
          res.status(404).type('json').json({ error: 'Picture not found.' });
        })
        .pipe(res);
    }),
  );

  return router;
};
