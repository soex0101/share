/**
 * /api/templates: field maps (template definitions) and the published template files.
 *
 *   POST /api/templates                          body: field map JSON  -> 201 { templateId, version }
 *                                                409 when that version is already saved
 *   POST /api/templates?newVersion=1             same, but saved as the next free version of its templateId
 *                                                (highest saved + 1, or 1); the answer says which
 *   PUT  /api/templates/:templateId/:version     body: field map JSON  -> 200 { templateId, version }
 *                                                overwrites a saved version ("Save changes"); 404 when not saved
 *   GET  /api/templates                          list: [{ templateId, version, name, createdAt, hasFile, hasSource }], newest version first
 *   GET  /api/templates/:templateId/:version     the field map JSON (:version may be "latest")
 *   PUT  /api/templates/:templateId/:version/file   body: the template .docx (raw)  -> 204
 *   GET  /api/templates/:templateId/:version/file   download the template .docx
 *   PUT  /api/templates/:templateId/:version/source body: the manager's original .docx (raw), header X-File-Name -> 204
 *   GET  /api/templates/:templateId/:version/source download it (file name in X-File-Name), to edit this version again
 */
'use strict';
const express = require('express');
const Template = require('../models/Template');
const { wrap, httpError, rawDocx, DOCX_MIME } = require('./util');

/** @param core  DocForm core (readDefinition) */
module.exports = function templatesRouter(core) {
  const router = express.Router();

  /** Validate a field map from a request body; returns the normalized definition or throws 400. */
  const checkMap = (body) => {
    let def;
    try {
      def = core.readDefinition(body); // full field map validation, same as the Parse page
    } catch (e) {
      throw httpError(400, e.message);
    }
    if (!def.templateId) throw httpError(400, 'The field map has no templateId.');
    return def;
  };
  const checkVersion = (v) => {
    if (!Number.isInteger(v) || v < 1) throw httpError(400, 'The field map version must be a whole number from 1.');
  };

  router.post(
    '/',
    express.json({ limit: '2mb' }),
    wrap(async (req, res) => {
      const def = checkMap(req.body);
      let version = def.version;
      if (req.query.newVersion) {
        const last = await Template.findOne({ templateId: def.templateId }, { version: 1 }).sort({ version: -1 }).lean();
        version = last ? last.version + 1 : 1;
      }
      checkVersion(version);
      try {
        await Template.create({ templateId: def.templateId, version, name: def.name, definition: { ...req.body, version } });
      } catch (e) {
        if (e.code === 11000) {
          throw httpError(409, `${def.templateId} v${version} is already saved. Save it as a new version, or open v${version} to change it.`);
        }
        throw e;
      }
      res.status(201).json({ templateId: def.templateId, version });
    }),
  );

  router.put(
    '/:templateId/:version',
    express.json({ limit: '2mb' }),
    wrap(async (req, res) => {
      const def = checkMap(req.body);
      const version = Number(req.params.version);
      checkVersion(version);
      if (def.templateId !== req.params.templateId || def.version !== version) {
        throw httpError(400, `The field map is ${def.templateId} v${def.version}, not ${req.params.templateId} v${version}.`);
      }
      const r = await Template.updateOne({ templateId: def.templateId, version }, { name: def.name, definition: req.body });
      if (!r.matchedCount) throw httpError(404, `${def.templateId} v${version} is not saved in the database yet.`);
      res.json({ templateId: def.templateId, version });
    }),
  );

  router.get(
    '/',
    wrap(async (req, res) => {
      // hasFile: the generated template is stored (Download page can download it again)
      // hasSource: the original .docx is stored, so the Match page can open this version for editing
      const list = await Template.aggregate([
        { $sort: { templateId: 1, version: -1 } },
        { $project: { _id: 0, templateId: 1, version: 1, name: 1, createdAt: 1, hasFile: { $ne: [{ $type: '$file' }, 'missing'] }, hasSource: { $ne: [{ $type: '$source' }, 'missing'] } } },
      ]);
      res.json(list);
    }),
  );

  /** Find one version; "latest" = highest version number. */
  const findVersion = (templateId, version, fields) => {
    if (version === 'latest') return Template.findOne({ templateId }, fields).sort({ version: -1 });
    const v = Number(version);
    if (!Number.isInteger(v)) throw httpError(400, 'Version must be a number or "latest".');
    return Template.findOne({ templateId, version: v }, fields);
  };

  router.get(
    '/:templateId/:version',
    wrap(async (req, res) => {
      const t = await findVersion(req.params.templateId, req.params.version, { definition: 1 }).lean();
      if (!t) throw httpError(404, 'Template not found.');
      res.json(t.definition);
    }),
  );

  /**
   * PUT / GET of one stored .docx of a version:
   *   /file    the generated template sent to clients (download name: "<name>_v<version>.docx")
   *   /source  the manager's original, kept for editing (its own file name, also sent as X-File-Name)
   */
  for (const [route, field] of [['file', 'file'], ['source', 'source']]) {
    router.put(
      `/:templateId/:version/${route}`,
      rawDocx,
      wrap(async (req, res) => {
        if (!Buffer.isBuffer(req.body) || !req.body.length) throw httpError(400, 'Send the .docx as the request body.');
        const update = { [field]: req.body };
        if (field === 'source') update.sourceName = decodeURIComponent(req.get('X-File-Name') || '') || 'template.docx';
        const r = await Template.updateOne({ templateId: req.params.templateId, version: Number(req.params.version) }, update);
        if (!r.matchedCount) throw httpError(404, 'Template not found. Save the field map first.');
        res.status(204).end();
      }),
    );

    router.get(
      `/:templateId/:version/${route}`,
      wrap(async (req, res) => {
        const t = await findVersion(req.params.templateId, req.params.version, { [field]: 1, sourceName: 1, name: 1, version: 1 })
          .select(`+${field}`)
          .lean();
        if (!t || !t[field]) {
          throw httpError(404, field === 'source' ? 'The original .docx of this version is not saved.' : 'No file saved for this template.');
        }
        const name = field === 'source' ? t.sourceName || 'template.docx' : `${t.name}_v${t.version}.docx`;
        res.set('Content-Type', DOCX_MIME);
        res.set('Content-Disposition', `attachment; filename="${encodeURIComponent(name)}"`);
        res.set('X-File-Name', encodeURIComponent(name));
        res.send(t[field].buffer || t[field]);
      }),
    );
  }

  return router;
};
