/** Small helpers shared by the API routes. */
'use strict';
const express = require('express');

const DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

/** Express 4 does not catch errors from async handlers: pass them to next(). */
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/** An Error the error handler sends as { error: message, ...extra } with this HTTP status. */
function httpError(status, message, extra) {
  const e = new Error(message);
  e.status = status;
  e.expose = true;
  e.extra = extra;
  return e;
}

/** Raw request body (Buffer) for .docx uploads, any content type. 15 MB keeps a document under MongoDB's 16 MB limit. */
const rawDocx = express.raw({ type: () => true, limit: '15mb' });

module.exports = { DOCX_MIME, wrap, httpError, rawDocx };
