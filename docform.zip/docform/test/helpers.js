import { readFileSync } from 'fs';
import { join } from 'path';
import JSZip from 'jszip';
import { loadDocx, buildPreview, suggestTargets, describeGroupRow, keyFromLabel } from '../src/core/index.js';
import { NS, child, descendants, elements, parseXml, serializeXml, wAttr } from '../src/core/xml.js';

export const sampleBytes = () => readFileSync(join(__dirname, 'fixtures', 'Sample.docx'));

export const findPara = (preview, text) => {
  for (const { para } of preview.paras.values()) if (para.text.trim() === text) return para;
  throw new Error(`paragraph "${text}" not found`);
};

/** The definition a manager would build in the UI for Sample.docx. */
export async function sampleDefinition() {
  const { doc } = await loadDocx(sampleBytes());
  const preview = buildPreview(doc);
  const target = (label, mode, nth = 0) => {
    const p = preview.paras.get(
      [...preview.paras.values()].filter(({ para }) => para.text.trim() === label)[nth].para.key,
    ).para;
    const t = suggestTargets(preview, p.path).find((x) => x.mode === mode);
    if (!t) throw new Error(`no ${mode} target for ${label}`);
    return { labelPath: p.path, targetPaths: t.paths, labelText: label };
  };
  // "2026" cells have month cells to their right
  const fromYear = target('From', 'right');
  const toYear = target('To', 'right');
  const fromMonthPath = [...fromYear.targetPaths[0]];
  fromMonthPath[2] += 1;
  const toMonthPath = [...toYear.targetPaths[0]];
  toMonthPath[2] += 1;
  const months = Array.from({ length: 12 }, (_, i) => String(i + 1));
  const fields = [
    { key: 'title', label: 'Title', type: 'text', required: true, ...target('Title', 'self') },
    { key: 'taskType', label: 'Task Type', type: 'dropdown', required: true, options: ['Web Project', 'Application', 'Mobile', 'Hybrid'], ...target('Task Type', 'self') },
    { key: 'periodFrom.year', label: 'From year', type: 'number', required: true, ...fromYear },
    { key: 'periodFrom.month', label: 'From month', type: 'dropdown', options: months, targetPaths: [fromMonthPath] },
    { key: 'periodTo.year', label: 'To year', type: 'number', required: true, ...toYear },
    { key: 'periodTo.month', label: 'To month', type: 'dropdown', options: months, targetPaths: [toMonthPath] },
    { key: 'taskRequirements', label: 'Task requirements', type: 'rich', required: true, ...target('1. Task requirements', 'below-text') },
    { key: 'economicEfficiency', label: 'Economic efficiency', type: 'rich', ...target('2. Economic effeciency', 'below-text') },
    { key: 'necessity', label: 'Necessity', type: 'rich', ...target('3. Necessity', 'below-text') },
    { key: 'investors', label: 'Investors', type: 'rich', ...target('4. Investors', 'below-text') },
    { key: 'totalInvestPool', label: 'Total invest pool', type: 'number', required: true, unit: 'USD', ...target('5. Total invest pool', 'below-text') },
  ];
  const group = (headerText, key, types = {}) => {
    const p = findPara(preview, headerText);
    const info = describeGroupRow(preview, p.path.slice(0, 2));
    return {
      key,
      label: info.title,
      headerRow: p.path.slice(0, 2),
      removeSampleRows: true,
      columns: info.columns.map((c) => ({ key: keyFromLabel(c.label), label: c.label, cell: c.cell, type: 'text', ...(types[keyFromLabel(c.label)] || {}) })),
    };
  };
  const groups = [
    group('Gender', 'members', { gender: { type: 'dropdown', options: ['M', 'F'] }, age: { type: 'number', min: 18, max: 70 }, name: { required: true } }),
    group('Purpose', 'funding', { amount: { type: 'number', required: true } }),
  ];
  return { templateId: 'tpl_project_task', name: 'Project Task Application', version: 1, fields, groups };
}

/** Simulate a client filling the template in Word. values: { tag: text }, rows: { groupKey: [{ tag: text }] } */
export async function fillDocx(bytes, values, rows = {}) {
  const zip = await JSZip.loadAsync(bytes);
  const doc = parseXml(await zip.file('word/document.xml').async('string'));
  const tagOf = (sdt) => {
    const t = child(child(sdt, 'sdtPr'), 'tag');
    return t ? wAttr(t, 'val') : '';
  };
  const setText = (sdt, text) => {
    const pr = child(sdt, 'sdtPr');
    const ph = child(pr, 'showingPlcHdr');
    if (ph) pr.removeChild(ph);
    const ts = descendants(child(sdt, 'sdtContent'), 't');
    ts[0].textContent = text;
    ts.slice(1).forEach((t) => t.parentNode.removeChild(t));
  };
  const all = descendants(doc, 'sdt');
  for (const sdt of all) {
    const pr = child(sdt, 'sdtPr');
    if (child(pr, 'repeatingSection', NS.w15)) {
      const list = rows[tagOf(sdt)] || [];
      const content = child(sdt, 'sdtContent');
      const item = elements(content)[0];
      list.forEach((row, i) => {
        const target = i === 0 ? item : content.appendChild(item.cloneNode(true));
        for (const inner of descendants(target, 'sdt')) {
          const t = tagOf(inner);
          if (t && row[t] !== undefined) setText(inner, row[t]);
        }
      });
    }
  }
  for (const sdt of descendants(doc, 'sdt')) {
    const t = tagOf(sdt);
    if (t && values[t] !== undefined) setText(sdt, values[t]);
  }
  zip.file('word/document.xml', serializeXml(doc));
  return zip.generateAsync({ type: 'uint8array' });
}

/** A 1×1 PNG. */
export const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');

/**
 * Simulate a client pasting a picture into the control tagged `tag` (as Word does: a w:drawing run
 * whose a:blip points to a relationship -> word/media/<name>). Options:
 *   name        media file name (default "pasted.png")
 *   external    a linked picture (TargetMode="External", no bytes in the file)
 *   relId       reuse an existing relationship id (same picture twice)
 */
export async function addImage(bytes, tag, image = PNG, { name = 'pasted.png', external = false, relId } = {}) {
  const zip = await JSZip.loadAsync(bytes);
  const doc = parseXml(await zip.file('word/document.xml').async('string'));
  const sdt = descendants(doc, 'sdt').find((s) => wAttr(child(child(s, 'sdtPr'), 'tag'), 'val') === tag);
  const pr = child(sdt, 'sdtPr');
  const ph = child(pr, 'showingPlcHdr');
  if (ph) {
    // placeholder showing: the picture replaces the gray text
    pr.removeChild(ph);
    for (const t of descendants(child(sdt, 'sdtContent'), 't')) t.textContent = '';
  }

  const id = relId || `rIdPic${Math.floor(Math.random() * 1e9)}`;
  if (!relId) {
    const relsXml = await zip.file('word/_rels/document.xml.rels').async('string');
    const rel = external
      ? `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="http://example.invalid/${name}" TargetMode="External"/>`
      : `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${name}"/>`;
    zip.file('word/_rels/document.xml.rels', relsXml.replace('</Relationships>', `${rel}</Relationships>`));
    if (!external) zip.file(`word/media/${name}`, image);
  }
  const run = parseXml(
    `<w:r xmlns:w="${NS.w}" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">` +
      `<w:drawing><wp:inline><wp:extent cx="9525" cy="9525"/><wp:docPr id="999" name="Picture"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">` +
      `<pic:pic><pic:nvPicPr><pic:cNvPr id="0" name="${name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip ${external ? 'r:link' : 'r:embed'}="${id}"/></pic:blipFill><pic:spPr/></pic:pic>` +
      `</a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`,
  ).documentElement;
  descendants(child(sdt, 'sdtContent'), 'p')[0].appendChild(doc.importNode(run, true));
  zip.file('word/document.xml', serializeXml(doc));
  return { bytes: await zip.generateAsync({ type: 'uint8array' }), relId: id };
}
