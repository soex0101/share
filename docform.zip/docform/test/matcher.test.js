import { loadDocx, buildPreview } from '../src/core/index.js';
import { startSelection, fieldFromForm, groupFromForm, usedAreas } from '../src/features/match/matcherModel.js';
import { newDefinition } from '../src/state/definition.js';
import { sampleBytes, findPara } from './helpers.js';

async function setup() {
  const { doc } = await loadDocx(sampleBytes());
  const preview = buildPreview(doc);
  return { preview, def: newDefinition('Sample.docx') };
}

describe('matcher model', () => {
  it('new definitions get an id from the file name', () => {
    expect(newDefinition('Project Task (v2).docx')).toMatchObject({ templateId: 'tpl_project_task_v2', name: 'Project Task (v2)', version: 1 });
  });

  it('suggests a key, type and input area for a heading', async () => {
    const { preview, def } = await setup();
    const sel = startSelection(preview, def, findPara(preview, '1. Task requirements'));
    expect(sel.fieldForm).toMatchObject({ key: 'taskRequirements', label: 'Task requirements', type: 'rich' });
    expect(sel.suggestions[sel.targetIdx].mode).toBe('below-text');
  });

  it('links a field and refuses the same area twice', async () => {
    const { preview, def } = await setup();
    const sel = startSelection(preview, def, findPara(preview, '4. Investors'));
    const { field } = fieldFromForm(def, preview, sel, sel.targetIdx, sel.fieldForm);
    expect(field.key).toBe('investors');
    const def2 = { ...def, fields: [field] };
    expect(usedAreas(def2, preview).size).toBe(1);
    const again = startSelection(preview, def2, findPara(preview, '4. Investors'));
    const form = { ...again.fieldForm, key: 'other' };
    const below = again.suggestions.findIndex((s) => s.mode === 'below-text');
    expect(fieldFromForm(def2, preview, again, below, form).error).toMatch(/already linked to "investors"/);
  });

  it('validates field names and dropdown choices', async () => {
    const { preview, def } = await setup();
    const sel = startSelection(preview, def, findPara(preview, 'Task Type'));
    expect(fieldFromForm(def, preview, sel, 0, { ...sel.fieldForm, key: '1bad' }).error).toMatch(/Field name/);
    expect(fieldFromForm(def, preview, sel, 0, { ...sel.fieldForm, type: 'dropdown', options: '' }).error).toMatch(/dropdown choice/);
  });

  it('builds a repeating table from a header row', async () => {
    const { preview, def } = await setup();
    const sel = startSelection(preview, def, findPara(preview, 'Gender'));
    expect(sel.groupForm.key).toBe('projectMembers');
    expect(sel.groupInfo.sampleRows).toBe(4);
    const { group } = groupFromForm(def, preview, sel, sel.groupForm);
    expect(group.columns.map((c) => c.key)).toEqual(['no', 'name', 'gender', 'age', 'duty', 'grade', 'responsibilities', 'from', 'to', 'result']);
  });
});
