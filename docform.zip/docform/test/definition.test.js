import JSZip from 'jszip';
import { generateTemplate, parseSubmission, exportDefinition, readDefinition, DEFINITION_FORMAT } from '../src/core/index.js';
import { sampleBytes, sampleDefinition, fillDocx } from './helpers.js';
import { dbStatus, storedSnapshot } from '../src/state/definition.js';

const VALUES = { title: 'Portal', taskType: 'Mobile', 'periodFrom.year': '2026', 'periodTo.year': '2027', taskRequirements: 'x', totalInvestPool: '1000' };

async function withoutEmbeddedMap(bytes) {
  const zip = await JSZip.loadAsync(bytes);
  zip.remove('customXml');
  return zip.generateAsync({ type: 'uint8array' });
}

describe('field map JSON', () => {
  it('exports keys, types and document positions, and reads back', async () => {
    const def = await sampleDefinition();
    const json = JSON.parse(JSON.stringify(exportDefinition(def)));
    expect(json.format).toBe(DEFINITION_FORMAT);
    expect(json.fields.find((f) => f.key === 'taskType')).toMatchObject({ type: 'dropdown', options: ['Web Project', 'Application', 'Mobile', 'Hybrid'], required: true });
    expect(json.fields[0].targetPaths).toBeDefined();
    expect(json.groups[0].columns[0].cell).toBe(0);
    const back = readDefinition(JSON.stringify(json));
    expect(back.templateId).toBe('tpl_project_task');
    expect(back.groups.map((g) => g.key)).toEqual(['members', 'funding']);
  });

  it('rejects files that are not a usable field map', () => {
    expect(() => readDefinition('{oops')).toThrow(/Not valid JSON/);
    expect(() => readDefinition('[]')).toThrow(/JSON object/);
    expect(() => readDefinition({ format: 'other' })).toThrow(/Unknown format/);
    expect(() => readDefinition({ fields: [{ key: 'a', type: 'colour' }] })).toThrow(/unknown type/);
    expect(() => readDefinition({ fields: [{ key: 'a', type: 'dropdown' }] })).toThrow(/needs "options"/);
    expect(() => readDefinition({ fields: [{ key: 'a', type: 'text' }, { key: 'a', type: 'text' }] })).toThrow(/used twice/);
    expect(() => readDefinition({ fields: [] })).toThrow(/no fields/);
  });
});

describe('parsing with a loaded field map', () => {
  it('reads a file that has no embedded map', async () => {
    const def = await sampleDefinition();
    const filled = await withoutEmbeddedMap(await fillDocx(await generateTemplate(sampleBytes(), def), VALUES));
    const bare = await parseSubmission(filled);
    expect(bare.definitionSource).toBe('none');
    expect(bare.data.periodFrom.year).toBe('2026'); // text only: no types without a map

    const res = await parseSubmission(filled, { definition: readDefinition(JSON.stringify(exportDefinition(def))) });
    expect(res.definitionSource).toBe('loaded');
    expect(res.errors).toEqual([]);
    expect(res.data.periodFrom.year).toBe(2026);
    expect(res.data.totalInvestPool).toBe(1000);
  });

  it('a loaded map wins over the embedded one and mismatches are reported', async () => {
    const def = await sampleDefinition();
    const filled = await fillDocx(await generateTemplate(sampleBytes(), def), VALUES);
    const other = readDefinition({ templateId: 'tpl_other', version: 3, fields: [{ key: 'title', type: 'text' }, { key: 'budget', type: 'number', required: true }] });
    const res = await parseSubmission(filled, { definition: other });
    expect(res.definitionSource).toBe('loaded');
    expect(res.warnings[0]).toMatch(/tpl_project_task.*tpl_other/);
    expect(res.errors.map((e) => e.field)).toEqual(['budget']);
    expect(res.data.title).toBe('Portal');
  });

  it('falls back to the given map only when nothing else is available', async () => {
    const def = await sampleDefinition();
    const filled = await fillDocx(await generateTemplate(sampleBytes(), def), VALUES);
    const res = await parseSubmission(filled, { fallback: readDefinition({ fields: [{ key: 'title', type: 'text' }] }) });
    expect(res.definitionSource).toBe('embedded');
  });
});

describe('saved state (workspace)', () => {
  const def = { templateId: 'tpl_a', name: 'A', version: 1, fields: [{ key: 'title', label: 'Title', type: 'text', targetPaths: [[1]] }], groups: [] };

  it('tells new, saved and changed apart', () => {
    expect(dbStatus(def, null)).toBe('new');
    const snap = storedSnapshot(def);
    expect(dbStatus({ ...def }, snap)).toBe('saved');
    expect(dbStatus({ ...def, fields: [] }, snap)).toBe('changed');
    expect(dbStatus({ ...def, name: 'B' }, snap)).toBe('changed');
    expect(dbStatus({ ...def, version: 2 }, snap)).toBe('new'); // another version is not saved yet
    expect(dbStatus({ ...def, templateId: 'tpl_b' }, snap)).toBe('new');
  });
});
