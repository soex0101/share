import JSZip from 'jszip';
import { loadDocx, buildPreview, suggestTargets, generateTemplate, parseSubmission, keyFromLabel } from '../src/core/index.js';
import { sampleBytes, sampleDefinition, fillDocx, findPara } from './helpers.js';

describe('preview', () => {
  it('reads the Sample table including merged cells', async () => {
    const { doc } = await loadDocx(sampleBytes());
    const preview = buildPreview(doc);
    const table = preview.blocks.find((b) => b.type === 'table');
    expect(table.rows).toHaveLength(18);
    expect(table.rows[0].cells[0].rowSpan).toBe(2);
    expect(table.rows[1].cells[0].vMerge).toBe('continue');
  });

  it('suggests the text below a heading, up to the blank line', async () => {
    const { doc } = await loadDocx(sampleBytes());
    const preview = buildPreview(doc);
    const label = findPara(preview, '1. Task requirements');
    const [first] = suggestTargets(preview, label.path);
    expect(first.mode).toBe('below-text');
    expect(first.paths.map((p) => preview.paras.get(p.join('.')).para.text)).toEqual([
      'This is task requirements section.',
      'There can be text, images.',
    ]);
  });

  it('suggests the cell below a signature label', async () => {
    const { doc } = await loadDocx(sampleBytes());
    const preview = buildPreview(doc);
    const label = findPara(preview, 'Sign of CTO');
    const below = suggestTargets(preview, label.path).find((t) => t.mode === 'below-cell');
    expect(below.paths[0][1]).toBe(label.path[1] + 1);
  });
});

describe('keys', () => {
  it('turns labels into field keys', () => {
    expect(keyFromLabel('6. Project members')).toBe('projectMembers');
    expect(keyFromLabel('Responsibilities ')).toBe('responsibilities');
  });
});

describe('generate + parse', () => {
  it('produces a tagged template that embeds its definition', async () => {
    const out = await generateTemplate(sampleBytes(), await sampleDefinition());
    const zip = await JSZip.loadAsync(out);
    const xml = await zip.file('word/document.xml').async('string');
    for (const tag of ['title', 'taskType', 'periodFrom.year', 'members', 'funding', 'gender', 'amount']) {
      expect(xml).toContain(`w:tag w:val="${tag}"`);
    }
    expect(xml).toContain('w15:repeatingSection');
    expect(xml).not.toContain('Alexander'); // sample rows removed
    expect(await zip.file('[Content_Types].xml').async('string')).toContain('/customXml/itemProps1.xml');
  });

  it('an unfilled template reports the required fields', async () => {
    const out = await generateTemplate(sampleBytes(), await sampleDefinition());
    const res = await parseSubmission(out);
    expect(res.definitionSource).toBe('embedded');
    expect(res.status).toBe('needs_review');
    expect(res.errors.map((e) => e.field)).toEqual(
      expect.arrayContaining(['title', 'taskType', 'taskRequirements', 'totalInvestPool']),
    );
    expect(res.data.members).toEqual([]);
  });

  it('reads a filled submission into typed JSON', async () => {
    const template = await generateTemplate(sampleBytes(), await sampleDefinition());
    const filled = await fillDocx(
      template,
      {
        title: 'Customer portal',
        taskType: 'Web Project',
        'periodFrom.year': '2026',
        'periodFrom.month': '1',
        'periodTo.year': '2026',
        'periodTo.month': '12',
        taskRequirements: 'Build the portal.',
        totalInvestPool: '$80,000',
      },
      {
        members: [
          { no: '1', name: 'Jack', gender: 'M', age: '31', duty: 'Senior' },
          { no: '2', name: 'Gleb', gender: 'F', age: '35', duty: 'Junior' },
        ],
        funding: [{ no: '1', purpose: 'Salary', reason: '5 Developers', amount: '$50000' }],
      },
    );
    const res = await parseSubmission(filled);
    expect(res.errors).toEqual([]);
    expect(res.status).toBe('ok');
    expect(res.templateId).toBe('tpl_project_task');
    expect(res.data.title).toBe('Customer portal');
    expect(res.data.periodFrom).toEqual({ year: 2026, month: '1' });
    expect(res.data.totalInvestPool).toBe(80000);
    expect(res.data.necessity).toBeNull();
    expect(res.data.members).toHaveLength(2);
    expect(res.data.members[1]).toMatchObject({ name: 'Gleb', gender: 'F', age: 35 });
    expect(res.data.funding[0]).toMatchObject({ purpose: 'Salary', amount: 50000 });
  });

  it('flags bad values instead of saving them silently', async () => {
    const template = await generateTemplate(sampleBytes(), await sampleDefinition());
    const filled = await fillDocx(
      template,
      { title: 'X', taskType: 'Desktop', 'periodFrom.year': '2026', 'periodTo.year': '2026', taskRequirements: 'x', totalInvestPool: 'a lot' },
      { members: [{ name: 'Tom', age: '12' }] },
    );
    const res = await parseSubmission(filled);
    const fields = res.errors.map((e) => e.field);
    expect(fields).toEqual(expect.arrayContaining(['taskType', 'totalInvestPool', 'members[0].age']));
    expect(res.status).toBe('needs_review');
  });

  it('rejects two fields on the same input area', async () => {
    const def = await sampleDefinition();
    def.fields[1].targetPaths = def.fields[0].targetPaths;
    await expect(generateTemplate(sampleBytes(), def)).rejects.toThrow(/same input area/);
  });
});
