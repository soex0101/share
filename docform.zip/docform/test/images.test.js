/** Pictures in filled files: listed per field in `result.images`, bytes on request. */
import { generateTemplate, parseSubmission } from '../src/core/index.js';
import { sampleBytes, sampleDefinition, fillDocx, addImage, PNG } from './helpers.js';

const VALUES = { title: 'Portal', taskType: 'Mobile', 'periodFrom.year': '2026', 'periodTo.year': '2027', taskRequirements: 'See the picture', totalInvestPool: '1000' };

async function filled(values = VALUES) {
  const def = await sampleDefinition();
  return { def, bytes: await fillDocx(await generateTemplate(sampleBytes(), def), values) };
}

describe('pictures in fields', () => {
  it('lists a picture with its field and keeps the text in data', async () => {
    const { def, bytes } = await filled();
    const withPic = (await addImage(bytes, 'taskRequirements', PNG, { name: 'diagram.png' })).bytes;
    const res = await parseSubmission(withPic, { definition: def });
    expect(res.data.taskRequirements).toBe('See the picture');
    expect(res.images).toEqual([{ field: 'taskRequirements', fileName: 'diagram.png', contentType: 'image/png', size: PNG.length, path: 'word/media/diagram.png' }]);
    expect(res.status).toBe('ok');

    const full = await parseSubmission(withPic, { definition: def, withImageBytes: true });
    expect(Buffer.from(full.images[0].bytes).equals(PNG)).toBe(true);
  });

  it('a required field holding only a picture is filled', async () => {
    const { def, bytes } = await filled({ ...VALUES, taskRequirements: undefined });
    const before = await parseSubmission(bytes, { definition: def });
    expect(before.errors.map((e) => e.field)).toContain('taskRequirements');

    const res = await parseSubmission((await addImage(bytes, 'taskRequirements')).bytes, { definition: def });
    expect(res.errors).toEqual([]);
    expect(res.data.taskRequirements).toBe('');
    expect(res.images.map((i) => i.field)).toEqual(['taskRequirements']);
  });

  it('skips linked pictures, counts a repeated picture once, and finds pictures in several fields', async () => {
    const { def, bytes } = await filled();
    const a = await addImage(bytes, 'necessity', PNG, { name: 'a.png' });
    const twice = await addImage(a.bytes, 'necessity', PNG, { relId: a.relId });
    const other = await addImage(twice.bytes, 'investors', PNG, { name: 'b.jpeg' });
    const linked = await addImage(other.bytes, 'economicEfficiency', PNG, { external: true });
    const res = await parseSubmission(linked.bytes, { definition: def });
    expect(res.images.map((i) => [i.field, i.fileName, i.contentType])).toEqual([
      ['necessity', 'a.png', 'image/png'],
      ['investors', 'b.jpeg', 'image/jpeg'],
    ]);
  });

  it('files without pictures have an empty list', async () => {
    const { def, bytes } = await filled();
    expect((await parseSubmission(bytes, { definition: def })).images).toEqual([]);
  });
});
