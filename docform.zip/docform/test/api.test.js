/**
 * API tests against a real MongoDB. Skipped unless MONGO_URL is set:
 *   MONGO_URL=mongodb://127.0.0.1:27017 npm test
 * Uses a throw-away database (docform_test_<time>) and drops it at the end.
 */
import http from 'http';
import mongoose from 'mongoose';
import * as core from '../src/core/index.js';
import { exportDefinition } from '../src/core/index.js';
import { sampleBytes, sampleDefinition, fillDocx, addImage, PNG } from './helpers.js';

const { createApp } = require('../server/app');
const db = require('../server/db');

const MONGO_URL = process.env.MONGO_URL;
const maybe = MONGO_URL ? describe : describe.skip;

const VALUES = { title: 'Portal', taskType: 'Mobile', 'periodFrom.year': '2026', 'periodTo.year': '2027', taskRequirements: 'x', totalInvestPool: '1000' };

/** Minimal HTTP client: returns { status, json, buf, headers }. */
function request(port, method, path, { json, bytes, headers = {} } = {}) {
  const body = json !== undefined ? Buffer.from(JSON.stringify(json)) : bytes ? Buffer.from(bytes) : null;
  const h = { ...headers };
  if (json !== undefined) h['Content-Type'] = 'application/json';
  if (body) h['Content-Length'] = body.length;
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, method, path, headers: h }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        let parsed = null;
        if (/json/.test(res.headers['content-type'] || '')) parsed = JSON.parse(buf.toString());
        resolve({ status: res.statusCode, json: parsed, buf, headers: res.headers });
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

maybe('MongoDB API', () => {
  let server;
  let port;
  let def;
  let template;
  let filled;
  const silent = { log: () => {}, error: () => {} };

  beforeAll(async () => {
    // same server, throw-away database name (keeps any ?options)
    const m = MONGO_URL.match(/^(mongodb(?:\+srv)?:\/\/[^/?]+)(?:\/[^?]*)?(\?.*)?$/);
    const url = `${m[1]}/docform_test_${Date.now()}${m[2] || ''}`;
    await db.connect(url, { log: silent });
    server = createApp({ core, isConnected: db.isConnected }).listen(0);
    port = server.address().port;
    def = await sampleDefinition();
    template = await core.generateTemplate(await sampleBytes(), def);
    filled = await fillDocx(template, VALUES, { members: [{ name: 'Jack', gender: 'M', age: '31' }] });
  }, 30000);

  afterAll(async () => {
    if (server) server.close();
    if (db.isConnected()) await mongoose.connection.dropDatabase();
    await db.disconnect();
  });

  it('reports the database state', async () => {
    expect((await request(port, 'GET', '/api/health')).json).toEqual({ db: true });
  });

  it('saves a field map once per version and returns it', async () => {
    const map = exportDefinition(def);
    expect((await request(port, 'POST', '/api/templates', { json: map })).status).toBe(201);
    const again = await request(port, 'POST', '/api/templates', { json: map });
    expect(again.status).toBe(409);
    expect(again.json.error).toMatch(/already saved\. Save it as a new version/);
    expect((await request(port, 'GET', `/api/templates/${def.templateId}/1`)).json).toEqual(map);
    expect((await request(port, 'GET', `/api/templates/${def.templateId}/latest`)).json.version).toBe(1);
    const list = (await request(port, 'GET', '/api/templates')).json;
    expect(list).toEqual([expect.objectContaining({ templateId: def.templateId, version: 1, name: def.name })]);
    expect(list[0].definition).toBeUndefined();
    expect(list[0].hasFile).toBe(false);
  });

  it('overwrites a saved version and saves new versions', async () => {
    const map = exportDefinition(def);
    const changed = { ...map, name: 'Changed', fields: map.fields.slice(1) };
    const put = await request(port, 'PUT', `/api/templates/${def.templateId}/1`, { json: changed });
    expect(put.status).toBe(200);
    expect((await request(port, 'GET', `/api/templates/${def.templateId}/1`)).json).toEqual(changed);
    expect((await request(port, 'GET', '/api/templates')).json[0].name).toBe('Changed');
    // URL and body must name the same version; unknown versions are not created by PUT
    expect((await request(port, 'PUT', `/api/templates/${def.templateId}/2`, { json: changed })).status).toBe(400);
    expect((await request(port, 'PUT', `/api/templates/${def.templateId}/9`, { json: { ...changed, version: 9 } })).status).toBe(404);

    const nv = await request(port, 'POST', '/api/templates?newVersion=1', { json: map }); // map says v1
    expect(nv.status).toBe(201);
    expect(nv.json).toEqual({ templateId: def.templateId, version: 2 });
    expect((await request(port, 'GET', `/api/templates/${def.templateId}/2`)).json).toEqual({ ...map, version: 2 });
    const first = await request(port, 'POST', '/api/templates?newVersion=1', { json: { ...map, templateId: 'tpl_fresh', version: 7 } });
    expect(first.json).toEqual({ templateId: 'tpl_fresh', version: 1 });

    // back to the original v1 for the next tests; drop the extra records
    expect((await request(port, 'PUT', `/api/templates/${def.templateId}/1`, { json: map })).status).toBe(200);
    await mongoose.connection.collection('templates').deleteMany({ $or: [{ version: 2 }, { templateId: 'tpl_fresh' }] });
  });

  it('rejects field maps that are not valid', async () => {
    const r = await request(port, 'POST', '/api/templates', { json: { fields: [{ key: '1bad', type: 'colour' }] } });
    expect(r.status).toBe(400);
    expect(r.json.error).toMatch(/Invalid field map/);
    const noVersion = await request(port, 'POST', '/api/templates', { json: { ...exportDefinition(def), version: null } });
    expect(noVersion.status).toBe(400);
    expect((await request(port, 'GET', '/api/templates/nope/1')).status).toBe(404);
  });

  it('stores and returns the template file', async () => {
    expect((await request(port, 'PUT', `/api/templates/${def.templateId}/1/file`, { bytes: template })).status).toBe(204);
    const r = await request(port, 'GET', `/api/templates/${def.templateId}/1/file`);
    expect(r.status).toBe(200);
    expect(Buffer.compare(r.buf, Buffer.from(template))).toBe(0);
    expect((await request(port, 'PUT', '/api/templates/nope/1/file', { bytes: template })).status).toBe(404);
    expect((await request(port, 'GET', '/api/templates')).json[0].hasFile).toBe(true);
    expect(decodeURIComponent(r.headers['x-file-name'])).toBe(`${def.name}_v1.docx`);
  });

  it('stores the original .docx so a version can be opened for editing', async () => {
    const list = async () => (await request(port, 'GET', '/api/templates')).json[0];
    expect((await list()).hasSource).toBe(false);
    expect((await request(port, 'GET', `/api/templates/${def.templateId}/1/source`)).status).toBe(404);

    const original = await sampleBytes();
    const put = await request(port, 'PUT', `/api/templates/${def.templateId}/1/source`, {
      bytes: original,
      headers: { 'X-File-Name': encodeURIComponent('Müller Sample.docx') },
    });
    expect(put.status).toBe(204);
    expect((await list()).hasSource).toBe(true);

    const r = await request(port, 'GET', `/api/templates/${def.templateId}/1/source`);
    expect(r.status).toBe(200);
    expect(decodeURIComponent(r.headers['x-file-name'])).toBe('Müller Sample.docx');
    expect(Buffer.compare(r.buf, Buffer.from(original))).toBe(0);

    // what the Match page does: original + stored map -> preview and a new template again
    const map = core.readDefinition((await request(port, 'GET', `/api/templates/${def.templateId}/1`)).json);
    const { doc } = await core.loadDocx(new Uint8Array(r.buf));
    expect(core.buildPreview(doc)).toBeTruthy();
    await expect(core.generateTemplate(new Uint8Array(r.buf), { ...map, version: 2 })).resolves.toBeTruthy();
  });

  it('parses a filled file with the stored map and saves it once', async () => {
    const r = await request(port, 'POST', '/api/submissions', { bytes: filled, headers: { 'X-File-Name': encodeURIComponent('Jack’s file.docx') } });
    expect(r.status).toBe(201);
    expect(r.json.result.data.title).toBe('Portal');
    expect(r.json.result.data.members[0].age).toBe(31);

    const dup = await request(port, 'POST', '/api/submissions', { bytes: filled });
    expect(dup.status).toBe(409);
    expect(dup.json.id).toBe(r.json.id);

    const one = (await request(port, 'GET', `/api/submissions/${r.json.id}`)).json;
    expect(one).toMatchObject({ templateId: def.templateId, version: 1, fileName: 'Jack’s file.docx', status: r.json.result.status });
    expect(one.file).toBeUndefined();
    expect(one.data.members[0].name).toBe('Jack');

    const file = await request(port, 'GET', `/api/submissions/${r.json.id}/file`);
    expect(Buffer.compare(file.buf, Buffer.from(filled))).toBe(0);
    expect((await request(port, 'GET', `/api/submissions?templateId=${def.templateId}`)).json).toHaveLength(1);
    expect((await request(port, 'GET', '/api/submissions/not-an-id')).status).toBe(404);
  });

  it('stores pictures from fields in GridFS', async () => {
    const one = await addImage(filled, 'necessity', PNG, { name: 'chart.png' });
    const again = await addImage(one.bytes, 'investors', PNG, { relId: one.relId }); // same picture in a second field
    const r = await request(port, 'POST', '/api/submissions', { bytes: again.bytes });
    expect(r.status).toBe(201);
    const imgs = r.json.result.images;
    expect(imgs.map((i) => [i.field, i.fileName, i.contentType, i.size])).toEqual([
      ['necessity', 'chart.png', 'image/png', PNG.length],
      ['investors', 'chart.png', 'image/png', PNG.length],
    ]);
    expect(imgs[0].fileId).toBe(imgs[1].fileId); // stored once
    expect(imgs[0].bytes).toBeUndefined();

    const s = (await request(port, 'GET', `/api/submissions/${r.json.id}`)).json;
    expect(s.images).toEqual(imgs);
    const files = await mongoose.connection.collection('images.files').find({ 'metadata.submissionId': new mongoose.Types.ObjectId(r.json.id) }).toArray();
    expect(files).toHaveLength(1);
    expect(files[0].metadata.contentType).toBe('image/png');

    const pic = await request(port, 'GET', `/api/submissions/${r.json.id}/images/${imgs[0].fileId}`);
    expect(pic.status).toBe(200);
    expect(pic.headers['content-type']).toBe('image/png');
    expect(Buffer.compare(pic.buf, PNG)).toBe(0);
    // a picture of another submission, or nonsense ids
    expect((await request(port, 'GET', `/api/submissions/${r.json.id}/images/${new mongoose.Types.ObjectId()}`)).status).toBe(404);
    expect((await request(port, 'GET', `/api/submissions/${r.json.id}/images/nope`)).status).toBe(404);
    await mongoose.connection.collection('submissions').deleteOne({ _id: new mongoose.Types.ObjectId(r.json.id) });
  });

  it('refuses files of unknown templates or that are not .docx', async () => {
    const other = await request(port, 'POST', '/api/submissions?templateId=tpl_other&version=1', { bytes: filled });
    expect(other.status).toBe(400);
    expect(other.json.error).toMatch(/not saved in the database/);
    const junk = await request(port, 'POST', '/api/submissions', { bytes: Buffer.from('hello') });
    expect(junk.status).toBe(400);
  });

  it('answers 503 while the database is down', async () => {
    const down = createApp({ core, isConnected: () => false }).listen(0);
    const r = await request(down.address().port, 'GET', '/api/templates');
    down.close();
    expect(r.status).toBe(503);
  });
});
