const form = document.getElementById("split");
const result = document.getElementById("result");
const copy = document.getElementById("copy");
const notice = document.getElementById("notice");

function shareText(count, cents) {
  const euros = Math.floor(cents / 100);
  const fraction = String(cents % 100).padStart(2, "0");
  const amount = "€" + euros + "." + fraction;
  if (count === 1) return "1 person pays " + amount + ".";
  return count + " people pay " + amount + " each.";
}

function clearResult() {
  result.textContent = "";
  notice.textContent = "";
  copy.disabled = true;
}
form.addEventListener("input", clearResult);

form.addEventListener("submit", (event) => {
  event.preventDefault();
  clearResult();
  const input = form.elements.bill.value.replace(",", ".");
  const [whole, part = ""] = input.split(".");
  const total = Number(whole + part.padEnd(2, "0"));
  const people = form.elements.people.valueAsNumber;
  if (!Number.isSafeInteger(total) || !Number.isSafeInteger(people)
      || total < 0 || people < 1) {
    notice.textContent = "Use a valid bill and group size.";
    return;
  }
  const base = Math.floor(total / people);
  const extra = total % people;
  if (extra === 0) {
    result.textContent = shareText(people, base);
  } else {
    result.textContent = shareText(extra, base + 1) + " " +
                         shareText(people - extra, base);
  }
  copy.disabled = false;
});

copy.addEventListener("click", async () => {
  const text = result.textContent;
  let message;
  try {
    await navigator.clipboard.writeText(text);
    message = "Copied. Paste the result into your chat.";
  } catch {
    message = "Select the result text and copy it manually.";
  }
  if (result.textContent === text) {
    notice.textContent = message;
  }
});

window.Telegram?.WebApp?.ready();
